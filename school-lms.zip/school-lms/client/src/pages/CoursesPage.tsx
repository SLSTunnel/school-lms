import React, { useState } from 'react';
import {
  Container,
  Grid,
  Card,
  CardContent,
  CardMedia,
  Typography,
  Box,
  Button,
  TextField,
  InputAdornment,
  MenuItem,
  Select,
  FormControl,
  InputLabel,
  Chip,
  LinearProgress,
  IconButton,
  Menu,
  MenuItem as MuiMenuItem,
} from '@mui/material';
import { styled } from '@mui/material/styles';
import {
  Search as SearchIcon,
  FilterList as FilterListIcon,
  MoreVert as MoreVertIcon,
  Book as BookIcon,
  Person as PersonIcon,
  AccessTime as TimeIcon,
  Star as StarIcon,
  PlayCircle as PlayIcon,
} from '@mui/icons-material';

const StyledCard = styled(Card)(({ theme }) => ({
  height: '100%',
  display: 'flex',
  flexDirection: 'column',
  transition: 'transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out',
  '&:hover': {
    transform: 'translateY(-5px)',
    boxShadow: theme.shadows[8],
  },
}));

const CourseCard: React.FC<{
  title: string;
  code: string;
  instructor: string;
  description: string;
  progress: number;
  status: 'in-progress' | 'completed' | 'upcoming';
  startDate: string;
  duration: string;
  onAction: (action: string) => void;
}> = ({ title, code, instructor, description, progress, status, startDate, duration, onAction }) => {
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const open = Boolean(anchorEl);

  const handleMenuClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = (action?: string) => {
    if (action) {
      onAction(action);
    }
    setAnchorEl(null);
  };

  const statusColors = {
    'in-progress': 'primary',
    'completed': 'success',
    'upcoming': 'warning',
  };

  const statusLabels = {
    'in-progress': 'In Progress',
    'completed': 'Completed',
    'upcoming': 'Upcoming',
  };

  return (
    <StyledCard>
      <CardMedia
        component="div"
        sx={{
          pt: '56.25%', // 16:9
          position: 'relative',
          bgcolor: 'primary.light',
          color: 'primary.contrastText',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center',
        }}
      >
        <BookIcon sx={{ fontSize: 60, opacity: 0.5 }} />
        <Chip
          label={statusLabels[status]}
          color={statusColors[status] as any}
          size="small"
          sx={{
            position: 'absolute',
            top: 16,
            right: 16,
            fontWeight: 600,
          }}
        />
      </CardMedia>
      <CardContent sx={{ flexGrow: 1, display: 'flex', flexDirection: 'column' }}>
        <Box display="flex" justifyContent="space-between" alignItems="flex-start" mb={1}>
          <Box>
            <Typography variant="caption" color="text.secondary">
              {code}
            </Typography>
            <Typography variant="h6" component="h3" gutterBottom>
              {title}
            </Typography>
          </Box>
          <IconButton
            aria-label="more"
            aria-controls="course-menu"
            aria-haspopup="true"
            onClick={handleMenuClick}
            size="small"
          >
            <MoreVertIcon />
          </IconButton>
          <Menu
            id="course-menu"
            anchorEl={anchorEl}
            keepMounted
            open={open}
            onClose={() => handleMenuClose()}
          >
            <MuiMenuItem onClick={() => handleMenuClose('view')}>View Details</MuiMenuItem>
            <MuiMenuItem onClick={() => handleMenuClose('download')}>Download Materials</MuiMenuItem>
            <MuiMenuItem onClick={() => handleMenuClose('unenroll')}>Unenroll</MuiMenuItem>
          </Menu>
        </Box>

        <Box display="flex" alignItems="center" mb={1}>
          <PersonIcon fontSize="small" color="action" sx={{ mr: 0.5 }} />
          <Typography variant="body2" color="text.secondary">
            {instructor}
          </Typography>
        </Box>

        <Typography variant="body2" color="text.secondary" paragraph sx={{ flexGrow: 1 }}>
          {description.length > 100 ? `${description.substring(0, 100)}...` : description}
        </Typography>

        {status !== 'upcoming' && (
          <Box mb={2}>
            <Box display="flex" justifyContent="space-between" mb={0.5}>
              <Typography variant="caption" color="text.secondary">
                Progress
              </Typography>
              <Typography variant="caption" color="text.secondary" fontWeight="bold">
                {progress}%
              </Typography>
            </Box>
            <LinearProgress
              variant="determinate"
              value={progress}
              sx={{ height: 8, borderRadius: 4 }}
            />
          </Box>
        )}

        <Box display="flex" justifyContent="space-between" alignItems="center" mt="auto">
          <Box display="flex" alignItems="center">
            <TimeIcon fontSize="small" color="action" sx={{ mr: 0.5 }} />
            <Typography variant="caption" color="text.secondary">
              {startDate} • {duration}
            </Typography>
          </Box>
          <Button
            variant="contained"
            color="primary"
            size="small"
            startIcon={status === 'completed' ? <StarIcon /> : <PlayIcon />}
            onClick={() => onAction('continue')}
          >
            {status === 'completed' ? 'Review' : 'Continue'}
          </Button>
        </Box>
      </CardContent>
    </StyledCard>
  );
};

const CoursesPage: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [filter, setFilter] = useState('all');
  const [sortBy, setSortBy] = useState('recent');

  // Sample course data
  const courses = [
    {
      id: 1,
      title: 'Introduction to React',
      code: 'CS-101',
      instructor: 'Dr. Sarah Johnson',
      description: 'Learn the fundamentals of React including components, state, and props.',
      progress: 75,
      status: 'in-progress' as const,
      startDate: 'Sep 1, 2023',
      duration: '8 weeks',
    },
    {
      id: 2,
      title: 'Advanced JavaScript',
      code: 'CS-201',
      instructor: 'Prof. Michael Chen',
      description: 'Deep dive into advanced JavaScript concepts and patterns.',
      progress: 100,
      status: 'completed' as const,
      startDate: 'Jul 15, 2023',
      duration: '10 weeks',
    },
    {
      id: 3,
      title: 'UI/UX Design Principles',
      code: 'DS-101',
      instructor: 'Dr. Emily Wilson',
      description: 'Master the principles of user interface and experience design.',
      progress: 25,
      status: 'in-progress' as const,
      startDate: 'Oct 1, 2023',
      duration: '6 weeks',
    },
    {
      id: 4,
      title: 'Data Structures & Algorithms',
      code: 'CS-301',
      instructor: 'Prof. Robert Taylor',
      description: 'Comprehensive study of data structures and algorithms with practical implementations.',
      progress: 0,
      status: 'upcoming' as const,
      startDate: 'Nov 15, 2023',
      duration: '12 weeks',
    },
  ];

  const handleCourseAction = (courseId: number, action: string) => {
    console.log(`Action '${action}' on course ${courseId}`);
    // Handle course actions (view, download, unenroll, etc.)
  };

  return (
    <Container maxWidth="xl" sx={{ mt: 4, mb: 6 }}>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={4} flexWrap="wrap" gap={2}>
        <Typography variant="h4" component="h1">
          My Courses
        </Typography>
        <Button variant="contained" color="primary">
          Enroll in a Course
        </Button>
      </Box>

      {/* Filters and Search */}
      <Box display="flex" flexWrap="wrap" gap={2} mb={4}>
        <TextField
          placeholder="Search courses..."
          variant="outlined"
          size="small"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon color="action" />
              </InputAdornment>
            ),
          }}
          sx={{ minWidth: 250, flexGrow: 1 }}
        />

        <FormControl variant="outlined" size="small" sx={{ minWidth: 200 }}>
          <InputLabel id="filter-label">Filter by Status</InputLabel>
          <Select
            labelId="filter-label"
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            label="Filter by Status"
            startAdornment={
              <InputAdornment position="start">
                <FilterListIcon color="action" />
              </InputAdornment>
            }
          >
            <MenuItem value="all">All Courses</MenuItem>
            <MenuItem value="in-progress">In Progress</MenuItem>
            <MenuItem value="completed">Completed</MenuItem>
            <MenuItem value="upcoming">Upcoming</MenuItem>
          </Select>
        </FormControl>

        <FormControl variant="outlined" size="small" sx={{ minWidth: 200 }}>
          <InputLabel id="sort-label">Sort By</InputLabel>
          <Select
            labelId="sort-label"
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            label="Sort By"
          >
            <MenuItem value="recent">Recently Added</MenuItem>
            <MenuItem value="title-asc">Title (A-Z)</MenuItem>
            <MenuItem value="title-desc">Title (Z-A)</MenuItem>
            <MenuItem value="progress">Progress</MenuItem>
            <MenuItem value="date">Start Date</MenuItem>
          </Select>
        </FormControl>
      </Box>

      {/* Course Grid */}
      {courses.length > 0 ? (
        <Grid container spacing={3}>
          {courses.map((course) => (
            <Grid item xs={12} sm={6} md={4} lg={3} key={course.id}>
              <CourseCard
                title={course.title}
                code={course.code}
                instructor={course.instructor}
                description={course.description}
                progress={course.progress}
                status={course.status}
                startDate={course.startDate}
                duration={course.duration}
                onAction={(action) => handleCourseAction(course.id, action)}
              />
            </Grid>
          ))}
        </Grid>
      ) : (
        <Box
          display="flex"
          flexDirection="column"
          alignItems="center"
          justifyContent="center"
          minHeight="300px"
          textAlign="center"
          p={4}
          bgcolor="background.paper"
          borderRadius={2}
          boxShadow={1}
        >
          <BookIcon color="disabled" sx={{ fontSize: 60, mb: 2, opacity: 0.5 }} />
          <Typography variant="h6" color="text.secondary" gutterBottom>
            No courses found
          </Typography>
          <Typography variant="body1" color="text.secondary" paragraph>
            {searchTerm
              ? 'No courses match your search criteria. Try adjusting your search or filters.'
              : 'You are not enrolled in any courses yet.'}
          </Typography>
          <Button variant="contained" color="primary">
            Browse Available Courses
          </Button>
        </Box>
      )}
    </Container>
  );
};

export default CoursesPage;
