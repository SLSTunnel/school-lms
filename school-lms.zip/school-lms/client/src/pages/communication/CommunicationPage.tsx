import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  Box, 
  Tabs, 
  Tab, 
  Paper, 
  Typography, 
  IconButton, 
  TextField, 
  InputAdornment, 
  List, 
  ListItem, 
  ListItemAvatar, 
  Avatar, 
  ListItemText, 
  ListItemSecondaryAction, 
  Badge,
  Button,
  Divider,
  useTheme,
  useMediaQuery
} from '@mui/material';
import { 
  Chat as ChatIcon, 
  Videocam as VideoIcon, 
  Search as SearchIcon, 
  Group as GroupIcon,
  Add as AddIcon,
  MoreVert as MoreVertIcon,
  ArrowBack as ArrowBackIcon,
  School as SchoolIcon,
  Person as PersonIcon
} from '@mui/icons-material';
import { ChatInterface } from '../../components/communication/chat/ChatInterface';
import ConferenceInterface from '../../components/communication/conference/ConferenceInterface';
import { useAuth } from '../../contexts/AuthContext';

// Mock data - replace with actual API calls
const mockConversations = [
  {
    id: 'conv1',
    name: 'Math 101 - Group Chat',
    type: 'course',
    courseId: 'math101',
    lastMessage: 'See you in class tomorrow!',
    unreadCount: 2,
    participants: ['s1', 's2', 's3', 't1'],
    updatedAt: new Date(Date.now() - 1000 * 60 * 30), // 30 minutes ago
  },
  {
    id: 'conv2',
    name: 'Dr. Smith',
    type: 'direct',
    lastMessage: 'Please submit your assignment by Friday',
    unreadCount: 0,
    participants: ['t1'],
    updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 2), // 2 hours ago
  },
  {
    id: 'conv3',
    name: 'Study Group',
    type: 'group',
    lastMessage: 'Let\'s meet at the library',
    unreadCount: 5,
    participants: ['s2', 's3', 's4'],
    updatedAt: new Date(Date.now() - 1000 * 60 * 60 * 24), // 1 day ago
  },
];

const mockCourses = [
  { id: 'math101', name: 'Introduction to Calculus', code: 'MATH-101' },
  { id: 'cs201', name: 'Data Structures', code: 'CS-201' },
  { id: 'phy301', name: 'Classical Mechanics', code: 'PHY-301' },
];

const CommunicationPage: React.FC = () => {
  const { tab = 'chats', id: activeId } = useParams<{ tab?: string; id?: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState(tab);
  const [showMobileDetail, setShowMobileDetail] = useState(false);

  // Update active tab when URL changes
  useEffect(() => {
    const tabFromUrl = window.location.pathname.split('/')[2] || 'chats';
    setActiveTab(tabFromUrl);
  }, [window.location.pathname]);

  // Handle tab change
  const handleTabChange = (event: React.SyntheticEvent, newValue: string) => {
    setActiveTab(newValue);
    navigate(`/communication/${newValue}`);
    if (isMobile) {
      setShowMobileDetail(false);
    }
  };

  // Handle conversation click
  const handleConversationClick = (conversationId: string) => {
    if (isMobile) {
      setShowMobileDetail(true);
    }
    // In a real app, you would navigate to the specific conversation
    console.log('Selected conversation:', conversationId);
  };

  // Handle back button click on mobile
  const handleBackClick = () => {
    setShowMobileDetail(false);
  };

  // Filter conversations based on search query
  const filteredConversations = mockConversations.filter(conv =>
    conv.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    conv.lastMessage.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Render conversation list
  const renderConversationList = () => (
    <Box sx={{ borderRight: 1, borderColor: 'divider', height: '100%' }}>
      <Box p={2}>
        <Typography variant="h6" gutterBottom>
          Messages
        </Typography>
        <TextField
          fullWidth
          variant="outlined"
          placeholder="Search conversations..."
          size="small"
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon />
              </InputAdornment>
            ),
          }}
        />
      </Box>
      <List sx={{ overflowY: 'auto', height: 'calc(100% - 120px)' }}>
        {filteredConversations.map((conversation) => (
          <React.Fragment key={conversation.id}>
            <ListItem 
              button 
              selected={activeId === conversation.id}
              onClick={() => handleConversationClick(conversation.id)}
            >
              <ListItemAvatar>
                <Badge 
                  badgeContent={conversation.unreadCount} 
                  color="primary"
                  invisible={conversation.unreadCount === 0}
                >
                  <Avatar>
                    {conversation.type === 'direct' 
                      ? conversation.name.charAt(0) 
                      : <GroupIcon />
                    }
                  </Avatar>
                </Badge>
              </ListItemAvatar>
              <ListItemText
                primary={
                  <Box display="flex" justifyContent="space-between" alignItems="center">
                    <Typography noWrap sx={{ fontWeight: conversation.unreadCount > 0 ? 'bold' : 'normal' }}>
                      {conversation.name}
                    </Typography>
                    <Typography variant="caption" color="text.secondary">
                      {formatTimeAgo(conversation.updatedAt)}
                    </Typography>
                  </Box>
                }
                secondary={
                  <Typography 
                    noWrap 
                    variant="body2" 
                    color={conversation.unreadCount > 0 ? 'primary' : 'text.secondary'}
                    sx={{ 
                      fontWeight: conversation.unreadCount > 0 ? 'bold' : 'normal',
                      maxWidth: '80%',
                      display: 'inline-block',
                      overflow: 'hidden',
                      textOverflow: 'ellipsis',
                      whiteSpace: 'nowrap',
                    }}
                  >
                    {conversation.lastMessage}
                  </Typography>
                }
              />
              <ListItemSecondaryAction>
                <IconButton edge="end" size="small">
                  <MoreVertIcon fontSize="small" />
                </IconButton>
              </ListItemSecondaryAction>
            </ListItem>
            <Divider variant="inset" component="li" />
          </React.Fragment>
        ))}
      </List>
      <Box p={2} borderTop={1} borderColor="divider">
        <Button 
          fullWidth 
          variant="contained" 
          startIcon={<AddIcon />}
          onClick={() => console.log('Start new conversation')}
        >
          New Conversation
        </Button>
      </Box>
    </Box>
  );

  // Render course list for video conferences
  const renderCourseList = () => (
    <Box sx={{ p: 2 }}>
      <Typography variant="h6" gutterBottom>
        My Courses
      </Typography>
      <List>
        {mockCourses.map((course) => (
          <React.Fragment key={course.id}>
            <ListItem 
              button 
              onClick={() => console.log('View course:', course.id)}
              sx={{ borderRadius: 1 }}
            >
              <ListItemAvatar>
                <Avatar sx={{ bgcolor: 'primary.main' }}>
                  <SchoolIcon />
                </Avatar>
              </ListItemAvatar>
              <ListItemText
                primary={course.name}
                secondary={course.code}
              />
              <ListItemSecondaryAction>
                <Button 
                  variant="outlined" 
                  size="small" 
                  startIcon={<VideoIcon />}
                  onClick={(e) => {
                    e.stopPropagation();
                    navigate(`/communication/meetings/new?courseId=${course.id}`);
                  }}
                >
                  New Meeting
                </Button>
              </ListItemSecondaryAction>
            </ListItem>
            <Divider variant="inset" component="li" />
          </React.Fragment>
        ))}
      </List>
      
      <Typography variant="h6" sx={{ mt: 4, mb: 2 }}>
        Upcoming Meetings
      </Typography>
      <Paper variant="outlined" sx={{ p: 2, borderRadius: 2 }}>
        <Typography color="text.secondary" align="center" sx={{ py: 4 }}>
          No upcoming meetings scheduled
        </Typography>
      </Paper>
      
      <Box mt={2} textAlign="center">
        <Button 
          variant="contained" 
          startIcon={<VideoIcon />}
          onClick={() => navigate('/communication/meetings/new')}
        >
          Start Instant Meeting
        </Button>
      </Box>
    </Box>
  );

  // Format time ago (e.g., "2 hours ago")
  const formatTimeAgo = (date: Date): string => {
    const seconds = Math.floor((new Date().getTime() - date.getTime()) / 1000);
    
    const intervals = {
      year: 31536000,
      month: 2592000,
      week: 604800,
      day: 86400,
      hour: 3600,
      minute: 60
    };
    
    for (const [unit, secondsInUnit] of Object.entries(intervals)) {
      const interval = Math.floor(seconds / secondsInUnit);
      if (interval >= 1) {
        return interval === 1 ? `1 ${unit} ago` : `${interval} ${unit}s ago`;
      }
    }
    
    return 'Just now';
  };

  // Render the appropriate content based on the active tab and mobile state
  const renderContent = () => {
    if (isMobile && showMobileDetail) {
      // Show conversation/meeting detail on mobile
      return (
        <Box flex={1} display="flex" flexDirection="column">
          <Box 
            sx={{ 
              p: 1, 
              display: 'flex', 
              alignItems: 'center',
              borderBottom: 1,
              borderColor: 'divider',
            }}
          >
            <IconButton onClick={handleBackClick} sx={{ mr: 1 }}>
              <ArrowBackIcon />
            </IconButton>
            <Typography variant="h6">
              {activeTab === 'chats' ? 'Chat' : 'Meeting'}
            </Typography>
          </Box>
          <Box flex={1} overflow="auto">
            {activeTab === 'chats' ? (
              <ChatInterface 
                conversationId={activeId || ''} 
                onBack={handleBackClick} 
                isMobile 
              />
            ) : (
              <ConferenceInterface 
                roomId={activeId || 'demo-room'} 
                onLeave={handleBackClick} 
              />
            )}
          </Box>
        </Box>
      );
    } else if (isMobile) {
      // Show list view on mobile
      return activeTab === 'chats' ? renderConversationList() : renderCourseList();
    } else {
      // Desktop view with sidebar and detail
      return (
        <Box display="flex" height="100%">
          <Box width={350} minWidth={350} maxWidth="30%" height="100%" overflow="hidden">
            {activeTab === 'chats' ? renderConversationList() : renderCourseList()}
          </Box>
          <Divider orientation="vertical" flexItem />
          <Box flex={1} minWidth={0} display="flex" flexDirection="column">
            {activeTab === 'chats' ? (
              activeId ? (
                <ChatInterface conversationId={activeId} />
              ) : (
                <Box 
                  display="flex" 
                  alignItems="center" 
                  justifyContent="center" 
                  height="100%"
                  textAlign="center"
                  p={4}
                >
                  <div>
                    <ChatIcon sx={{ fontSize: 64, color: 'text.secondary', mb: 2 }} />
                    <Typography variant="h6" color="text.secondary">
                      Select a conversation or start a new one
                    </Typography>
                    <Button 
                      variant="contained" 
                      color="primary" 
                      sx={{ mt: 2 }}
                      startIcon={<AddIcon />}
                    >
                      New Chat
                    </Button>
                  </div>
                </Box>
              )
            ) : (
              <ConferenceInterface roomId={activeId || 'demo-room'} />
            )}
          </Box>
        </Box>
      );
    }
  };

  return (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      {/* Tabs */}
      <Paper square elevation={0} sx={{ borderBottom: 1, borderColor: 'divider' }}>
        <Tabs
          value={activeTab}
          onChange={handleTabChange}
          variant="fullWidth"
          indicatorColor="primary"
          textColor="primary"
          sx={{
            '& .MuiTab-root': {
              minHeight: 64,
            },
          }}
        >
          <Tab 
            icon={<ChatIcon />} 
            label="Chats" 
            value="chats" 
            iconPosition="start" 
          />
          <Tab 
            icon={<VideoIcon />} 
            label="Meetings" 
            value="meetings" 
            iconPosition="start" 
          />
        </Tabs>
      </Paper>
      
      {/* Main content */}
      <Box flex={1} overflow="hidden" bgcolor="background.default">
        {renderContent()}
      </Box>
    </Box>
  );
};

export default CommunicationPage;
