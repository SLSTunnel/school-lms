import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import {
  Box,
  Button,
  TextField,
  Typography,
  Paper,
  Grid,
  Divider,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  FormControlLabel,
  Switch,
  Chip,
  Avatar,
  List,
  ListItem,
  ListItemAvatar,
  ListItemText,
  Checkbox,
  IconButton,
  useTheme,
  useMediaQuery,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  DialogContentText,
  FormGroup,
  InputAdornment,
  Alert,
  AlertTitle,
} from '@mui/material';
import {
  ArrowBack as ArrowBackIcon,
  PersonAdd as PersonAddIcon,
  Schedule as ScheduleIcon,
  VideoCall as VideoCallIcon,
  Close as CloseIcon,
  Check as CheckIcon,
  Group as GroupIcon,
  School as SchoolIcon,
  Person as PersonIcon,
  Event as EventIcon,
  AccessTime as AccessTimeIcon,
  Lock as LockIcon,
  LockOpen as LockOpenIcon,
  Link as LinkIcon,
  ContentCopy as ContentCopyIcon,
} from '@mui/icons-material';
import { DateTimePicker } from '@mui/x-date-pickers/DateTimePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { format, addMinutes, isBefore, isAfter } from 'date-fns';
import { useAuth } from '../../contexts/AuthContext';

// Mock data - replace with actual API calls
const mockCourses = [
  { id: 'math101', name: 'Introduction to Calculus', code: 'MATH-101' },
  { id: 'cs201', name: 'Data Structures', code: 'CS-201' },
  { id: 'phy301', name: 'Classical Mechanics', code: 'PHY-301' },
];

const mockStudents = [
  { id: 's1', name: 'John Doe', email: 'john@example.com', avatar: '/path/to/avatar1.jpg' },
  { id: 's2', name: 'Jane Smith', email: 'jane@example.com', avatar: '/path/to/avatar2.jpg' },
  { id: 's3', name: 'Alex Johnson', email: 'alex@example.com', avatar: '/path/to/avatar3.jpg' },
  { id: 's4', name: 'Maria Garcia', email: 'maria@example.com', avatar: '/path/to/avatar4.jpg' },
  { id: 's5', name: 'David Kim', email: 'david@example.com', avatar: '/path/to/avatar5.jpg' },
];

const NewMeetingPage: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const { user } = useAuth();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  
  // Form state
  const [meetingType, setMeetingType] = useState<'instant' | 'scheduled'>('instant');
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [startTime, setStartTime] = useState<Date | null>(new Date());
  const [duration, setDuration] = useState<number>(60);
  const [courseId, setCourseId] = useState<string>('');
  const [isRecurring, setIsRecurring] = useState(false);
  const [isPrivate, setIsPrivate] = useState(false);
  const [selectedStudents, setSelectedStudents] = useState<string[]>([]);
  const [meetingLink, setMeetingLink] = useState('');
  const [showLinkDialog, setShowLinkDialog] = useState(false);
  const [copied, setCopied] = useState(false);
  const [searchStudent, setSearchStudent] = useState('');
  const [showStudentList, setShowStudentList] = useState(false);
  
  // Initialize form with course ID from URL if provided
  useEffect(() => {
    const courseIdFromUrl = searchParams.get('courseId');
    if (courseIdFromUrl) {
      setCourseId(courseIdFromUrl);
      // In a real app, you would fetch the course details and pre-fill the title
      const course = mockCourses.find(c => c.id === courseIdFromUrl);
      if (course) {
        setTitle(`${course.name} - ${format(new Date(), 'MMM d, yyyy')}`);
      }
    } else {
      setTitle(`Meeting - ${format(new Date(), 'MMM d, yyyy')}`);
    }
  }, [searchParams]);
  
  // Generate a mock meeting link (in a real app, this would come from your backend)
  const generateMeetingLink = () => {
    const randomId = Math.random().toString(36).substring(2, 10);
    return `${window.location.origin}/meeting/${randomId}`;
  };
  
  // Handle form submission
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // In a real app, you would validate the form and send the data to your API
    console.log({
      title,
      description,
      startTime,
      duration,
      courseId,
      isRecurring,
      isPrivate,
      selectedStudents,
      meetingType,
    });
    
    // Generate a mock meeting link and show the dialog
    const link = generateMeetingLink();
    setMeetingLink(link);
    setShowLinkDialog(true);
  };
  
  // Handle copying the meeting link to clipboard
  const handleCopyLink = () => {
    navigator.clipboard.writeText(meetingLink);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };
  
  // Toggle student selection
  const toggleStudentSelection = (studentId: string) => {
    setSelectedStudents(prev => 
      prev.includes(studentId)
        ? prev.filter(id => id !== studentId)
        : [...prev, studentId]
    );
  };
  
  // Filter students based on search
  const filteredStudents = mockStudents.filter(student =>
    student.name.toLowerCase().includes(searchStudent.toLowerCase()) ||
    student.email.toLowerCase().includes(searchStudent.toLowerCase())
  );
  
  // Get the selected course
  const selectedCourse = courseId ? mockCourses.find(c => c.id === courseId) : null;
  
  return (
    <Box sx={{ maxWidth: 1200, mx: 'auto', p: isMobile ? 1 : 3 }}>
      {/* Header */}
      <Box sx={{ mb: 4, display: 'flex', alignItems: 'center' }}>
        <IconButton onClick={() => navigate(-1)} sx={{ mr: 2 }}>
          <ArrowBackIcon />
        </IconButton>
        <Typography variant="h4" component="h1">
          {meetingType === 'instant' ? 'Start Instant Meeting' : 'Schedule a Meeting'}
        </Typography>
      </Box>
      
      <Grid container spacing={3}>
        {/* Main form */}
        <Grid item xs={12} md={8}>
          <Paper elevation={0} sx={{ p: 3, mb: 3, borderRadius: 2 }}>
            <form onSubmit={handleSubmit}>
              {/* Meeting type toggle */}
              <Box sx={{ mb: 4, display: 'flex', gap: 2 }}>
                <Button
                  fullWidth
                  variant={meetingType === 'instant' ? 'contained' : 'outlined'}
                  startIcon={<VideoCallIcon />}
                  onClick={() => setMeetingType('instant')}
                  size="large"
                  sx={{
                    py: 1.5,
                    borderRadius: 2,
                    textTransform: 'none',
                    fontSize: '1rem',
                  }}
                >
                  Start an instant meeting
                </Button>
                <Button
                  fullWidth
                  variant={meetingType === 'scheduled' ? 'contained' : 'outlined'}
                  startIcon={<ScheduleIcon />}
                  onClick={() => setMeetingType('scheduled')}
                  size="large"
                  sx={{
                    py: 1.5,
                    borderRadius: 2,
                    textTransform: 'none',
                    fontSize: '1rem',
                  }}
                >
                  Schedule for later
                </Button>
              </Box>
              
              {/* Course selection */}
              <FormControl fullWidth sx={{ mb: 3 }}>
                <InputLabel id="course-select-label">Course (optional)</InputLabel>
                <Select
                  labelId="course-select-label"
                  id="course-select"
                  value={courseId}
                  label="Course (optional)"
                  onChange={(e) => setCourseId(e.target.value as string)}
                  startAdornment={
                    courseId ? (
                      <SchoolIcon sx={{ color: 'text.secondary', mr: 1 }} />
                    ) : null
                  }
                >
                  <MenuItem value="">
                    <em>None</em>
                  </MenuItem>
                  {mockCourses.map((course) => (
                    <MenuItem key={course.id} value={course.id}>
                      {course.name} ({course.code})
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
              
              {/* Title */}
              <TextField
                fullWidth
                label="Meeting title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
                sx={{ mb: 3 }}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <EventIcon color="action" />
                    </InputAdornment>
                  ),
                }}
              />
              
              {/* Description */}
              <TextField
                fullWidth
                label="Description (optional)"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                multiline
                rows={3}
                sx={{ mb: 3 }}
              />
              
              {/* Date and time (for scheduled meetings) */}
              {meetingType === 'scheduled' && (
                <LocalizationProvider dateAdapter={AdapterDateFns}>
                  <Grid container spacing={2} sx={{ mb: 3 }}>
                    <Grid item xs={12} sm={6}>
                      <DateTimePicker
                        label="Start time"
                        value={startTime}
                        onChange={(newValue) => setStartTime(newValue)}
                        minDateTime={new Date()}
                        renderInput={(params) => (
                          <TextField 
                            {...params} 
                            fullWidth 
                            required 
                            InputProps={{
                              startAdornment: (
                                <InputAdornment position="start">
                                  <AccessTimeIcon color="action" />
                                </InputAdornment>
                              ),
                            }}
                          />
                        )}
                      />
                    </Grid>
                    <Grid item xs={12} sm={6}>
                      <FormControl fullWidth>
                        <InputLabel id="duration-label">Duration</InputLabel>
                        <Select
                          labelId="duration-label"
                          id="duration"
                          value={duration}
                          label="Duration"
                          onChange={(e) => setDuration(Number(e.target.value))}
                        >
                          <MenuItem value={15}>15 minutes</MenuItem>
                          <MenuItem value={30}>30 minutes</MenuItem>
                          <MenuItem value={60}>1 hour</MenuItem>
                          <MenuItem value={90}>1.5 hours</MenuItem>
                          <MenuItem value={120}>2 hours</MenuItem>
                          <MenuItem value={180}>3 hours</MenuItem>
                        </Select>
                      </FormControl>
                    </Grid>
                  </Grid>
                  
                  {/* Recurring meeting option */}
                  <FormGroup sx={{ mb: 3 }}>
                    <FormControlLabel 
                      control={
                        <Switch 
                          checked={isRecurring} 
                          onChange={(e) => setIsRecurring(e.target.checked)} 
                        />
                      } 
                      label="Recurring meeting" 
                    />
                    {isRecurring && (
                      <Box sx={{ mt: 1, ml: 4 }}>
                        <Typography variant="body2" color="text.secondary" gutterBottom>
                          Recurrence options will be available after saving.
                        </Typography>
                      </Box>
                    )}
                  </FormGroup>
                </LocalizationProvider>
              )}
              
              {/* Privacy settings */}
              <Box sx={{ mb: 4, p: 2, bgcolor: 'action.hover', borderRadius: 1 }}>
                <FormGroup>
                  <FormControlLabel 
                    control={
                      <Switch 
                        checked={isPrivate} 
                        onChange={(e) => setIsPrivate(e.target.checked)} 
                      />
                    } 
                    label={
                      <Box display="flex" alignItems="center">
                        {isPrivate ? <LockIcon fontSize="small" sx={{ mr: 1 }} /> : <LockOpenIcon fontSize="small" sx={{ mr: 1 }} />}
                        <span>{isPrivate ? 'Private meeting' : 'Public meeting'}</span>
                      </Box>
                    } 
                  />
                  <Typography variant="body2" color="text.secondary" sx={{ mt: 1, ml: 4 }}>
                    {isPrivate 
                      ? 'Only invited participants can join this meeting.' 
                      : 'Anyone with the link can join this meeting.'}
                  </Typography>
                </FormGroup>
              </Box>
              
              {/* Invite participants */}
              <Box sx={{ mb: 4 }}>
                <Typography variant="h6" gutterBottom>
                  Invite Participants
                </Typography>
                <Typography variant="body2" color="text.secondary" gutterBottom>
                  {selectedStudents.length > 0 
                    ? `${selectedStudents.length} participant${selectedStudents.length > 1 ? 's' : ''} selected`
                    : 'Select participants to invite (optional)'}
                </Typography>
                
                {/* Selected participants chips */}
                <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 1, mb: 2 }}>
                  {selectedStudents.map(studentId => {
                    const student = mockStudents.find(s => s.id === studentId);
                    return student ? (
                      <Chip
                        key={studentId}
                        avatar={<Avatar src={student.avatar} alt={student.name} />}
                        label={student.name}
                        onDelete={() => toggleStudentSelection(studentId)}
                        sx={{ borderRadius: 1 }}
                      />
                    ) : null;
                  })}
                </Box>
                
                {/* Search and select students */}
                <Box position="relative">
                  <TextField
                    fullWidth
                    variant="outlined"
                    placeholder="Search students..."
                    value={searchStudent}
                    onChange={(e) => setSearchStudent(e.target.value)}
                    onFocus={() => setShowStudentList(true)}
                    InputProps={{
                      startAdornment: (
                        <InputAdornment position="start">
                          <PersonAddIcon color="action" />
                        </InputAdornment>
                      ),
                    }}
                  />
                  
                  {/* Student list dropdown */}
                  {showStudentList && (
                    <Paper 
                      elevation={3} 
                      sx={{
                        position: 'absolute',
                        width: '100%',
                        maxHeight: 300,
                        overflowY: 'auto',
                        mt: 0.5,
                        zIndex: 10,
                      }}
                    >
                      <List dense>
                        {filteredStudents.length > 0 ? (
                          filteredStudents.map((student) => (
                            <ListItem 
                              key={student.id}
                              button
                              onClick={() => toggleStudentSelection(student.id)}
                              sx={{ borderRadius: 1 }}
                            >
                              <Checkbox
                                edge="start"
                                checked={selectedStudents.includes(student.id)}
                                tabIndex={-1}
                                disableRipple
                              />
                              <ListItemAvatar>
                                <Avatar src={student.avatar} alt={student.name} />
                              </ListItemAvatar>
                              <ListItemText 
                                primary={student.name} 
                                secondary={student.email} 
                              />
                            </ListItem>
                          ))
                        ) : (
                          <ListItem>
                            <ListItemText 
                              primary="No students found" 
                              primaryTypographyProps={{ color: 'text.secondary' }}
                            />
                          </ListItem>
                        )}
                      </List>
                    </Paper>
                  )}
                </Box>
                
                {/* Click away listener to close dropdown */}
                {showStudentList && (
                  <Box
                    position="fixed"
                    top={0}
                    left={0}
                    right={0}
                    bottom={0}
                    zIndex={9}
                    onClick={() => setShowStudentList(false)}
                  />
                )}
              </Box>
              
              {/* Submit button */}
              <Box sx={{ mt: 4, display: 'flex', justifyContent: 'flex-end' }}>
                <Button
                  type="submit"
                  variant="contained"
                  color="primary"
                  size="large"
                  startIcon={<VideoCallIcon />}
                  sx={{ minWidth: 200 }}
                >
                  {meetingType === 'instant' ? 'Start Meeting' : 'Schedule Meeting'}
                </Button>
              </Box>
            </form>
          </Paper>
          
          {/* Meeting tips */}
          <Paper elevation={0} sx={{ p: 3, borderRadius: 2, bgcolor: 'action.hover' }}>
            <Typography variant="h6" gutterBottom>
              Tips for a great meeting
            </Typography>
            <ul style={{ paddingLeft: 20, margin: 0 }}>
              <li style={{ marginBottom: 8 }}>
                <Typography variant="body2">
                  <strong>Test your setup</strong> - Check your camera, microphone, and speakers before joining.
                </Typography>
              </li>
              <li style={{ marginBottom: 8 }}>
                <Typography variant="body2">
                  <strong>Use a wired connection</strong> - For the best video quality, connect to the internet with an Ethernet cable.
                </Typography>
              </li>
              <li>
                <Typography variant="body2">
                  <strong>Mute your microphone</strong> - When you're not speaking to reduce background noise.
                </Typography>
              </li>
            </ul>
          </Paper>
        </Grid>
        
        {/* Sidebar */}
        <Grid item xs={12} md={4}>
          <Paper elevation={0} sx={{ p: 3, borderRadius: 2, position: 'sticky', top: 20 }}>
            <Typography variant="h6" gutterBottom>
              Meeting Summary
            </Typography>
            
            <Box sx={{ mb: 3 }}>
              <Typography variant="subtitle2" color="text.secondary">
                MEETING TITLE
              </Typography>
              <Typography variant="body1" sx={{ wordBreak: 'break-word' }}>
                {title || 'Untitled Meeting'}
              </Typography>
            </Box>
            
            <Box sx={{ mb: 3 }}>
              <Typography variant="subtitle2" color="text.secondary">
                WHEN
              </Typography>
              <Typography variant="body1">
                {meetingType === 'instant' 
                  ? 'Starts now' 
                  : startTime 
                    ? format(startTime, 'EEEE, MMMM d, yyyy h:mm a')
                    : 'No date selected'}
              </Typography>
              {meetingType === 'scheduled' && startTime && (
                <Typography variant="body2" color="text.secondary">
                  {format(addMinutes(startTime, duration), 'h:mm a')} • {duration} min
                </Typography>
              )}
            </Box>
            
            {selectedCourse && (
              <Box sx={{ mb: 3 }}>
                <Typography variant="subtitle2" color="text.secondary">
                  COURSE
                </Typography>
                <Box sx={{ display: 'flex', alignItems: 'center', mt: 1 }}>
                  <Avatar sx={{ bgcolor: 'primary.main', mr: 1 }}>
                    <SchoolIcon />
                  </Avatar>
                  <div>
                    <Typography variant="body1">{selectedCourse.name}</Typography>
                    <Typography variant="body2" color="text.secondary">
                      {selectedCourse.code}
                    </Typography>
                  </div>
                </Box>
              </Box>
            )}
            
            <Box sx={{ mb: 3 }}>
              <Typography variant="subtitle2" color="text.secondary">
                PRIVACY
              </Typography>
              <Box sx={{ display: 'flex', alignItems: 'center', mt: 1 }}>
                {isPrivate ? (
                  <>
                    <LockIcon color="action" sx={{ mr: 1 }} />
                    <Typography>Private meeting</Typography>
                  </>
                ) : (
                  <>
                    <LockOpenIcon color="action" sx={{ mr: 1 }} />
                    <Typography>Public meeting</Typography>
                  </>
                )}
              </Box>
            </Box>
            
            <Divider sx={{ my: 2 }} />
            
            <Box>
              <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                PARTICIPANTS
              </Typography>
              <List dense>
                <ListItem sx={{ px: 0 }}>
                  <ListItemAvatar>
                    <Avatar src={user?.avatar} alt={user?.name}>
                      {user?.name?.charAt(0) || <PersonIcon />}
                    </Avatar>
                  </ListItemAvatar>
                  <ListItemText 
                    primary={user?.name || 'You'} 
                    secondary="Organizer" 
                    secondaryTypographyProps={{ variant: 'body2' }}
                  />
                </ListItem>
                
                {selectedStudents.length > 0 ? (
                  selectedStudents.map(studentId => {
                    const student = mockStudents.find(s => s.id === studentId);
                    return student ? (
                      <ListItem key={studentId} sx={{ px: 0 }}>
                        <ListItemAvatar>
                          <Avatar src={student.avatar} alt={student.name}>
                            {student.name.charAt(0)}
                          </Avatar>
                        </ListItemAvatar>
                        <ListItemText 
                          primary={student.name} 
                          secondary={student.email}
                          secondaryTypographyProps={{ variant: 'body2' }}
                        />
                      </ListItem>
                    ) : null;
                  })
                ) : (
                  <Typography variant="body2" color="text.secondary" sx={{ fontStyle: 'italic' }}>
                    No participants added yet
                  </Typography>
                )}
              </List>
            </Box>
          </Paper>
        </Grid>
      </Grid>
      
      {/* Meeting link dialog */}
      <Dialog open={showLinkDialog} onClose={() => setShowLinkDialog(false)} maxWidth="sm" fullWidth>
        <DialogTitle>
          <Box display="flex" justifyContent="space-between" alignItems="center">
            <span>Your meeting is ready</span>
            <IconButton onClick={() => setShowLinkDialog(false)}>
              <CloseIcon />
            </IconButton>
          </Box>
        </DialogTitle>
        <DialogContent>
          <Alert 
            severity="success" 
            sx={{ mb: 3 }}
            action={
              <Button 
                color="inherit" 
                size="small" 
                onClick={() => navigate(meetingLink.replace(window.location.origin, ''))}
              >
                Join Now
              </Button>
            }
          >
            <AlertTitle>Meeting created successfully</AlertTitle>
            Your {meetingType === 'instant' ? 'meeting has started' : 'meeting has been scheduled'}.
          </Alert>
          
          <Typography variant="subtitle1" gutterBottom>
            Share this link with participants
          </Typography>
          
          <Box sx={{ display: 'flex', mb: 2 }}>
            <TextField
              fullWidth
              variant="outlined"
              value={meetingLink}
              InputProps={{
                readOnly: true,
                startAdornment: (
                  <InputAdornment position="start">
                    <LinkIcon color="action" />
                  </InputAdornment>
                ),
              }}
              sx={{ 
                '& .MuiOutlinedInput-root': {
                  borderTopRightRadius: 0,
                  borderBottomRightRadius: 0,
                },
              }}
            />
            <Button
              variant="contained"
              onClick={handleCopyLink}
              startIcon={copied ? <CheckIcon /> : <ContentCopyIcon />}
              sx={{
                borderTopLeftRadius: 0,
                borderBottomLeftRadius: 0,
                minWidth: 'auto',
                px: 2,
              }}
            >
              {copied ? 'Copied!' : 'Copy'}
            </Button>
          </Box>
          
          <Typography variant="body2" color="text.secondary">
            Participants can join using the link above. You can also invite them by email.
          </Typography>
        </DialogContent>
        <DialogActions sx={{ p: 2, pt: 0 }}>
          <Button onClick={() => setShowLinkDialog(false)}>Close</Button>
          <Button 
            variant="contained" 
            color="primary" 
            onClick={() => navigate(meetingLink.replace(window.location.origin, ''))}
            startIcon={<VideoCallIcon />}
          >
            Join Meeting
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default NewMeetingPage;
