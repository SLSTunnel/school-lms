import React, { useState, useEffect } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import {
  Box,
  Typography,
  Paper,
  Button,
  IconButton,
  Avatar,
  List,
  ListItem,
  ListItemAvatar,
  ListItemText,
  Divider,
  Chip,
  Tabs,
  Tab,
  TextField,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  Menu,
  MenuItem,
  CircularProgress,
  Alert,
  useTheme,
  useMediaQuery,
} from '@mui/material';
import {
  ArrowBack as ArrowBackIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  MoreVert as MoreVertIcon,
  PersonAdd as PersonAddIcon,
  Link as LinkIcon,
  ContentCopy as ContentCopyIcon,
  Check as CheckIcon,
  Videocam as VideoIcon,
  Schedule as ScheduleIcon,
  School as SchoolIcon,
  Person as PersonIcon,
  Group as GroupIcon,
  AccessTime as AccessTimeIcon,
  Event as EventIcon,
  Chat as ChatIcon,
  FileCopy as FileCopyIcon,
  Email as EmailIcon,
  CalendarToday as CalendarTodayIcon,
} from '@mui/icons-material';
import { format, formatDistanceToNow, isBefore, isAfter, parseISO } from 'date-fns';
import { useAuth } from '../../contexts/AuthContext';

// Mock data - replace with actual API calls
const mockMeeting = {
  id: 'meet123',
  title: 'Math 101 - Weekly Discussion',
  description: 'Weekly discussion session for Math 101 students. We will go over the latest assignment and prepare for the upcoming quiz.',
  startTime: new Date(Date.now() + 1000 * 60 * 60 * 24).toISOString(), // Tomorrow
  duration: 60, // minutes
  course: {
    id: 'math101',
    name: 'Introduction to Calculus',
    code: 'MATH-101',
  },
  isRecurring: true,
  recurrence: 'WEEKLY',
  isPrivate: false,
  meetingLink: 'https://meet.example.com/abc123',
  meetingId: 'abc123',
  meetingPassword: '123456',
  organizer: {
    id: 't1',
    name: 'Dr. Smith',
    email: 'smith@example.com',
    avatar: '',
  },
  participants: [
    { id: 's1', name: 'John Doe', email: 'john@example.com', avatar: '', status: 'accepted' },
    { id: 's2', name: 'Jane Smith', email: 'jane@example.com', avatar: '', status: 'accepted' },
    { id: 's3', name: 'Alex Johnson', email: 'alex@example.com', avatar: '', status: 'pending' },
  ],
  createdAt: new Date(Date.now() - 1000 * 60 * 60 * 24 * 2).toISOString(), // 2 days ago
  updatedAt: new Date(Date.now() - 1000 * 60 * 60).toISOString(), // 1 hour ago
};

const MeetingDetailsPage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  
  // State
  const [activeTab, setActiveTab] = useState(0);
  const [meeting, setMeeting] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState<Record<string, boolean>>({});
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [cancelDialogOpen, setCancelDialogOpen] = useState(false);
  
  // Fetch meeting details
  useEffect(() => {
    const fetchMeeting = async () => {
      try {
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 800));
        setMeeting(mockMeeting);
        setLoading(false);
      } catch (err) {
        setError('Failed to load meeting details. Please try again.');
        setLoading(false);
        console.error('Error fetching meeting:', err);
      }
    };
    
    fetchMeeting();
  }, [id]);
  
  // Handle tab change
  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setActiveTab(newValue);
  };
  
  // Handle menu open
  const handleMenuOpen = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };
  
  // Handle menu close
  const handleMenuClose = () => {
    setAnchorEl(null);
  };
  
  // Handle copy to clipboard
  const handleCopy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopied(prev => ({ ...prev, [key]: true }));
    setTimeout(() => {
      setCopied(prev => ({ ...prev, [key]: false }));
    }, 2000);
  };
  
  // Handle delete meeting
  const handleDeleteMeeting = () => {
    // In a real app, you would call an API to delete the meeting
    console.log('Deleting meeting:', id);
    setDeleteDialogOpen(false);
    handleMenuClose();
    // Navigate back after a short delay to show feedback
    setTimeout(() => {
      navigate('/communication/meetings');
    }, 1000);
  };
  
  // Handle cancel meeting
  const handleCancelMeeting = () => {
    // In a real app, you would call an API to cancel the meeting
    console.log('Canceling meeting:', id);
    setCancelDialogOpen(false);
    // Update meeting status
    setMeeting((prev: any) => ({
      ...prev,
      status: 'cancelled',
    }));
  };
  
  // Handle join meeting
  const handleJoinMeeting = () => {
    // In a real app, this would navigate to the meeting URL
    window.open(meeting.meetingLink, '_blank');
  };
  
  // Format date and time
  const formatDateTime = (dateString: string) => {
    const date = parseISO(dateString);
    return {
      date: format(date, 'EEEE, MMMM d, yyyy'),
      time: format(date, 'h:mm a'),
      relative: formatDistanceToNow(date, { addSuffix: true }),
    };
  };
  
  // Check if meeting is in the past
  const isPastMeeting = meeting && isBefore(parseISO(meeting.startTime), new Date());
  
  // Check if meeting is happening now (within the scheduled duration)
  const isHappeningNow = meeting && 
    isAfter(new Date(), parseISO(meeting.startTime)) && 
    isBefore(new Date(), new Date(new Date(meeting.startTime).getTime() + meeting.duration * 60 * 1000));
  
  // Loading state
  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="60vh">
        <CircularProgress />
      </Box>
    );
  }
  
  // Error state
  if (error) {
    return (
      <Box p={3}>
        <Alert severity="error" sx={{ mb: 2 }}>
          {error}
        </Alert>
        <Button 
          variant="contained" 
          color="primary" 
          onClick={() => window.location.reload()}
        >
          Retry
        </Button>
      </Box>
    );
  }
  
  // Meeting not found
  if (!meeting) {
    return (
      <Box p={3} textAlign="center">
        <Typography variant="h5" gutterBottom>
          Meeting not found
        </Typography>
        <Typography color="text.secondary" paragraph>
          The meeting you're looking for doesn't exist or you don't have permission to view it.
        </Typography>
        <Button 
          variant="contained" 
          color="primary" 
          component={Link} 
          to="/communication/meetings"
        >
          Back to Meetings
        </Button>
      </Box>
    );
  }
  
  const { 
    title, 
    description, 
    startTime, 
    duration, 
    course, 
    isRecurring, 
    isPrivate, 
    meetingLink, 
    meetingId, 
    meetingPassword,
    organizer,
    participants,
    status
  } = meeting;
  
  const formattedStart = formatDateTime(startTime);
  const endTime = new Date(new Date(startTime).getTime() + duration * 60 * 1000);
  
  return (
    <Box>
      {/* Header */}
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Box display="flex" alignItems="center">
          <IconButton 
            onClick={() => navigate(-1)} 
            sx={{ mr: 1 }}
            aria-label="go back"
          >
            <ArrowBackIcon />
          </IconButton>
          <Typography variant="h4" component="h1">
            {title}
          </Typography>
          
          {status === 'cancelled' && (
            <Chip 
              label="Cancelled" 
              color="error" 
              size="small" 
              sx={{ ml: 2, alignSelf: 'center' }}
            />
          )}
          
          {isHappeningNow && !isPastMeeting && status !== 'cancelled' && (
            <Chip 
              label="Happening Now" 
              color="success" 
              size="small" 
              sx={{ 
                ml: 2, 
                alignSelf: 'center',
                color: 'white',
                fontWeight: 'bold',
              }}
            />
          )}
        </Box>
        
        <Box>
          {status !== 'cancelled' && (
            <Button
              variant="contained"
              color="primary"
              startIcon={<VideoIcon />}
              onClick={handleJoinMeeting}
              disabled={isPastMeeting}
              sx={{ mr: 1 }}
            >
              {isPastMeeting ? 'Meeting Ended' : 'Join Meeting'}
            </Button>
          )}
          
          <IconButton onClick={handleMenuOpen} aria-label="more options">
            <MoreVertIcon />
          </IconButton>
          
          <Menu
            anchorEl={anchorEl}
            open={Boolean(anchorEl)}
            onClose={handleMenuClose}
            anchorOrigin={{
              vertical: 'bottom',
              horizontal: 'right',
            }}
            transformOrigin={{
              vertical: 'top',
              horizontal: 'right',
            }}
          >
            <MenuItem 
              onClick={() => {
                navigate(`/communication/meetings/edit/${id}`);
                handleMenuClose();
              }}
              disabled={isPastMeeting || status === 'cancelled'}
            >
              <EditIcon fontSize="small" sx={{ mr: 1 }} />
              Edit Meeting
            </MenuItem>
            <MenuItem 
              onClick={() => {
                setCancelDialogOpen(true);
                handleMenuClose();
              }}
              disabled={isPastMeeting || status === 'cancelled'}
            >
              <ScheduleIcon fontSize="small" sx={{ mr: 1 }} />
              Cancel Meeting
            </MenuItem>
            <Divider />
            <MenuItem 
              onClick={() => {
                handleCopy(meetingLink, 'link');
                handleMenuClose();
              }}
            >
              <LinkIcon fontSize="small" sx={{ mr: 1 }} />
              Copy Meeting Link
            </MenuItem>
            <MenuItem 
              onClick={() => {
                handleCopy(meetingId, 'id');
                handleMenuClose();
              }}
            >
              <ContentCopyIcon fontSize="small" sx={{ mr: 1 }} />
              Copy Meeting ID
            </MenuItem>
            {meetingPassword && (
              <MenuItem 
                onClick={() => {
                  handleCopy(meetingPassword, 'password');
                  handleMenuClose();
                }}
              >
                <ContentCopyIcon fontSize="small" sx={{ mr: 1 }} />
                Copy Password
              </MenuItem>
            )}
            <Divider />
            <MenuItem 
              onClick={() => {
                setDeleteDialogOpen(true);
                handleMenuClose();
              }}
              sx={{ color: 'error.main' }}
            >
              <DeleteIcon fontSize="small" sx={{ mr: 1 }} />
              Delete Meeting
            </MenuItem>
          </Menu>
        </Box>
      </Box>
      
      {/* Main content */}
      <Grid container spacing={3}>
        {/* Left column - Meeting details */}
        <Grid item xs={12} md={8}>
          <Paper elevation={0} sx={{ p: 3, mb: 3, borderRadius: 2 }}>
            <Tabs 
              value={activeTab} 
              onChange={handleTabChange} 
              sx={{ mb: 3 }}
              variant="scrollable"
              scrollButtons="auto"
            >
              <Tab label="Details" />
              <Tab label="Participants" />
              <Tab label="Chat" />
              <Tab label="Recordings" />
            </Tabs>
            
            {activeTab === 0 && (
              <Box>
                <Typography variant="h6" gutterBottom>
                  About This Meeting
                </Typography>
                <Typography variant="body1" paragraph>
                  {description || 'No description provided.'}
                </Typography>
                
                <Divider sx={{ my: 3 }} />
                
                <Grid container spacing={3}>
                  <Grid item xs={12} sm={6}>
                    <Box display="flex" alignItems="flex-start" mb={2}>
                      <EventIcon color="action" sx={{ mr: 2, mt: 0.5 }} />
                      <div>
                        <Typography variant="subtitle2" color="text.secondary">
                          Date & Time
                        </Typography>
                        <Typography variant="body1">
                          {formattedStart.date}
                        </Typography>
                        <Typography variant="body2" color="text.secondary">
                          {formattedStart.time} - {format(endTime, 'h:mm a')} • {duration} min
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          {formattedStart.relative}
                        </Typography>
                      </div>
                    </Box>
                    
                    <Box display="flex" alignItems="flex-start" mb={2}>
                      <SchoolIcon color="action" sx={{ mr: 2, mt: 0.5 }} />
                      <div>
                        <Typography variant="subtitle2" color="text.secondary">
                          Course
                        </Typography>
                        <Typography variant="body1">
                          {course.name} ({course.code})
                        </Typography>
                      </div>
                    </Box>
                    
                    <Box display="flex" alignItems="flex-start" mb={2}>
                      <PersonIcon color="action" sx={{ mr: 2, mt: 0.5 }} />
                      <div>
                        <Typography variant="subtitle2" color="text.secondary">
                          Organizer
                        </Typography>
                        <Typography variant="body1">
                          {organizer.name}
                        </Typography>
                      </div>
                    </Box>
                  </Grid>
                  
                  <Grid item xs={12} sm={6}>
                    <Box display="flex" alignItems="flex-start" mb={2}>
                      <GroupIcon color="action" sx={{ mr: 2, mt: 0.5 }} />
                      <div>
                        <Typography variant="subtitle2" color="text.secondary">
                          Participants
                        </Typography>
                        <Typography variant="body1">
                          {participants.length + 1} people
                        </Typography>
                      </div>
                    </Box>
                    
                    <Box display="flex" alignItems="flex-start" mb={2}>
                      <AccessTimeIcon color="action" sx={{ mr: 2, mt: 0.5 }} />
                      <div>
                        <Typography variant="subtitle2" color="text.secondary">
                          Meeting Type
                        </Typography>
                        <Typography variant="body1">
                          {isRecurring ? 'Recurring' : 'One-time'}
                          {isRecurring && ` (${meeting.recurency || 'Weekly'})`}
                        </Typography>
                      </div>
                    </Box>
                    
                    <Box display="flex" alignItems="flex-start">
                      {isPrivate ? (
                        <LockIcon color="action" sx={{ mr: 2, mt: 0.5 }} />
                      ) : (
                        <LockOpenIcon color="action" sx={{ mr: 2, mt: 0.5 }} />
                      )}
                      <div>
                        <Typography variant="subtitle2" color="text.secondary">
                          Privacy
                        </Typography>
                        <Typography variant="body1">
                          {isPrivate ? 'Private' : 'Public'}
                        </Typography>
                        <Typography variant="caption" color="text.secondary">
                          {isPrivate 
                            ? 'Only invited participants can join' 
                            : 'Anyone with the link can join'}
                        </Typography>
                      </div>
                    </Box>
                  </Grid>
                </Grid>
                
                <Divider sx={{ my: 3 }} />
                
                <Box>
                  <Typography variant="h6" gutterBottom>
                    Meeting Link
                  </Typography>
                  <Box display="flex" alignItems="center" mb={2}>
                    <TextField
                      fullWidth
                      variant="outlined"
                      value={meetingLink}
                      InputProps={{
                        readOnly: true,
                        startAdornment: (
                          <InputAdornment position="start">
                            <LinkIcon color="action" />
                          </InputAdornment>
                        ),
                      }}
                      sx={{ 
                        '& .MuiOutlinedInput-root': {
                          borderTopRightRadius: 0,
                          borderBottomRightRadius: 0,
                        },
                      }}
                    />
                    <Button
                      variant="contained"
                      onClick={() => handleCopy(meetingLink, 'link')}
                      startIcon={copied['link'] ? <CheckIcon /> : <ContentCopyIcon />}
                      sx={{
                        borderTopLeftRadius: 0,
                        borderBottomLeftRadius: 0,
                        minWidth: 'auto',
                        px: 2,
                        height: '56px',
                      }}
                    >
                      {copied['link'] ? 'Copied!' : 'Copy'}
                    </Button>
                  </Box>
                  
                  <Grid container spacing={2}>
                    <Grid item xs={12} sm={6}>
                      <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                        Meeting ID
                      </Typography>
                      <Box display="flex" alignItems="center" mb={2}>
                        <TextField
                          fullWidth
                          variant="outlined"
                          value={meetingId}
                          InputProps={{
                            readOnly: true,
                          }}
                          sx={{ 
                            '& .MuiOutlinedInput-root': {
                              borderTopRightRadius: 0,
                              borderBottomRightRadius: 0,
                            },
                          }}
                        />
                        <Button
                          variant="outlined"
                          onClick={() => handleCopy(meetingId, 'id')}
                          startIcon={copied['id'] ? <CheckIcon /> : <ContentCopyIcon />}
                          sx={{
                            borderTopLeftRadius: 0,
                            borderBottomLeftRadius: 0,
                            minWidth: 'auto',
                            px: 2,
                            height: '56px',
                          }}
                        >
                          {copied['id'] ? 'Copied!' : 'Copy'}
                        </Button>
                      </Box>
                    </Grid>
                    
                    {meetingPassword && (
                      <Grid item xs={12} sm={6}>
                        <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                          Password
                        </Typography>
                        <Box display="flex" alignItems="center">
                          <TextField
                            fullWidth
                            variant="outlined"
                            type="password"
                            value={meetingPassword}
                            InputProps={{
                              readOnly: true,
                            }}
                            sx={{ 
                              '& .MuiOutlinedInput-root': {
                                borderTopRightRadius: 0,
                                borderBottomRightRadius: 0,
                              },
                            }}
                          />
                          <Button
                            variant="outlined"
                            onClick={() => handleCopy(meetingPassword, 'password')}
                            startIcon={copied['password'] ? <CheckIcon /> : <ContentCopyIcon />}
                            sx={{
                              borderTopLeftRadius: 0,
                              borderBottomLeftRadius: 0,
                              minWidth: 'auto',
                              px: 2,
                              height: '56px',
                            }}
                          >
                            {copied['password'] ? 'Copied!' : 'Copy'}
                          </Button>
                        </Box>
                      </Grid>
                    )}
                  </Grid>
                </Box>
              </Box>
            )}
            
            {activeTab === 1 && (
              <Box>
                <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
                  <Typography variant="h6">
                    Participants ({participants.length + 1})
                  </Typography>
                  <Button 
                    variant="outlined" 
                    startIcon={<PersonAddIcon />}
                    onClick={() => console.log('Add participants')}
                  >
                    Add
                  </Button>
                </Box>
                
                <List>
                  {/* Organizer */}
                  <ListItem>
                    <ListItemAvatar>
                      <Avatar src={organizer.avatar}>
                        {organizer.name.charAt(0)}
                      </Avatar>
                    </ListItemAvatar>
                    <ListItemText 
                      primary={
                        <Box display="flex" alignItems="center">
                          {organizer.name}
                          <Chip 
                            label="Organizer" 
                            size="small" 
                            color="primary" 
                            variant="outlined"
                            sx={{ ml: 1, fontSize: '0.7rem' }}
                          />
                        </Box>
                      }
                      secondary={organizer.email}
                    />
                  </ListItem>
                  
                  <Divider variant="inset" component="li" />
                  
                  {/* Participants */}
                  {participants.map((participant: any) => (
                    <React.Fragment key={participant.id}>
                      <ListItem>
                        <ListItemAvatar>
                          <Avatar src={participant.avatar}>
                            {participant.name.charAt(0)}
                          </Avatar>
                        </ListItemAvatar>
                        <ListItemText 
                          primary={participant.name}
                          secondary={
                            <Box component="span" display="flex" alignItems="center">
                              {participant.email}
                              {participant.status === 'pending' && (
                                <Chip 
                                  label="Pending" 
                                  size="small" 
                                  color="warning" 
                                  variant="outlined"
                                  sx={{ ml: 1, fontSize: '0.7rem' }}
                                />
                              )}
                              {participant.status === 'accepted' && (
                                <Chip 
                                  label="Accepted" 
                                  size="small" 
                                  color="success" 
                                  variant="outlined"
                                  sx={{ ml: 1, fontSize: '0.7rem' }}
                                />
                              )}
                            </Box>
                          }
                        />
                        <IconButton edge="end" aria-label="remove">
                          <DeleteIcon fontSize="small" />
                        </IconButton>
                      </ListItem>
                      <Divider variant="inset" component="li" />
                    </React.Fragment>
                  ))}
                </List>
              </Box>
            )}
            
            {activeTab === 2 && (
              <Box textAlign="center" py={4}>
                <ChatIcon color="action" sx={{ fontSize: 48, mb: 2 }} />
                <Typography variant="h6" gutterBottom>
                  Meeting Chat
                </Typography>
                <Typography color="text.secondary" paragraph>
                  Chat history will appear here during and after the meeting.
                </Typography>
                <Button 
                  variant="outlined" 
                  startIcon={<ChatIcon />}
                  onClick={() => console.log('Open chat')}
                >
                  Open Chat
                </Button>
              </Box>
            )}
            
            {activeTab === 3 && (
              <Box textAlign="center" py={4}>
                <FileCopyIcon color="action" sx={{ fontSize: 48, mb: 2 }} />
                <Typography variant="h6" gutterBottom>
                  Recordings
                </Typography>
                <Typography color="text.secondary" paragraph>
                  {isPastMeeting 
                    ? 'No recordings available for this meeting.'
                    : 'Recordings will appear here after the meeting ends.'
                  }
                </Typography>
                {isPastMeeting && (
                  <Button 
                    variant="outlined" 
                    startIcon={<EmailIcon />}
                    onClick={() => console.log('Request recording')}
                  >
                    Request Recording
                  </Button>
                )}
              </Box>
            )}
          </Paper>
        </Grid>
        
        {/* Right column - Actions and info */}
        <Grid item xs={12} md={4}>
          <Paper elevation={0} sx={{ p: 3, mb: 3, borderRadius: 2, position: 'sticky', top: 20 }}>
            <Typography variant="h6" gutterBottom>
              Meeting Actions
            </Typography>
            
            <Button
              fullWidth
              variant="contained"
              color="primary"
              size="large"
              startIcon={<VideoIcon />}
              onClick={handleJoinMeeting}
              disabled={isPastMeeting || status === 'cancelled'}
              sx={{ mb: 2 }}
            >
              {isPastMeeting 
                ? 'Meeting Ended' 
                : status === 'cancelled'
                  ? 'Meeting Cancelled'
                  : isHappeningNow
                    ? 'Join Now'
                    : 'Join Meeting'}
            </Button>
            
            <Button
              fullWidth
              variant="outlined"
              size="large"
              startIcon={<CalendarTodayIcon />}
              onClick={() => console.log('Add to calendar')}
              sx={{ mb: 2 }}
            >
              Add to Calendar
            </Button>
            
            <Button
              fullWidth
              variant="outlined"
              size="large"
              startIcon={<EmailIcon />}
              onClick={() => console.log('Email invite')}
              sx={{ mb: 2 }}
            >
              Email Invite
            </Button>
            
            <Divider sx={{ my: 2 }} />
            
            <Typography variant="subtitle2" color="text.secondary" gutterBottom>
              MEETING LINK
            </Typography>
            <Box display="flex" alignItems="center" mb={2}>
              <TextField
                fullWidth
                variant="outlined"
                size="small"
                value={meetingLink}
                InputProps={{
                  readOnly: true,
                  startAdornment: (
                    <InputAdornment position="start">
                      <LinkIcon fontSize="small" color="action" />
                    </InputAdornment>
                  ),
                }}
                sx={{ 
                  '& .MuiOutlinedInput-root': {
                    borderTopRightRadius: 0,
                    borderBottomRightRadius: 0,
                  },
                  '& .MuiOutlinedInput-input': {
                    py: 1,
                    fontSize: '0.875rem',
                  },
                }}
              />
              <Button
                variant="outlined"
                size="small"
                onClick={() => handleCopy(meetingLink, 'linkSidebar')}
                sx={{
                  borderTopLeftRadius: 0,
                  borderBottomLeftRadius: 0,
                  minWidth: 'auto',
                  px: 1,
                  height: '40px',
                }}
              >
                {copied['linkSidebar'] ? 'Copied!' : 'Copy'}
              </Button>
            </Box>
            
            <Divider sx={{ my: 2 }} />
            
            <Typography variant="subtitle2" color="text.secondary" gutterBottom>
              NEED HELP?
            </Typography>
            <Button
              fullWidth
              variant="text"
              size="small"
              onClick={() => console.log('Get help')}
              sx={{ justifyContent: 'flex-start', pl: 1, mb: 1 }}
            >
              Meeting Help Center
            </Button>
            <Button
              fullWidth
              variant="text"
              size="small"
              onClick={() => console.log('Contact support')}
              sx={{ justifyContent: 'flex-start', pl: 1 }}
            >
              Contact Support
            </Button>
          </Paper>
        </Grid>
      </Grid>
      
      {/* Delete confirmation dialog */}
      <Dialog
        open={deleteDialogOpen}
        onClose={() => setDeleteDialogOpen(false)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>Delete Meeting</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Are you sure you want to delete this meeting? This action cannot be undone and will 
            notify all participants that the meeting has been cancelled.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteDialogOpen(false)}>Cancel</Button>
          <Button 
            onClick={handleDeleteMeeting} 
            color="error"
            variant="contained"
          >
            Delete
          </Button>
        </DialogActions>
      </Dialog>
      
      {/* Cancel meeting dialog */}
      <Dialog
        open={cancelDialogOpen}
        onClose={() => setCancelDialogOpen(false)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>Cancel Meeting</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Are you sure you want to cancel this meeting? This will notify all participants 
            that the meeting has been cancelled.
          </DialogContentText>
          <TextField
            fullWidth
            label="Reason for cancellation (optional)"
            multiline
            rows={3}
            margin="normal"
            variant="outlined"
          />
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setCancelDialogOpen(false)}>Back</Button>
          <Button 
            onClick={handleCancelMeeting} 
            color="warning"
            variant="contained"
          >
            Cancel Meeting
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default MeetingDetailsPage;
