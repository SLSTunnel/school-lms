import React, { useState, useCallback, useMemo, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { useTheme, Theme } from '@mui/material/styles';
import {
  Box,
  Typography,
  Paper,
  Grid,
  Avatar,
  Button,
  Divider,
  List,
  ListItem,
  ListItemText,
  ListItemAvatar,
  Chip,
  Tabs,
  Tab,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  IconButton,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  CircularProgress,
  Switch,
  FormControlLabel,
  MenuItem,
  Select,
  SelectChangeEvent,
  InputLabel,
  FormControl,
  InputAdornment,
  LinearProgress,
  Rating,
  Badge,
  Tooltip,
  Card,
  CardContent,
  CardHeader,
  CardActionArea,
  CardMedia,
} from '@mui/material';
import {
  ArrowBack as ArrowBackIcon,
  Edit as EditIcon,
  Save as SaveIcon,
  Delete as DeleteIcon,
  Email as EmailIcon,
  Phone as PhoneIcon,
  LocationOn as LocationIcon,
  CalendarToday as CalendarIcon,
  School as SchoolIcon,
  Work as WorkIcon,
  AccessTime as AccessTimeIcon,
  Notifications as NotificationsIcon,
  Person as PersonIcon,
  Settings as SettingsIcon,
  Add as AddIcon,
} from '@mui/icons-material';

// Import custom hooks
import useApi from '../../../hooks/useApi';
import useNotification from '../../../hooks/useNotification';
import useModal from '../../../hooks/useModal';

// Define interfaces
interface ClassInfo {
  id: string;
  name: string;
  subject: string;
  schedule: string;
  students: number;
}

interface Qualification {
  id: string;
  degree: string;
  institution: string;
  year: number;
}

interface CommunicationPreferences {
  email: boolean;
  sms: boolean;
  push: boolean;
  weeklyDigest: boolean;
}

interface Teacher {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  department: string;
  position: string;
  joinDate: string;
  status: 'Active' | 'Inactive' | 'On Leave';
  avatar?: string;
  address?: string;
  bio?: string;
  communicationPreferences: CommunicationPreferences;
  classes?: ClassInfo[];
  qualifications?: Qualification[];
}

// Initial teacher data
const initialTeacherData: Teacher = {
  id: '',
  firstName: '',
  lastName: '',
  email: '',
  phone: '',
  department: '',
  position: '',
  joinDate: new Date().toISOString().split('T')[0],
  status: 'Active',
  address: '',
  bio: '',
  communicationPreferences: {
    email: true,
    sms: false,
    push: true,
    weeklyDigest: true,
  },
  classes: [],
  qualifications: [],
};

// TabPanel component
interface TabPanelProps {
  children?: React.ReactNode;
  index: number;
  value: number;
}

const TabPanel: React.FC<TabPanelProps> = ({ children, value, index, ...other }) => {
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`teacher-tabpanel-${index}`}
      aria-labelledby={`teacher-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          {children}
        </Box>
      )}
    </div>
  );
};

// Main component
const TeacherDetailsView: React.FC = () => {
  // State management
  const [tabValue, setTabValue] = useState(0);
  const [editMode, setEditMode] = useState(false);
  const [teacher, setTeacher] = useState<Teacher>(initialTeacherData);
  const [isLoading, setIsLoading] = useState(true);
  
  // Hooks
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();
  const theme = useTheme();
  
  // API integration
  const { fetch: fetchTeacher } = useApi<Teacher>();
  const { notify } = useNotification();
  
  // Confirmation modal for delete action
  const { 
    isOpen: isDeleteModalOpen, 
    openModal: openDeleteModal, 
    closeModal: closeDeleteModal,
    data: deleteModalData 
  } = useModal<{ confirmText: string }>();

  // Handle input changes
  const handleInputChange = useCallback((field: keyof Teacher, value: any) => {
    setTeacher(prev => ({
      ...prev,
      [field]: value
    }));
  }, []);

  // Handle preference changes
  const handlePreferenceChange = useCallback((preference: keyof CommunicationPreferences, checked: boolean) => {
    setTeacher(prev => ({
      ...prev,
      communicationPreferences: {
        ...prev.communicationPreferences,
        [preference]: checked
      }
    }));
  }, []);

  // Handle delete button click
  const handleDeleteClick = useCallback(() => {
    openDeleteModal({
      confirmText: `Are you sure you want to delete ${teacher.firstName} ${teacher.lastName}?`
    });
  }, [openDeleteModal, teacher.firstName, teacher.lastName]);

  // Handle delete confirmation
  const handleDeleteConfirm = useCallback(async () => {
    try {
      setIsLoading(true);
      await fetchTeacher({
        method: 'DELETE',
        url: `/api/teachers/${id}`
      });
      
      notify({
        message: 'Teacher deleted successfully',
        type: 'success'
      });
      
      navigate('/admin/teachers');
    } catch (error) {
      notify({
        message: 'Failed to delete teacher',
        type: 'error'
      });
      setIsLoading(false);
    }
  }, [fetchTeacher, id, navigate, notify]);

  // Handle save
  const handleSave = useCallback(async () => {
    try {
      setIsLoading(true);
      await fetchTeacher({
        method: 'PUT',
        url: `/api/teachers/${id}`,
        data: teacher
      });
      
      notify({
        message: 'Teacher updated successfully',
        type: 'success'
      });
      
      setEditMode(false);
    } catch (error) {
      notify({
        message: 'Failed to update teacher',
        type: 'error'
      });
    } finally {
      setIsLoading(false);
    }
  }, [fetchTeacher, id, notify, teacher]);

  // Load teacher data
  useEffect(() => {
    const loadTeacher = async () => {
      if (!id) return;
      
      try {
        const response = await fetchTeacher({
          method: 'GET',
          url: `/api/teachers/${id}`
        });
        
        if (response?.data) {
          setTeacher(response.data);
        }
      } catch (error) {
        notify({
          message: 'Failed to load teacher data',
          type: 'error'
        });
      } finally {
        setIsLoading(false);
      }
    };
    
    loadTeacher();
  }, [fetchTeacher, id, notify]);
  
  // Update tab value when tab changes
  const handleTabChange = useCallback((event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  }, []);
  
  // Get status color based on status
  const getStatusColor = useMemo(() => {
    switch (teacher.status) {
      case 'Active':
        return 'success';
      case 'Inactive':
        return 'error';
      case 'On Leave':
        return 'warning';
      default:
        return 'default';
    }
  }, [teacher.status]);
  
  // Format join date
  const formattedJoinDate = useMemo(() => {
    return new Date(teacher.joinDate).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  }, [teacher.joinDate]);
  
  if (!id) {
    return (
      <Box sx={{ p: 3, textAlign: 'center' }}>
        <Typography variant="h6" color="error">
          No teacher ID provided
        </Typography>
        <Button 
          variant="contained" 
          color="primary" 
          onClick={() => navigate('/admin/teachers')}
          sx={{ mt: 2 }}
        >
          Back to Teachers
        </Button>
      </Box>
    );
  }
  
  return (
    <Box sx={{ p: 3 }}>
      <Button
        startIcon={<ArrowBackIcon />}
        onClick={() => navigate(-1)}
        sx={{ mb: 2 }}
      >
        Back to Teachers
      </Button>
      
      {isLoading ? (
        <Box display="flex" justifyContent="center" p={4}>
          <CircularProgress />
        </Box>
      ) : (
        <Paper sx={{ p: 3 }}>
          {/* Header with edit/save buttons */}
          <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
            <Typography variant="h4" component="h1">
              {teacher.firstName} {teacher.lastName}
            </Typography>
            <Box>
              {!editMode ? (
                <Button
                  variant="contained"
                  color="primary"
                  startIcon={<EditIcon />}
                  onClick={() => setEditMode(true)}
                >
                  Edit
                </Button>
              ) : (
                <>
                  <Button
                    variant="contained"
                    color="primary"
                    startIcon={<SaveIcon />}
                    onClick={handleSave}
                    sx={{ mr: 1 }}
                    disabled={isLoading}
                  >
                    {isLoading ? 'Saving...' : 'Save'}
                  </Button>
                  <Button
                    variant="outlined"
                    color="error"
                    startIcon={<DeleteIcon />}
                    onClick={handleDeleteClick}
                    disabled={isLoading}
                  >
                    Delete
                  </Button>
                </>
              )}
            </Box>
          </Box>
          
          {/* Main content */}
          <Grid container spacing={3}>
            {/* Left column - Profile */}
            <Grid item xs={12} md={4}>
              <Box textAlign="center" mb={3}>
                <Avatar
                  src={teacher.avatar}
                  sx={{
                    width: 150,
                    height: 150,
                    mx: 'auto',
                    mb: 2,
                    fontSize: 60,
                  }}
                >
                  {teacher.firstName.charAt(0)}{teacher.lastName.charAt(0)}
                </Avatar>
                
                <Typography variant="h6" gutterBottom>
                  {editMode ? (
                    <>
                      <TextField
                        value={teacher.firstName}
                        onChange={(e) => handleInputChange('firstName', e.target.value)}
                        margin="dense"
                        sx={{ mr: 1 }}
                      />
                      <TextField
                        value={teacher.lastName}
                        onChange={(e) => handleInputChange('lastName', e.target.value)}
                        margin="dense"
                      />
                    </>
                  ) : (
                    `${teacher.firstName} ${teacher.lastName}`
                  )}
                </Typography>
                
                {editMode ? (
                  <FormControl fullWidth margin="dense">
                    <Select
                      value={teacher.status}
                      onChange={(e) => handleInputChange('status', e.target.value as 'Active' | 'Inactive' | 'On Leave')}
                      size="small"
                    >
                      <MenuItem value="Active">Active</MenuItem>
                      <MenuItem value="Inactive">Inactive</MenuItem>
                      <MenuItem value="On Leave">On Leave</MenuItem>
                    </Select>
                  </FormControl>
                ) : (
                  <Chip
                    label={teacher.status}
                    color={getStatusColor}
                    size="small"
                    sx={{ mb: 2 }}
                  />
                )}
                
                <List dense>
                  <ListItem>
                    <ListItemAvatar>
                      <EmailIcon color="action" />
                    </ListItemAvatar>
                    <ListItemText 
                      primary={
                        editMode ? (
                          <TextField
                            fullWidth
                            value={teacher.email}
                            onChange={(e) => handleInputChange('email', e.target.value)}
                            margin="dense"
                            type="email"
                          />
                        ) : (
                          <a href={`mailto:${teacher.email}`}>{teacher.email}</a>
                        )
                      }
                      secondary="Email"
                    />
                  </ListItem>
                  
                  <ListItem>
                    <ListItemAvatar>
                      <PhoneIcon color="action" />
                    </ListItemAvatar>
                    <ListItemText 
                      primary={
                        editMode ? (
                          <TextField
                            fullWidth
                            value={teacher.phone}
                            onChange={(e) => handleInputChange('phone', e.target.value)}
                            margin="dense"
                          />
                        ) : (
                          <a href={`tel:${teacher.phone}`}>{teacher.phone}</a>
                        )
                      }
                      secondary="Phone"
                    />
                  </ListItem>
                  
                  <ListItem>
                    <ListItemAvatar>
                      <LocationIcon color="action" />
                    </ListItemAvatar>
                    <ListItemText 
                      primary={
                        editMode ? (
                          <TextField
                            fullWidth
                            value={teacher.address || ''}
                            onChange={(e) => handleInputChange('address', e.target.value)}
                            margin="dense"
                          />
                        ) : (
                          teacher.address || 'N/A'
                        )
                      }
                      secondary="Address"
                    />
                  </ListItem>
                  
                  <ListItem>
                    <ListItemAvatar>
                      <CalendarIcon color="action" />
                    </ListItemAvatar>
                    <ListItemText 
                      primary={
                        editMode ? (
                          <TextField
                            fullWidth
                            type="date"
                            value={teacher.joinDate}
                            onChange={(e) => handleInputChange('joinDate', e.target.value)}
                            margin="dense"
                            InputLabelProps={{
                              shrink: true,
                            }}
                          />
                        ) : (
                          formattedJoinDate
                        )
                      }
                      secondary="Join Date"
                    />
                  </ListItem>
                  
                  <ListItem>
                    <ListItemAvatar>
                      <SchoolIcon color="action" />
                    </ListItemAvatar>
                    <ListItemText 
                      primary={
                        editMode ? (
                          <FormControl fullWidth margin="dense">
                            <InputLabel>Department</InputLabel>
                            <Select
                              value={teacher.department}
                              onChange={(e) => handleInputChange('department', e.target.value as string)}
                              label="Department"
                            >
                              <MenuItem value="Mathematics">Mathematics</MenuItem>
                              <MenuItem value="Science">Science</MenuItem>
                              <MenuItem value="English">English</MenuItem>
                              <MenuItem value="History">History</MenuItem>
                              <MenuItem value="Art">Art</MenuItem>
                              <MenuItem value="Music">Music</MenuItem>
                              <MenuItem value="Physical Education">Physical Education</MenuItem>
                            </Select>
                          </FormControl>
                        ) : (
                          teacher.department
                        )
                      }
                      secondary="Department"
                    />
                  </ListItem>
                </List>
              </Box>
            </Grid>
            
            {/* Right column - Details */}
            <Grid item xs={12} md={8}>
              <Paper sx={{ p: 2, mb: 3 }}>
                <Typography variant="h6" gutterBottom>Biography</Typography>
                {editMode ? (
                  <TextField
                    fullWidth
                    multiline
                    rows={4}
                    value={teacher.bio || ''}
                    onChange={(e) => handleInputChange('bio', e.target.value)}
                    variant="outlined"
                    margin="normal"
                  />
                ) : (
                  <Typography variant="body1" color="textSecondary">
                    {teacher.bio || 'No biography available.'}
                  </Typography>
                )}
              </Paper>
              
              <Tabs
                value={tabValue}
                onChange={handleTabChange}
                indicatorColor="primary"
                textColor="primary"
                variant="fullWidth"
                sx={{ mb: 2 }}
              >
                <Tab label="Classes" />
                <Tab label="Qualifications" />
                <Tab label="Communication" />
              </Tabs>
              
              <TabPanel value={tabValue} index={0}>
                <TableContainer component={Paper}>
                  <Table>
                    <TableHead>
                      <TableRow>
                        <TableCell>Class Name</TableCell>
                        <TableCell>Subject</TableCell>
                        <TableCell>Schedule</TableCell>
                        <TableCell align="right">Students</TableCell>
                      </TableRow>
                    </TableHead>
                    <TableBody>
                      {teacher.classes?.length ? (
                        teacher.classes.map((cls) => (
                          <TableRow key={cls.id} hover>
                            <TableCell>{cls.name}</TableCell>
                            <TableCell>{cls.subject}</TableCell>
                            <TableCell>{cls.schedule}</TableCell>
                            <TableCell align="right">{cls.students}</TableCell>
                          </TableRow>
                        ))
                      ) : (
                        <TableRow>
                          <TableCell colSpan={4} align="center">
                            No classes assigned
                          </TableCell>
                        </TableRow>
                      )}
                    </TableBody>
                  </Table>
                </TableContainer>
              </TabPanel>
              
              <TabPanel value={tabValue} index={1}>
                <List>
                  {teacher.qualifications?.length ? (
                    teacher.qualifications.map((qual) => (
                      <ListItem key={qual.id} divider>
                        <ListItemText
                          primary={qual.degree}
                          secondary={`${qual.institution}, ${qual.year}`}
                        />
                        {editMode && (
                          <IconButton edge="end" aria-label="delete">
                            <DeleteIcon />
                          </IconButton>
                        )}
                      </ListItem>
                    ))
                  ) : (
                    <ListItem>
                      <ListItemText primary="No qualifications added" />
                    </ListItem>
                  )}
                  {editMode && (
                    <Button
                      variant="outlined"
                      color="primary"
                      startIcon={<AddIcon />}
                      fullWidth
                      sx={{ mt: 1 }}
                    >
                      Add Qualification
                    </Button>
                  )}
                </List>
              </TabPanel>
              
              <TabPanel value={tabValue} index={2}>
                <List>
                  <ListItem>
                    <FormControlLabel
                      control={
                        <Switch
                          checked={teacher.communicationPreferences.email}
                          onChange={(e) => handlePreferenceChange('email', e.target.checked)}
                          color="primary"
                          disabled={!editMode}
                        />
                      }
                      label="Email Notifications"
                    />
                  </ListItem>
                  <ListItem>
                    <FormControlLabel
                      control={
                        <Switch
                          checked={teacher.communicationPreferences.sms}
                          onChange={(e) => handlePreferenceChange('sms', e.target.checked)}
                          color="primary"
                          disabled={!editMode}
                        />
                      }
                      label="SMS Notifications"
                    />
                  </ListItem>
                  <ListItem>
                    <FormControlLabel
                      control={
                        <Switch
                          checked={teacher.communicationPreferences.push}
                          onChange={(e) => handlePreferenceChange('push', e.target.checked)}
                          color="primary"
                          disabled={!editMode}
                        />
                      }
                      label="Push Notifications"
                    />
                  </ListItem>
                  <ListItem>
                    <FormControlLabel
                      control={
                        <Switch
                          checked={teacher.communicationPreferences.weeklyDigest}
                          onChange={(e) => handlePreferenceChange('weeklyDigest', e.target.checked)}
                          color="primary"
                          disabled={!editMode}
                        />
                      }
                      label="Weekly Digest"
                    />
                  </ListItem>
                </List>
              </TabPanel>
            </Grid>
          </Grid>
          
          {/* Delete Confirmation Dialog */}
          <Dialog
            open={isDeleteModalOpen}
            onClose={closeDeleteModal}
            aria-labelledby="delete-dialog-title"
          >
            <DialogTitle id="delete-dialog-title">Confirm Delete</DialogTitle>
            <DialogContent>
              <DialogContentText>
                {deleteModalData?.confirmText || 'Are you sure you want to delete this teacher?'}
              </DialogContentText>
            </DialogContent>
            <DialogActions>
              <Button onClick={closeDeleteModal} color="primary">
                Cancel
              </Button>
              <Button 
                onClick={handleDeleteConfirm} 
                color="error" 
                variant="contained"
                disabled={isLoading}
              >
                {isLoading ? 'Deleting...' : 'Delete'}
              </Button>
            </DialogActions>
          </Dialog>
        </Paper>
      )}
    </Box>
  );
};

export default TeacherDetailsView;
