import React, { useState, useEffect } from 'react';
import {
  Box,
  Button,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TextField,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  IconButton,
  Typography,
  Snackbar,
  Alert,
  Chip,
  Avatar,
  Tooltip,
} from '@mui/material';
import { Add as AddIcon, Edit as EditIcon, Delete as DeleteIcon, Person as PersonIcon } from '@mui/icons-material';

type UserRole = 'student' | 'teacher' | 'admin' | 'principal';

interface User {
  id: string;
  name: string;
  email: string;
  role: UserRole;
}

interface Course {
  id: string;
  code: string;
  name: string;
  description: string;
  teacher: User;
  students: User[];
  maxStudents: number;
  status: 'active' | 'inactive' | 'archived';
  schedule: string;
}

const CourseManagementPage: React.FC = () => {
  const [courses, setCourses] = useState<Course[]>([]);
  const [teachers, setTeachers] = useState<User[]>([]);
  const [students, setStudents] = useState<User[]>([]);
  const [open, setOpen] = useState(false);
  const [editingCourse, setEditingCourse] = useState<Course | null>(null);
  const [snackbar, setSnackbar] = useState({ open: false, message: '', severity: 'success' });
  
  // Form state
  const [formData, setFormData] = useState<Omit<Course, 'id' | 'students' | 'teacher'>>({ 
    code: '',
    name: '',
    description: '',
    maxStudents: 30,
    status: 'active',
    schedule: 'Mon, Wed, Fri 10:00 AM - 11:00 AM'
  });
  const [selectedTeacher, setSelectedTeacher] = useState('');
  const [selectedStudents, setSelectedStudents] = useState<string[]>([]);

  // Fetch data from API
  useEffect(() => {
    // TODO: Replace with actual API calls
    const mockTeachers: User[] = [
      { id: 't1', name: 'Dr. Smith', email: 'smith@school.com', role: 'teacher' },
      { id: 't2', name: 'Prof. Johnson', email: 'johnson@school.com', role: 'teacher' },
    ];
    
    const mockStudents: User[] = [
      { id: 's1', name: 'Alice Johnson', email: 'alice@school.com', role: 'student' },
      { id: 's2', name: 'Bob Williams', email: 'bob@school.com', role: 'student' },
      { id: 's3', name: 'Charlie Brown', email: 'charlie@school.com', role: 'student' },
    ];
    
    const mockCourses: Course[] = [
      {
        id: 'c1',
        code: 'MATH101',
        name: 'Introduction to Mathematics',
        description: 'Basic concepts of algebra and calculus',
        teacher: mockTeachers[0],
        students: [mockStudents[0], mockStudents[1]],
        maxStudents: 30,
        status: 'active',
        schedule: 'Mon, Wed, Fri 10:00 AM - 11:00 AM'
      },
      {
        id: 'c2',
        code: 'PHYS201',
        name: 'Physics for Engineers',
        description: 'Fundamentals of physics with engineering applications',
        teacher: mockTeachers[1],
        students: [mockStudents[0], mockStudents[2]],
        maxStudents: 25,
        status: 'active',
        schedule: 'Tue, Thu 1:00 PM - 2:30 PM'
      },
    ];
    
    setTeachers(mockTeachers);
    setStudents(mockStudents);
    setCourses(mockCourses);
  }, []);

  const handleOpen = (course: Course | null = null) => {
    if (course) {
      setEditingCourse(course);
      setFormData({
        code: course.code,
        name: course.name,
        description: course.description,
        maxStudents: course.maxStudents,
        status: course.status,
        schedule: course.schedule
      });
      setSelectedTeacher(course.teacher.id);
      setSelectedStudents(course.students.map(s => s.id));
    } else {
      setEditingCourse(null);
      setFormData({ 
        code: '',
        name: '',
        description: '',
        maxStudents: 30,
        status: 'active',
        schedule: 'Mon, Wed, Fri 10:00 AM - 11:00 AM'
      });
      setSelectedTeacher('');
      setSelectedStudents([]);
    }
    setOpen(true);
  };

  const handleClose = () => {
    setOpen(false);
    setEditingCourse(null);
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: name === 'maxStudents' ? parseInt(value) || 0 : value
    }));
  };

  const handleStatusChange = (e: any) => {
    setFormData(prev => ({
      ...prev,
      status: e.target.value as 'active' | 'inactive' | 'archived'
    }));
  };

  const handleTeacherChange = (e: any) => {
    setSelectedTeacher(e.target.value);
  };

  const handleStudentsChange = (e: any) => {
    setSelectedStudents(e.target.value);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const teacher = teachers.find(t => t.id === selectedTeacher);
    const selectedStudentList = students.filter(s => selectedStudents.includes(s.id));
    
    if (!teacher) {
      setSnackbar({ open: true, message: 'Please select a teacher', severity: 'error' });
      return;
    }
    
    const courseData = {
      ...formData,
      teacher,
      students: selectedStudentList
    };
    
    if (editingCourse) {
      // Update existing course
      setCourses(courses.map(c => 
        c.id === editingCourse.id ? { ...courseData, id: editingCourse.id } : c
      ));
      setSnackbar({ open: true, message: 'Course updated successfully', severity: 'success' });
    } else {
      // Add new course
      const newCourse = {
        ...courseData,
        id: `c${courses.length + 1}`,
      };
      setCourses([...courses, newCourse]);
      setSnackbar({ open: true, message: 'Course added successfully', severity: 'success' });
    }
    
    handleClose();
  };

  const handleDelete = (courseId: string) => {
    if (window.confirm('Are you sure you want to delete this course?')) {
      setCourses(courses.filter(course => course.id !== courseId));
      setSnackbar({ open: true, message: 'Course deleted successfully', severity: 'success' });
    }
  };

  const handleCloseSnackbar = () => {
    setSnackbar(prev => ({ ...prev, open: false }));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'success';
      case 'inactive': return 'warning';
      case 'archived': return 'default';
      default: return 'default';
    }
  };

  return (
    <Box sx={{ p: 3 }}>
      <Box sx={{ display: 'flex', justifyContent: 'space-between', mb: 3 }}>
        <Typography variant="h5">Course Management</Typography>
        <Button
          variant="contained"
          color="primary"
          startIcon={<AddIcon />}
          onClick={() => handleOpen()}
        >
          Add Course
        </Button>
      </Box>

      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Code</TableCell>
              <TableCell>Name</TableCell>
              <TableCell>Teacher</TableCell>
              <TableCell>Students</TableCell>
              <TableCell>Schedule</TableCell>
              <TableCell>Status</TableCell>
              <TableCell align="right">Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {courses.map((course) => (
              <TableRow key={course.id}>
                <TableCell>{course.code}</TableCell>
                <TableCell>{course.name}</TableCell>
                <TableCell>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                    <Avatar sx={{ width: 32, height: 32, bgcolor: 'primary.main' }}>
                      {course.teacher.name.charAt(0)}
                    </Avatar>
                    <Box>
                      <Typography variant="body2">{course.teacher.name}</Typography>
                      <Typography variant="caption" color="text.secondary">
                        {course.teacher.email}
                      </Typography>
                    </Box>
                  </Box>
                </TableCell>
                <TableCell>
                  <Box sx={{ display: 'flex', gap: 0.5, flexWrap: 'wrap' }}>
                    {course.students.slice(0, 3).map((student, index) => (
                      <Tooltip key={student.id} title={student.name}>
                        <Avatar 
                          sx={{ 
                            width: 32, 
                            height: 32, 
                            fontSize: '0.75rem',
                            bgcolor: index % 2 === 0 ? 'secondary.main' : 'info.main'
                          }}
                        >
                          {student.name.split(' ').map(n => n[0]).join('')}
                        </Avatar>
                      </Tooltip>
                    ))}
                    {course.students.length > 3 && (
                      <Chip 
                        size="small" 
                        label={`+${course.students.length - 3} more`} 
                        sx={{ height: 32 }}
                      />
                    )}
                  </Box>
                </TableCell>
                <TableCell>{course.schedule}</TableCell>
                <TableCell>
                  <Chip 
                    label={course.status} 
                    color={getStatusColor(course.status) as any}
                    size="small"
                  />
                </TableCell>
                <TableCell align="right">
                  <IconButton onClick={() => handleOpen(course)} color="primary">
                    <EditIcon />
                  </IconButton>
                  <IconButton onClick={() => handleDelete(course.id)} color="error">
                    <DeleteIcon />
                  </IconButton>
                </TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </TableContainer>

      {/* Add/Edit Course Dialog */}
      <Dialog open={open} onClose={handleClose} maxWidth="md" fullWidth>
        <DialogTitle>{editingCourse ? 'Edit Course' : 'Add New Course'}</DialogTitle>
        <form onSubmit={handleSubmit}>
          <DialogContent>
            <Box sx={{ display: 'flex', gap: 2, mb: 2 }}>
              <TextField
                margin="dense"
                name="code"
                label="Course Code"
                fullWidth
                variant="outlined"
                value={formData.code}
                onChange={handleChange}
                required
              />
              <TextField
                margin="dense"
                name="name"
                label="Course Name"
                fullWidth
                variant="outlined"
                value={formData.name}
                onChange={handleChange}
                required
              />
            </Box>
            
            <TextField
              margin="dense"
              name="description"
              label="Description"
              fullWidth
              multiline
              rows={3}
              variant="outlined"
              value={formData.description}
              onChange={handleChange}
              sx={{ mb: 2 }}
            />
            
            <Box sx={{ display: 'flex', gap: 2, mb: 2 }}>
              <FormControl fullWidth margin="dense">
                <InputLabel id="teacher-label">Teacher</InputLabel>
                <Select
                  labelId="teacher-label"
                  value={selectedTeacher}
                  label="Teacher"
                  onChange={handleTeacherChange}
                  required
                >
                  {teachers.map(teacher => (
                    <MenuItem key={teacher.id} value={teacher.id}>
                      {teacher.name} ({teacher.email})
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>
              
              <TextField
                margin="dense"
                name="maxStudents"
                label="Max Students"
                type="number"
                fullWidth
                variant="outlined"
                value={formData.maxStudents}
                onChange={handleChange}
                required
              />
              
              <FormControl fullWidth margin="dense">
                <InputLabel id="status-label">Status</InputLabel>
                <Select
                  labelId="status-label"
                  value={formData.status}
                  label="Status"
                  onChange={handleStatusChange}
                  required
                >
                  <MenuItem value="active">Active</MenuItem>
                  <MenuItem value="inactive">Inactive</MenuItem>
                  <MenuItem value="archived">Archived</MenuItem>
                </Select>
              </FormControl>
            </Box>
            
            <FormControl fullWidth margin="dense">
              <InputLabel id="students-label">Enrolled Students</InputLabel>
              <Select
                labelId="students-label"
                multiple
                value={selectedStudents}
                label="Enrolled Students"
                onChange={handleStudentsChange}
                renderValue={(selected) => (
                  <Box sx={{ display: 'flex', flexWrap: 'wrap', gap: 0.5 }}>
                    {selected.map((value) => {
                      const student = students.find(s => s.id === value);
                      return student ? (
                        <Chip key={value} label={student.name} size="small" />
                      ) : null;
                    })}
                  </Box>
                )}
              >
                {students.map((student) => (
                  <MenuItem key={student.id} value={student.id}>
                    {student.name} ({student.email})
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
            
            <TextField
              margin="dense"
              name="schedule"
              label="Schedule"
              fullWidth
              variant="outlined"
              value={formData.schedule}
              onChange={handleChange}
              required
              sx={{ mt: 2 }}
            />
          </DialogContent>
          <DialogActions sx={{ p: 2 }}>
            <Button onClick={handleClose}>Cancel</Button>
            <Button type="submit" variant="contained" color="primary">
              {editingCourse ? 'Update' : 'Create'} Course
            </Button>
          </DialogActions>
        </form>
      </Dialog>

      {/* Snackbar for notifications */}
      <Snackbar
        open={snackbar.open}
        autoHideDuration={6000}
        onClose={handleCloseSnackbar}
        anchorOrigin={{ vertical: 'top', horizontal: 'right' }}
      >
        <Alert onClose={handleCloseSnackbar} severity={snackbar.severity as any} sx={{ width: '100%' }}>
          {snackbar.message}
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default CourseManagementPage;
