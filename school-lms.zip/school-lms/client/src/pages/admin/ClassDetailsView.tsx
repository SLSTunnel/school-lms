import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { 
  Box, Typography, Paper, Tabs, Tab, Grid, Button, 
  Avatar, List, ListItem, ListItemText, ListItemAvatar, 
  Divider, Chip, IconButton, TextField, MenuItem, 
  Table, TableBody, TableCell, TableContainer, TableHead, 
  TableRow, TablePagination, LinearProgress, Card, CardContent,
  Dialog, DialogTitle, DialogContent, DialogActions, DialogContentText
} from '@mui/material';
import { 
  People as PeopleIcon, 
  Assignment as AssignmentIcon, 
  Event as EventIcon, 
  BarChart as BarChartIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Add as AddIcon,
  PersonAdd as PersonAddIcon,
  FileDownload as FileDownloadIcon,
  Print as PrintIcon,
  MoreVert as MoreVertIcon,
  CheckCircle as CheckCircleIcon,
  Warning as WarningIcon,
  Error as ErrorIcon
} from '@mui/icons-material';

// Mock data - replace with API calls in a real application
const mockClassData = {
  id: 'MATH101',
  name: 'Introduction to Calculus',
  code: 'MATH-101-01',
  section: '01',
  academicYear: '2023-2024',
  semester: 'Fall',
  credits: 3,
  description: 'An introduction to differential and integral calculus with applications.',
  instructor: {
    id: 't001',
    name: 'Dr. Sarah Johnson',
    email: 's.johnson@school.edu',
    avatar: '/path/to/avatar.jpg'
  },
  schedule: [
    { day: 'Monday', time: '09:00 AM - 10:30 AM', room: 'Science 205', type: 'Lecture' },
    { day: 'Wednesday', time: '09:00 AM - 10:30 AM', room: 'Science 205', type: 'Lecture' },
    { day: 'Friday', time: '10:45 AM - 11:45 AM', room: 'Science 210', type: 'Lab' }
  ],
  students: [
    { id: 's101', name: 'John Doe', email: 'john.doe@student.school.edu', status: 'Active', grade: 'A' },
    { id: 's102', name: 'Jane Smith', email: 'jane.smith@student.school.edu', status: 'Active', grade: 'A-' },
    { id: 's103', name: 'Alex Johnson', email: 'alex.johnson@student.school.edu', status: 'Active', grade: 'B+' },
    { id: 's104', name: 'Maria Garcia', email: 'maria.garcia@student.school.edu', status: 'Active', grade: 'A' },
    { id: 's105', name: 'David Kim', email: 'david.kim@student.school.edu', status: 'Active', grade: 'B' },
  ],
  assignments: [
    { id: 'a101', title: 'Homework 1: Limits', dueDate: '2023-10-15', status: 'Graded', averageScore: 87, totalPoints: 100 },
    { id: 'a102', title: 'Quiz 1', dueDate: '2023-10-22', status: 'Graded', averageScore: 92, totalPoints: 100 },
    { id: 'a103', title: 'Project 1', dueDate: '2023-11-05', status: 'Submitted', averageScore: null, totalPoints: 100 },
    { id: 'a104', title: 'Midterm Exam', dueDate: '2023-11-15', status: 'Upcoming', averageScore: null, totalPoints: 100 },
  ],
  announcements: [
    { id: 'ann1', date: '2023-10-10', title: 'Office Hours Change', content: 'Office hours this week will be moved to Thursday 2-4 PM.' },
    { id: 'ann2', date: '2023-10-05', title: 'Homework 1 Posted', content: 'Homework 1 has been posted. Due date is October 15th.' },
  ]
};

const ClassDetailsView: React.FC = () => {
  const { classId } = useParams<{ classId: string }>();
  const navigate = useNavigate();
  const [tabValue, setTabValue] = useState(0);
  const [editMode, setEditMode] = useState(false);
  const [classData, setClassData] = useState(mockClassData);
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(5);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);

  // In a real app, fetch class data based on classId
  useEffect(() => {
    // fetchClassData(classId).then(data => setClassData(data));
  }, [classId]);

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  const handleChangePage = (event: unknown, newPage: number) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement>) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleDeleteClass = () => {
    // In a real app, make API call to delete the class
    console.log('Deleting class:', classId);
    // navigate('/admin/classes');
    setDeleteDialogOpen(false);
  };

  const handleExportData = (type: 'students' | 'grades' | 'attendance') => {
    console.log(`Exporting ${type} data for class ${classId}`);
    // In a real app, generate and download the appropriate file
  };

  const renderClassInfo = () => (
    <Paper sx={{ p: 3, mb: 3 }}>
      <Box display="flex" justifyContent="space-between" alignItems="flex-start" mb={2}>
        <div>
          <Typography variant="h4" component="h1" gutterBottom>
            {classData.name}
          </Typography>
          <Typography variant="subtitle1" color="text.secondary" gutterBottom>
            {classData.code} • Section {classData.section} • {classData.credits} Credits
          </Typography>
          <Typography variant="body1" paragraph>
            {classData.description}
          </Typography>
          
          <Box mt={2} display="flex" alignItems="center">
            <Avatar 
              src={classData.instructor.avatar} 
              alt={classData.instructor.name}
              sx={{ width: 40, height: 40, mr: 1 }}
            />
            <Box>
              <Typography variant="subtitle2">Instructor</Typography>
              <Typography variant="body2">{classData.instructor.name}</Typography>
              <Typography variant="body2" color="text.secondary">
                {classData.instructor.email}
              </Typography>
            </Box>
          </Box>
        </div>
        
        <Box>
          <Button 
            variant="outlined" 
            startIcon={<EditIcon />}
            onClick={() => setEditMode(!editMode)}
            sx={{ mr: 1 }}
          >
            {editMode ? 'Cancel' : 'Edit'}
          </Button>
          <Button 
            variant="contained" 
            color="primary"
            startIcon={<PeopleIcon />}
            onClick={() => navigate(`/admin/classes/${classId}/enroll`)}
          >
            Manage Enrollment
          </Button>
        </Box>
      </Box>
      
      {editMode && (
        <Box mt={3} p={2} bgcolor="action.hover" borderRadius={1}>
          <Typography variant="h6" gutterBottom>Edit Class Information</Typography>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Class Name"
                value={classData.name}
                onChange={(e) => setClassData({...classData, name: e.target.value})}
                margin="normal"
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Section"
                value={classData.section}
                onChange={(e) => setClassData({...classData, section: e.target.value})}
                margin="normal"
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                label="Academic Year"
                value={classData.academicYear}
                onChange={(e) => setClassData({...classData, academicYear: e.target.value})}
                margin="normal"
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <TextField
                fullWidth
                select
                label="Semester"
                value={classData.semester}
                onChange={(e) => setClassData({...classData, semester: e.target.value})}
                margin="normal"
              >
                <MenuItem value="Fall">Fall</MenuItem>
                <MenuItem value="Spring">Spring</MenuItem>
                <MenuItem value="Summer">Summer</MenuItem>
                <MenuItem value="Winter">Winter</MenuItem>
              </TextField>
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                multiline
                rows={3}
                label="Description"
                value={classData.description}
                onChange={(e) => setClassData({...classData, description: e.target.value})}
                margin="normal"
              />
            </Grid>
            <Grid item xs={12}>
              <Button variant="contained" color="primary" onClick={() => setEditMode(false)}>
                Save Changes
              </Button>
            </Grid>
          </Grid>
        </Box>
      )}
      
      <Box mt={3}>
        <Typography variant="h6" gutterBottom>Class Schedule</Typography>
        <List>
          {classData.schedule.map((session, index) => (
            <React.Fragment key={index}>
              <ListItem>
                <ListItemAvatar>
                  <Avatar sx={{ bgcolor: session.type === 'Lecture' ? 'primary.main' : 'secondary.main' }}>
                    <EventIcon />
                  </Avatar>
                </ListItemAvatar>
                <ListItemText 
                  primary={`${session.day}, ${session.time}`}
                  secondary={`${session.type} • ${session.room}`}
                />
              </ListItem>
              {index < classData.schedule.length - 1 && <Divider variant="inset" component="li" />}
            </React.Fragment>
          ))}
        </List>
      </Box>
    </Paper>
  );

  const renderStudentsTab = () => (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
        <Typography variant="h6">Enrolled Students ({classData.students.length})</Typography>
        <Box>
          <Button 
            variant="outlined" 
            startIcon={<PersonAddIcon />}
            onClick={() => navigate(`/admin/classes/${classId}/enroll`)}
            sx={{ mr: 1 }}
          >
            Add Students
          </Button>
          <Button 
            variant="outlined" 
            startIcon={<FileDownloadIcon />}
            onClick={() => handleExportData('students')}
          >
            Export
          </Button>
        </Box>
      </Box>
      
      <TableContainer component={Paper}>
        <Table>
          <TableHead>
            <TableRow>
              <TableCell>Student</TableCell>
              <TableCell>Email</TableCell>
              <TableCell>Status</TableCell>
              <TableCell>Current Grade</TableCell>
              <TableCell>Actions</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {classData.students
              .slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
              .map((student) => (
                <TableRow key={student.id} hover>
                  <TableCell>
                    <Box display="flex" alignItems="center">
                      <Avatar sx={{ width: 32, height: 32, mr: 1 }}>
                        {student.name.charAt(0)}
                      </Avatar>
                      {student.name}
                    </Box>
                  </TableCell>
                  <TableCell>{student.email}</TableCell>
                  <TableCell>
                    <Chip 
                      label={student.status} 
                      size="small" 
                      color={student.status === 'Active' ? 'success' : 'default'}
                    />
                  </TableCell>
                  <TableCell>
                    <Box display="flex" alignItems="center">
                      <Box width="100%" mr={1}>
                        <LinearProgress 
                          variant="determinate" 
                          value={student.grade === 'A' ? 100 : 
                                 student.grade === 'A-' ? 90 :
                                 student.grade === 'B+' ? 87 :
                                 student.grade === 'B' ? 83 : 75}
                          color={
                            student.grade === 'A' || student.grade === 'A-' ? 'success' :
                            student.grade === 'B+' || student.grade === 'B' ? 'primary' : 'warning'
                          }
                        />
                      </Box>
                      <Box minWidth={35}>
                        <Typography variant="body2" color="text.secondary">
                          {student.grade}
                        </Typography>
                      </Box>
                    </Box>
                  </TableCell>
                  <TableCell>
                    <IconButton size="small" onClick={() => navigate(`/admin/students/${student.id}`)}>
                      <EditIcon fontSize="small" />
                    </IconButton>
                    <IconButton size="small" onClick={() => console.log('View grades for', student.id)}>
                      <BarChartIcon fontSize="small" />
                    </IconButton>
                  </TableCell>
                </TableRow>
              ))}
          </TableBody>
        </Table>
        <TablePagination
          rowsPerPageOptions={[5, 10, 25]}
          component="div"
          count={classData.students.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
        />
      </TableContainer>
    </Box>
  );

  const renderAssignmentsTab = () => (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h6">Assignments & Assessments</Typography>
        <Box>
          <Button 
            variant="contained" 
            startIcon={<AddIcon />}
            onClick={() => navigate(`/admin/classes/${classId}/assignments/new`)}
          >
            New Assignment
          </Button>
        </Box>
      </Box>
      
      <Grid container spacing={3}>
        <Grid item xs={12} md={8}>
          <TableContainer component={Paper}>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Title</TableCell>
                  <TableCell>Due Date</TableCell>
                  <TableCell>Status</TableCell>
                  <TableCell>Average</TableCell>
                  <TableCell>Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {classData.assignments.map((assignment) => (
                  <TableRow key={assignment.id} hover>
                    <TableCell>{assignment.title}</TableCell>
                    <TableCell>{new Date(assignment.dueDate).toLocaleDateString()}</TableCell>
                    <TableCell>
                      <Chip 
                        label={assignment.status} 
                        size="small" 
                        color={
                          assignment.status === 'Graded' ? 'success' : 
                          assignment.status === 'Submitted' ? 'info' : 'default'
                        }
                        icon={
                          assignment.status === 'Graded' ? <CheckCircleIcon fontSize="small" /> :
                          assignment.status === 'Submitted' ? <WarningIcon fontSize="small" /> :
                          <ErrorIcon fontSize="small" />
                        }
                      />
                    </TableCell>
                    <TableCell>
                      {assignment.averageScore ? (
                        <Box display="flex" alignItems="center">
                          <Box width="100%" mr={1}>
                            <LinearProgress 
                              variant="determinate" 
                              value={assignment.averageScore}
                              color={
                                assignment.averageScore >= 90 ? 'success' :
                                assignment.averageScore >= 80 ? 'primary' : 'warning'
                              }
                            />
                          </Box>
                          <Box minWidth={35}>
                            <Typography variant="body2" color="text.secondary">
                              {assignment.averageScore}%
                            </Typography>
                          </Box>
                        </Box>
                      ) : 'N/A'}
                    </TableCell>
                    <TableCell>
                      <IconButton size="small" onClick={() => navigate(`/admin/classes/${classId}/assignments/${assignment.id}`)}>
                        <EditIcon fontSize="small" />
                      </IconButton>
                      <IconButton size="small" onClick={() => console.log('Grade assignment', assignment.id)}>
                        <BarChartIcon fontSize="small" />
                      </IconButton>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </Grid>
        
        <Grid item xs={12} md={4}>
          <Card variant="outlined" sx={{ mb: 2 }}>
            <CardContent>
              <Typography variant="h6" gutterBottom>Assignment Statistics</Typography>
              <Typography variant="body2" color="text.secondary" paragraph>
                View and analyze assignment performance across the class.
              </Typography>
              <Box mt={2}>
                <Typography variant="subtitle2">Grading Distribution</Typography>
                <Box display="flex" alignItems="center" mt={1}>
                  <Box width="100%" mr={1}>
                    <LinearProgress variant="determinate" value={75} color="success" />
                  </Box>
                  <Box minWidth={35}>
                    <Typography variant="body2" color="text.secondary">
                      15/20
                    </Typography>
                  </Box>
                </Box>
                <Typography variant="caption" color="text.secondary">Assignments Graded</Typography>
              </Box>
              <Box mt={3}>
                <Typography variant="subtitle2">Class Average</Typography>
                <Typography variant="h5">85.6%</Typography>
                <Typography variant="caption" color="text.secondary">Based on graded work</Typography>
              </Box>
            </CardContent>
          </Card>
          
          <Card variant="outlined">
            <CardContent>
              <Typography variant="h6" gutterBottom>Quick Actions</Typography>
              <Button 
                fullWidth 
                variant="outlined" 
                startIcon={<FileDownloadIcon />}
                onClick={() => handleExportData('grades')}
                sx={{ mb: 1 }}
              >
                Export Gradebook
              </Button>
              <Button 
                fullWidth 
                variant="outlined" 
                startIcon={<PrintIcon />}
                onClick={() => window.print()}
              >
                Print Grade Report
              </Button>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );

  const renderAnnouncementsTab = () => (
    <Box>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
        <Typography variant="h6">Class Announcements</Typography>
        <Button 
          variant="contained" 
          startIcon={<AddIcon />}
          onClick={() => console.log('Create new announcement')}
        >
          New Announcement
        </Button>
      </Box>
      
      {classData.announcements.length > 0 ? (
        <List>
          {classData.announcements.map((announcement, index) => (
            <React.Fragment key={announcement.id}>
              <ListItem alignItems="flex-start">
                <ListItemAvatar>
                  <Avatar>
                    <AssignmentIcon />
                  </Avatar>
                </ListItemAvatar>
                <ListItemText
                  primary={
                    <Box display="flex" justifyContent="space-between" alignItems="center">
                      <Typography variant="subtitle1" component="div">
                        {announcement.title}
                      </Typography>
                      <Typography variant="caption" color="text.secondary">
                        {new Date(announcement.date).toLocaleDateString()}
                      </Typography>
                    </Box>
                  }
                  secondary={
                    <React.Fragment>
                      <Typography
                        component="span"
                        variant="body2"
                        color="text.primary"
                      >
                        {announcement.content}
                      </Typography>
                    </React.Fragment>
                  }
                />
                <IconButton edge="end" aria-label="more">
                  <MoreVertIcon />
                </IconButton>
              </ListItem>
              {index < classData.announcements.length - 1 && <Divider variant="inset" component="li" />}
            </React.Fragment>
          ))}
        </List>
      ) : (
        <Paper variant="outlined" sx={{ p: 3, textAlign: 'center' }}>
          <Typography color="text.secondary">No announcements yet.</Typography>
          <Button 
            variant="text" 
            color="primary" 
            startIcon={<AddIcon />}
            onClick={() => console.log('Create first announcement')}
            sx={{ mt: 1 }}
          >
            Create Announcement
          </Button>
        </Paper>
      )}
    </Box>
  );

  const renderAnalyticsTab = () => (
    <Box>
      <Typography variant="h6" gutterBottom>Class Analytics</Typography>
      <Grid container spacing={3}>
        <Grid item xs={12} md={6}>
          <Card variant="outlined" sx={{ height: '100%' }}>
            <CardContent>
              <Typography variant="subtitle1" gutterBottom>Grade Distribution</Typography>
              <Box height={300} display="flex" alignItems="center" justifyContent="center">
                <Typography color="text.secondary">Grade distribution chart would be displayed here</Typography>
              </Box>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12} md={6}>
          <Card variant="outlined" sx={{ height: '100%' }}>
            <CardContent>
              <Typography variant="subtitle1" gutterBottom>Attendance Overview</Typography>
              <Box height={300} display="flex" alignItems="center" justifyContent="center">
                <Typography color="text.secondary">Attendance chart would be displayed here</Typography>
              </Box>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={12}>
          <Card variant="outlined">
            <CardContent>
              <Typography variant="subtitle1" gutterBottom>Assignment Performance</Typography>
              <Box height={400} display="flex" alignItems="center" justifyContent="center">
                <Typography color="text.secondary">Assignment performance chart would be displayed here</Typography>
              </Box>
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );

  const renderSettingsTab = () => (
    <Box>
      <Typography variant="h6" gutterBottom>Class Settings</Typography>
      
      <Card variant="outlined" sx={{ mb: 3 }}>
        <CardContent>
          <Typography variant="subtitle1" gutterBottom>General Settings</Typography>
          <Grid container spacing={2}>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Class Code"
                value={classData.code}
                margin="normal"
                disabled={!editMode}
              />
            </Grid>
            <Grid item xs={12} md={6}>
              <TextField
                fullWidth
                label="Credits"
                type="number"
                value={classData.credits}
                margin="normal"
                disabled={!editMode}
              />
            </Grid>
            <Grid item xs={12}>
              <TextField
                fullWidth
                select
                label="Instructor"
                value={classData.instructor.id}
                margin="normal"
                disabled={!editMode}
              >
                <MenuItem value="t001">Dr. Sarah Johnson</MenuItem>
                <MenuItem value="t002">Prof. Michael Chen</MenuItem>
                <MenuItem value="t003">Dr. Emily Wilson</MenuItem>
              </TextField>
            </Grid>
          </Grid>
          
          {editMode && (
            <Box mt={2} display="flex" justifyContent="flex-end">
              <Button 
                variant="contained" 
                color="primary"
                onClick={() => setEditMode(false)}
              >
                Save Changes
              </Button>
            </Box>
          )}
        </CardContent>
      </Card>
      
      <Card variant="outlined" sx={{ mb: 3 }}>
        <CardContent>
          <Typography variant="subtitle1" gutterBottom>Danger Zone</Typography>
          <Typography variant="body2" color="text.secondary" paragraph>
            These actions are irreversible. Please be certain before proceeding.
          </Typography>
          <Button 
            variant="outlined" 
            color="error"
            startIcon={<DeleteIcon />}
            onClick={() => setDeleteDialogOpen(true)}
          >
            Delete This Class
          </Button>
          <Typography variant="caption" color="error" display="block" mt={1}>
            Warning: This will permanently delete all class data including student submissions and grades.
          </Typography>
        </CardContent>
      </Card>
    </Box>
  );

  return (
    <Box sx={{ width: '100%' }}>
      {renderClassInfo()}
      
      <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}>
        <Tabs 
          value={tabValue} 
          onChange={handleTabChange} 
          aria-label="class details tabs"
          variant="scrollable"
          scrollButtons="auto"
        >
          <Tab label="Students" icon={<PeopleIcon />} iconPosition="start" />
          <Tab label="Assignments" icon={<AssignmentIcon />} iconPosition="start" />
          <Tab label="Announcements" icon={<EventIcon />} iconPosition="start" />
          <Tab label="Analytics" icon={<BarChartIcon />} iconPosition="start" />
          <Tab label="Settings" icon={<MoreVertIcon />} iconPosition="start" />
        </Tabs>
      </Box>
      
      <Box sx={{ p: 1 }}>
        {tabValue === 0 && renderStudentsTab()}
        {tabValue === 1 && renderAssignmentsTab()}
        {tabValue === 2 && renderAnnouncementsTab()}
        {tabValue === 3 && renderAnalyticsTab()}
        {tabValue === 4 && renderSettingsTab()}
      </Box>
      
      <Dialog
        open={deleteDialogOpen}
        onClose={() => setDeleteDialogOpen(false)}
        aria-labelledby="alert-dialog-title"
        aria-describedby="alert-dialog-description"
      >
        <DialogTitle id="alert-dialog-title">
          Delete {classData.name}?
        </DialogTitle>
        <DialogContent>
          <DialogContentText id="alert-dialog-description">
            Are you sure you want to delete this class? This action cannot be undone and will permanently remove all class data, including student submissions, grades, and announcements.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setDeleteDialogOpen(false)}>Cancel</Button>
          <Button onClick={handleDeleteClass} color="error" autoFocus>
            Delete Class
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default ClassDetailsView;
