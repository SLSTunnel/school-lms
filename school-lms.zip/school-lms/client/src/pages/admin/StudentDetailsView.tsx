import React from 'react';
import {
  Box,
  Typography,
  Paper,
  Grid,
  Avatar,
  Button,
  Divider,
  List,
  ListItem,
  ListItemText,
  ListItemAvatar,
  Chip,
  Tabs,
  Tab,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  IconButton,
  TextField,
  InputAdornment,
} from '@mui/material';
import {
  ArrowBack as ArrowBackIcon,
  Email as EmailIcon,
  Phone as PhoneIcon,
  CalendarToday as CalendarIcon,
  School as SchoolIcon,
  Assignment as AssignmentIcon,
  BarChart as BarChartIcon,
  Event as EventIcon,
  Search as SearchIcon,
  FilterList as FilterListIcon,
  Edit as EditIcon,
  Print as PrintIcon,
  FileDownload as FileDownloadIcon,
} from '@mui/icons-material';
import { useNavigate, useParams } from 'react-router-dom';

// Mock data - replace with API calls in a real application
const studentData = {
  id: 'S1001',
  fullName: 'Alex Johnson',
  email: 'alex.johnson@school.edu',
  phone: '(555) 123-4567',
  address: '123 Main St, Anytown, USA',
  dateOfBirth: '2008-05-15',
  grade: '10th Grade',
  section: 'A',
  admissionDate: '2022-08-15',
  parentName: 'Sarah Johnson',
  parentEmail: 'sarah.johnson@email.com',
  parentPhone: '(555) 987-6543',
  emergencyContact: 'Michael Johnson (Father) - (555) 456-7890',
  bloodGroup: 'A+',
  avatarColor: '#3f51b5',
  attendance: {
    present: 145,
    absent: 12,
    late: 8,
    percentage: 92.3,
    monthlyData: [
      { month: 'Jan', present: 20, absent: 2, late: 1 },
      { month: 'Feb', present: 18, absent: 0, late: 2 },
      { month: 'Mar', present: 22, absent: 1, late: 0 },
      { month: 'Apr', present: 19, absent: 2, late: 1 },
      { month: 'May', present: 21, absent: 0, late: 0 },
      { month: 'Jun', present: 20, absent: 1, late: 1 },
    ],
  },
  courses: [
    { id: 'MATH101', name: 'Mathematics', teacher: 'Dr. Smith', grade: 'A', progress: 85 },
    { id: 'SCI201', name: 'Physics', teacher: 'Prof. Johnson', grade: 'A-', progress: 78 },
    { id: 'ENG101', name: 'English Literature', teacher: 'Ms. Davis', grade: 'B+', progress: 82 },
    { id: 'HIST101', name: 'World History', teacher: 'Mr. Wilson', grade: 'A', progress: 90 },
  ],
  assignments: [
    { id: 'A101', title: 'Algebra Homework', course: 'Mathematics', dueDate: '2023-10-15', status: 'Submitted', score: '48/50' },
    { id: 'A102', title: 'Physics Lab Report', course: 'Physics', dueDate: '2023-10-20', status: 'Graded', score: '45/50' },
    { id: 'A103', title: 'Essay Draft', course: 'English Literature', dueDate: '2023-10-22', status: 'Pending Review', score: '-' },
  ],
  behavior: [
    { date: '2023-10-10', type: 'positive', description: 'Helped organize class materials', points: 5 },
    { date: '2023-10-05', type: 'positive', description: 'Excellent class participation', points: 3 },
    { date: '2023-09-28', type: 'negative', description: 'Late submission', points: -2 },
  ],
};

const TabPanel = (props: any) => {
  const { children, value, index, ...other } = props;
  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`tabpanel-${index}`}
      aria-labelledby={`tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box sx={{ p: 3 }}>
          {children}
        </Box>
      )}
    </div>
  );
};

const StudentDetailsView: React.FC = () => {
  const [tabValue, setTabValue] = React.useState(0);
  const navigate = useNavigate();
  const { id } = useParams<{ id: string }>();

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setTabValue(newValue);
  };

  return (
    <Box sx={{ p: 3 }}>
      {/* Header */}
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 3 }}>
        <IconButton onClick={() => navigate(-1)} sx={{ mr: 2 }}>
          <ArrowBackIcon />
        </IconButton>
        <Typography variant="h5" component="h1">
          Student Details
        </Typography>
        <Box sx={{ flexGrow: 1 }} />
        <Button variant="outlined" startIcon={<PrintIcon />} sx={{ mr: 1 }}>
          Print
        </Button>
        <Button variant="outlined" startIcon={<FileDownloadIcon />} sx={{ mr: 1 }}>
          Export
        </Button>
        <Button variant="contained" startIcon={<EditIcon />}>
          Edit Profile
        </Button>
      </Box>

      {/* Student Profile Card */}
      <Paper sx={{ p: 3, mb: 3 }}>
        <Grid container spacing={3}>
          <Grid item xs={12} md={3} sx={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
            <Avatar 
              sx={{ 
                width: 120, 
                height: 120, 
                fontSize: 48,
                bgcolor: studentData.avatarColor,
                mb: 2
              }}
            >
              {studentData.fullName.split(' ').map(n => n[0]).join('')}
            </Avatar>
            <Typography variant="h6">{studentData.fullName}</Typography>
            <Chip 
              label={studentData.grade} 
              size="small" 
              color="primary" 
              variant="outlined" 
              sx={{ mt: 1, mb: 1 }}
            />
            <Typography variant="body2" color="textSecondary">
              Student ID: {studentData.id}
            </Typography>
          </Grid>
          
          <Grid item xs={12} md={9}>
            <Grid container spacing={2}>
              <Grid item xs={12} md={6}>
                <List dense>
                  <ListItem>
                    <ListItemAvatar>
                      <EmailIcon color="action" />
                    </ListItemAvatar>
                    <ListItemText primary="Email" secondary={studentData.email} />
                  </ListItem>
                  <Divider component="li" variant="inset" />
                  <ListItem>
                    <ListItemAvatar>
                      <PhoneIcon color="action" />
                    </ListItemAvatar>
                    <ListItemText primary="Phone" secondary={studentData.phone} />
                  </ListItem>
                  <Divider component="li" variant="inset" />
                  <ListItem>
                    <ListItemAvatar>
                      <CalendarIcon color="action" />
                    </ListItemAvatar>
                    <ListItemText 
                      primary="Date of Birth" 
                      secondary={new Date(studentData.dateOfBirth).toLocaleDateString()} 
                    />
                  </ListItem>
                </List>
              </Grid>
              <Grid item xs={12} md={6}>
                <List dense>
                  <ListItem>
                    <ListItemText primary="Parent/Guardian" secondary={studentData.parentName} />
                  </ListItem>
                  <Divider component="li" variant="inset" />
                  <ListItem>
                    <ListItemText primary="Parent Email" secondary={studentData.parentEmail} />
                  </ListItem>
                  <Divider component="li" variant="inset" />
                  <ListItem>
                    <ListItemText 
                      primary="Emergency Contact" 
                      secondary={studentData.emergencyContact} 
                    />
                  </ListItem>
                </List>
              </Grid>
              <Grid item xs={12}>
                <Box sx={{ 
                  display: 'flex', 
                  flexWrap: 'wrap', 
                  gap: 1,
                  '& > *': { 
                    flex: '1 1 180px',
                    minWidth: 0,
                  } 
                }}>
                  <Paper sx={{ p: 2, textAlign: 'center' }}>
                    <Typography variant="h6" color="primary">
                      {studentData.attendance.present}
                    </Typography>
                    <Typography variant="caption" color="textSecondary">
                      Days Present
                    </Typography>
                  </Paper>
                  <Paper sx={{ p: 2, textAlign: 'center' }}>
                    <Typography variant="h6" color="error">
                      {studentData.attendance.absent}
                    </Typography>
                    <Typography variant="caption" color="textSecondary">
                      Days Absent
                    </Typography>
                  </Paper>
                  <Paper sx={{ p: 2, textAlign: 'center' }}>
                    <Typography variant="h6" color="warning.main">
                      {studentData.attendance.late}
                    </Typography>
                    <Typography variant="caption" color="textSecondary">
                      Times Late
                    </Typography>
                  </Paper>
                  <Paper sx={{ p: 2, textAlign: 'center' }}>
                    <Typography 
                      variant="h6" 
                      sx={{ 
                        color: studentData.attendance.percentage > 90 ? 'success.main' : 'warning.main' 
                      }}
                    >
                      {studentData.attendance.percentage}%
                    </Typography>
                    <Typography variant="caption" color="textSecondary">
                      Attendance Rate
                    </Typography>
                  </Paper>
                </Box>
              </Grid>
            </Grid>
          </Grid>
        </Grid>
      </Paper>

      {/* Tabs */}
      <Paper sx={{ width: '100%', mb: 2 }}>
        <Tabs
          value={tabValue}
          onChange={handleTabChange}
          indicatorColor="primary"
          textColor="primary"
          variant="scrollable"
          scrollButtons="auto"
        >
          <Tab label="Courses" icon={<SchoolIcon />} iconPosition="start" />
          <Tab label="Assignments" icon={<AssignmentIcon />} iconPosition="start" />
          <Tab label="Attendance" icon={<EventIcon />} iconPosition="start" />
          <Tab label="Performance" icon={<BarChartIcon />} iconPosition="start" />
          <Tab label="Behavior" icon={<AssignmentIcon />} iconPosition="start" />
        </Tabs>
      </Paper>

      {/* Tab Content */}
      <Paper sx={{ p: 0, mb: 3, overflow: 'hidden' }}>
        {/* Courses Tab */}
        <TabPanel value={tabValue} index={0}>
          <Box sx={{ p: 2, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <Typography variant="h6">Enrolled Courses</Typography>
            <Box>
              <TextField
                size="small"
                placeholder="Search courses..."
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <SearchIcon />
                    </InputAdornment>
                  ),
                }}
                sx={{ mr: 1, width: 250 }}
              />
              <Button startIcon={<FilterListIcon />} sx={{ ml: 1 }}>
                Filter
              </Button>
            </Box>
          </Box>
          <TableContainer>
            <Table>
              <TableHead>
                <TableRow>
                  <TableCell>Course Code</TableCell>
                  <TableCell>Course Name</TableCell>
                  <TableCell>Instructor</TableCell>
                  <TableCell>Grade</TableCell>
                  <TableCell>Progress</TableCell>
                  <TableCell align="right">Actions</TableCell>
                </TableRow>
              </TableHead>
              <TableBody>
                {studentData.courses.map((course) => (
                  <TableRow key={course.id} hover>
                    <TableCell>{course.id}</TableCell>
                    <TableCell>{course.name}</TableCell>
                    <TableCell>{course.teacher}</TableCell>
                    <TableCell>
                      <Chip 
                        label={course.grade} 
                        color={
                          course.grade === 'A' || course.grade === 'A-' ? 'success' :
                          course.grade === 'B+' || course.grade === 'B' ? 'primary' : 'warning'
                        }
                        size="small"
                        variant="outlined"
                      />
                    </TableCell>
                    <TableCell>
                      <Box sx={{ display: 'flex', alignItems: 'center' }}>
                        <Box sx={{ width: '100%', mr: 1 }}>
                          <Box sx={{ position: 'relative', display: 'inline-flex' }}>
                            <Box
                              sx={{
                                top: 0,
                                left: 0,
                                bottom: 0,
                                right: 0,
                                position: 'absolute',
                                display: 'flex',
                                alignItems: 'center',
                                justifyContent: 'center',
                              }}
                            >
                              <Typography variant="caption" component="div" color="text.secondary">
                                {`${Math.round(course.progress)}%`}
                              </Typography>
                            </Box>
                          </Box>
                        </Box>
                      </Box>
                    </TableCell>
                    <TableCell align="right">
                      <Button size="small" color="primary">View Details</Button>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TableContainer>
        </TabPanel>

        {/* Assignments Tab */}
        <TabPanel value={tabValue} index={1}>
          <Box sx={{ p: 2 }}>
            <Typography variant="h6" gutterBottom>Recent Assignments</Typography>
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>Title</TableCell>
                    <TableCell>Course</TableCell>
                    <TableCell>Due Date</TableCell>
                    <TableCell>Status</TableCell>
                    <TableCell>Score</TableCell>
                    <TableCell align="right">Actions</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {studentData.assignments.map((assignment) => (
                    <TableRow key={assignment.id} hover>
                      <TableCell>{assignment.title}</TableCell>
                      <TableCell>{assignment.course}</TableCell>
                      <TableCell>{new Date(assignment.dueDate).toLocaleDateString()}</TableCell>
                      <TableCell>
                        <Chip 
                          label={assignment.status}
                          color={
                            assignment.status === 'Submitted' ? 'primary' :
                            assignment.status === 'Graded' ? 'success' : 'default'
                          }
                          size="small"
                        />
                      </TableCell>
                      <TableCell>
                        {assignment.score !== '-' ? (
                          <Chip 
                            label={assignment.score}
                            color="primary"
                            variant="outlined"
                            size="small"
                          />
                        ) : '-'}
                      </TableCell>
                      <TableCell align="right">
                        <Button size="small" color="primary">View</Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          </Box>
        </TabPanel>

        {/* Attendance Tab */}
        <TabPanel value={tabValue} index={2}>
          <Box sx={{ p: 2 }}>
            <Typography variant="h6" gutterBottom>Attendance Overview</Typography>
            <Box sx={{ mb: 3 }}>
              <Grid container spacing={2}>
                <Grid item xs={12} md={6}>
                  <Paper sx={{ p: 2, height: '100%' }}>
                    <Typography variant="subtitle1" gutterBottom>Monthly Attendance</Typography>
                    <Box sx={{ height: 300 }}>
                      {/* Placeholder for attendance chart */}
                      <Box sx={{ 
                        display: 'flex', 
                        alignItems: 'flex-end', 
                        height: '80%',
                        justifyContent: 'space-around',
                        mt: 4,
                      }}>
                        {studentData.attendance.monthlyData.map((monthData, index) => (
                          <Box key={index} sx={{ textAlign: 'center', width: 60 }}>
                            <Box 
                              sx={{
                                height: `${(monthData.present / 22) * 100}%`,
                                backgroundColor: 'primary.main',
                                borderRadius: 1,
                                mb: 1,
                              }}
                            />
                            <Typography variant="caption" display="block">
                              {monthData.month}
                            </Typography>
                            <Typography variant="caption" display="block">
                              {monthData.present}/{monthData.present + monthData.absent}
                            </Typography>
                          </Box>
                        ))}
                      </Box>
                    </Box>
                  </Paper>
                </Grid>
                <Grid item xs={12} md={6}>
                  <Paper sx={{ p: 2, height: '100%' }}>
                    <Typography variant="subtitle1" gutterBottom>Attendance Summary</Typography>
                    <List>
                      <ListItem>
                        <ListItemText 
                          primary="Total School Days" 
                          secondary={studentData.attendance.present + studentData.attendance.absent} 
                        />
                      </ListItem>
                      <Divider />
                      <ListItem>
                        <ListItemText 
                          primary="Days Present" 
                          secondary={`${studentData.attendance.present} (${studentData.attendance.percentage}%)`} 
                        />
                      </ListItem>
                      <Divider />
                      <ListItem>
                        <ListItemText 
                          primary="Days Absent" 
                          secondary={`${studentData.attendance.absent} (${(studentData.attendance.absent / (studentData.attendance.present + studentData.attendance.absent) * 100).toFixed(1)}%)`} 
                        />
                      </ListItem>
                      <Divider />
                      <ListItem>
                        <ListItemText 
                          primary="Times Late" 
                          secondary={studentData.attendance.late} 
                        />
                      </ListItem>
                    </List>
                  </Paper>
                </Grid>
              </Grid>
            </Box>
          </Box>
        </TabPanel>

        {/* Performance Tab */}
        <TabPanel value={tabValue} index={3}>
          <Box sx={{ p: 2 }}>
            <Typography variant="h6" gutterBottom>Academic Performance</Typography>
            <Grid container spacing={3}>
              <Grid item xs={12} md={6}>
                <Paper sx={{ p: 2, height: '100%' }}>
                  <Typography variant="subtitle1" gutterBottom>GPA Progress</Typography>
                  <Box sx={{ height: 300, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                    <Box sx={{ textAlign: 'center' }}>
                      <Typography variant="h3" color="primary" gutterBottom>
                        3.75
                      </Typography>
                      <Typography variant="body2" color="textSecondary">
                        Current GPA (4.0 scale)
                      </Typography>
                      <Chip 
                        label="+0.15 from last term" 
                        color="success" 
                        size="small" 
                        sx={{ mt: 1 }}
                      />
                    </Box>
                  </Box>
                </Paper>
              </Grid>
              <Grid item xs={12} md={6}>
                <Paper sx={{ p: 2, height: '100%' }}>
                  <Typography variant="subtitle1" gutterBottom>Grade Distribution</Typography>
                  <Box sx={{ height: 300, display: 'flex', flexDirection: 'column', justifyContent: 'center' }}>
                    {[
                      { grade: 'A', count: 12, color: 'success.main' },
                      { grade: 'B', count: 8, color: 'primary.main' },
                      { grade: 'C', count: 3, color: 'warning.main' },
                      { grade: 'D', count: 1, color: 'error.main' },
                      { grade: 'F', count: 0, color: 'error.dark' },
                    ].map((item, index) => (
                      <Box key={index} sx={{ mb: 1 }}>
                        <Box sx={{ display: 'flex', alignItems: 'center', mb: 0.5 }}>
                          <Typography variant="body2" sx={{ width: 24 }}>{item.grade}</Typography>
                          <Box sx={{ flexGrow: 1, ml: 1 }}>
                            <Box 
                              sx={{
                                height: 20,
                                width: `${(item.count / 12) * 100}%`,
                                backgroundColor: item.color,
                                borderRadius: 1,
                                minWidth: 8,
                              }}
                            />
                          </Box>
                          <Typography variant="body2" sx={{ ml: 1, minWidth: 24, textAlign: 'right' }}>
                            {item.count}
                          </Typography>
                        </Box>
                      </Box>
                    ))}
                  </Box>
                </Paper>
              </Grid>
            </Grid>
          </Box>
        </TabPanel>

        {/* Behavior Tab */}
        <TabPanel value={tabValue} index={4}>
          <Box sx={{ p: 2 }}>
            <Typography variant="h6" gutterBottom>Behavior & Conduct</Typography>
            <TableContainer>
              <Table>
                <TableHead>
                  <TableRow>
                    <TableCell>Date</TableCell>
                    <TableCell>Type</TableCell>
                    <TableCell>Description</TableCell>
                    <TableCell>Points</TableCell>
                    <TableCell>Action</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {studentData.behavior.map((item, index) => (
                    <TableRow key={index} hover>
                      <TableCell>{new Date(item.date).toLocaleDateString()}</TableCell>
                      <TableCell>
                        <Chip 
                          label={item.type === 'positive' ? 'Positive' : 'Negative'} 
                          color={item.type === 'positive' ? 'success' : 'error'} 
                          size="small"
                        />
                      </TableCell>
                      <TableCell>{item.description}</TableCell>
                      <TableCell>
                        <Chip 
                          label={item.points > 0 ? `+${item.points}` : item.points} 
                          color={item.points > 0 ? 'success' : 'error'} 
                          size="small"
                          variant="outlined"
                        />
                      </TableCell>
                      <TableCell>
                        <Button size="small" color="primary">Details</Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
            <Box sx={{ mt: 3, p: 2, bgcolor: 'background.paper', borderRadius: 1 }}>
              <Typography variant="subtitle1" gutterBottom>Behavior Summary</Typography>
              <Grid container spacing={2}>
                <Grid item xs={12} md={6}>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                    <Box sx={{ width: 100 }}>Positive Points:</Box>
                    <Chip label="+8" color="success" size="small" />
                  </Box>
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <Box sx={{ width: 100 }}>Negative Points:</Box>
                    <Chip label="-2" color="error" size="small" />
                  </Box>
                </Grid>
                <Grid item xs={12} md={6}>
                  <Box sx={{ display: 'flex', alignItems: 'center', mb: 1 }}>
                    <Box sx={{ width: 100 }}>Total Points:</Box>
                    <Chip label="+6" color="primary" size="small" />
                  </Box>
                  <Box sx={{ display: 'flex', alignItems: 'center' }}>
                    <Box sx={{ width: 100 }}>Behavior Grade:</Box>
                    <Chip label="A" color="success" size="small" />
                  </Box>
                </Grid>
              </Grid>
            </Box>
          </Box>
        </TabPanel>
      </Paper>
    </Box>
  );
};

export default StudentDetailsView;
