import React from 'react';
import {
  Box,
  Grid,
  Paper,
  Typography,
  LinearProgress,
  List,
  ListItem,
  ListItemText,
  Divider,
  Avatar,
  ListItemAvatar,
  Chip,
  useTheme,
} from '@mui/material';
import {
  People as PeopleIcon,
  School as SchoolIcon,
  Assignment as AssignmentIcon,
  Event as EventIcon,
  BarChart as BarChartIcon,
  NotificationsActive as NotificationsActiveIcon,
  Class as ClassIcon,
  TrendingUp as TrendingUpIcon,
} from '@mui/icons-material';

// Mock data - replace with actual API calls in a real application
const stats = {
  totalStudents: 1245,
  totalTeachers: 42,
  totalCourses: 36,
  totalClasses: 78,
  attendanceRate: 87,
  assignmentCompletion: 75,
  newRegistrations: 24,
  recentActivity: [
    { id: 1, user: 'Alice Johnson', action: 'submitted Math assignment', time: '10 min ago' },
    { id: 2, user: 'Bob Smith', action: 'enrolled in Physics 101', time: '25 min ago' },
    { id: 3, user: 'Dr. Sarah Lee', action: 'graded Calculus quizzes', time: '1 hour ago' },
    { id: 4, user: 'Principal Davis', action: 'announced holiday schedule', time: '2 hours ago' },
  ],
  upcomingEvents: [
    { id: 1, title: 'Parent-Teacher Meeting', date: 'Tomorrow, 3:00 PM', type: 'meeting' },
    { id: 2, title: 'Science Fair', date: 'Oct 15, 9:00 AM', type: 'event' },
    { id: 3, title: 'End of Term Exams', date: 'Nov 1, 8:00 AM', type: 'exam' },
  ],
  classDistribution: [
    { name: 'Freshman', value: 35 },
    { name: 'Sophomore', value: 28 },
    { name: 'Junior', value: 22 },
    { name: 'Senior', value: 15 },
  ],
};

const StatCard = ({ icon, title, value, color, trend, trendValue }: any) => {
  const theme = useTheme();
  return (
    <Paper 
      sx={{ 
        p: 3, 
        height: '100%',
        borderLeft: `4px solid ${theme.palette[color].main}`,
        '&:hover': {
          boxShadow: theme.shadows[3],
          transform: 'translateY(-2px)',
          transition: 'all 0.3s ease',
        },
      }}
    >
      <Box display="flex" alignItems="center" mb={1}>
        <Box
          sx={{
            p: 1,
            mr: 2,
            backgroundColor: `${theme.palette[color].light}20`,
            borderRadius: '8px',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
        >
          {React.cloneElement(icon, { 
            sx: { 
              color: theme.palette[color].main,
              fontSize: 24,
            } 
          })}
        </Box>
        <Box flexGrow={1}>
          <Typography variant="subtitle2" color="textSecondary">
            {title}
          </Typography>
          <Box display="flex" alignItems="center">
            <Typography variant="h4" component="div">
              {value}
            </Typography>
            {trend && (
              <Chip
                label={`${trend} ${trendValue}%`}
                size="small"
                color={trend === '↑' ? 'success' : 'error'}
                sx={{ ml: 1, fontWeight: 'bold' }}
              />
            )}
          </Box>
        </Box>
      </Box>
      {title.includes('Attendance') && (
        <Box mt={2}>
          <Box display="flex" justifyContent="space-between" mb={0.5}>
            <Typography variant="caption" color="textSecondary">
              This Month
            </Typography>
            <Typography variant="caption" fontWeight="bold">
              {stats.attendanceRate}%
            </Typography>
          </Box>
          <LinearProgress 
            variant="determinate" 
            value={stats.attendanceRate} 
            color={stats.attendanceRate > 85 ? 'success' : 'primary'}
            sx={{ height: 6, borderRadius: 3 }}
          />
        </Box>
      )}
      {title.includes('Assignments') && (
        <Box mt={2}>
          <Box display="flex" justifyContent="space-between" mb={0.5}>
            <Typography variant="caption" color="textSecondary">
              Completion Rate
            </Typography>
            <Typography variant="caption" fontWeight="bold">
              {stats.assignmentCompletion}%
            </Typography>
          </Box>
          <LinearProgress 
            variant="determinate" 
            value={stats.assignmentCompletion} 
            color={stats.assignmentCompletion > 80 ? 'success' : 'warning'}
            sx={{ height: 6, borderRadius: 3 }}
          />
        </Box>
      )}
    </Paper>
  );
};\n
const DashboardOverview: React.FC = () => {
  const theme = useTheme();

  return (
    <Box sx={{ p: 3 }}>
      <Typography variant="h5" gutterBottom sx={{ mb: 3 }}>
        Dashboard Overview
      </Typography>
      
      {/* Stats Cards */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard 
            icon={<PeopleIcon />} 
            title="Total Students" 
            value={stats.totalStudents} 
            color="primary"
            trend="↑"
            trendValue="12"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard 
            icon={<SchoolIcon />} 
            title="Total Teachers" 
            value={stats.totalTeachers} 
            color="secondary"
            trend="↑"
            trendValue="5"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard 
            icon={<ClassIcon />} 
            title="Active Classes" 
            value={stats.totalClasses} 
            color="info"
          />
        </Grid>
        <Grid item xs={12} sm={6} md={3}>
          <StatCard 
            icon={<TrendingUpIcon />} 
            title="New Registrations" 
            value={stats.newRegistrations} 
            color="success"
            trend="↑"
            trendValue="8"
          />
        </Grid>
      </Grid>

      <Grid container spacing={3}>
        {/* Recent Activity */}
        <Grid item xs={12} md={6} lg={4}>
          <Paper sx={{ p: 2, height: '100%' }}>
            <Box display="flex" alignItems="center" mb={2}>
              <NotificationsActiveIcon color="primary" sx={{ mr: 1 }} />
              <Typography variant="h6">Recent Activity</Typography>
            </Box>
            <List sx={{ width: '100%' }}>
              {stats.recentActivity.map((activity, index) => (
                <React.Fragment key={activity.id}>
                  <ListItem alignItems="flex-start" sx={{ px: 0 }}>
                    <ListItemAvatar>
                      <Avatar sx={{ bgcolor: theme.palette.primary.main }}>
                        {activity.user.charAt(0)}
                      </Avatar>
                    </ListItemAvatar>
                    <ListItemText
                      primary={
                        <>
                          <Typography component="span" fontWeight="bold">
                            {activity.user}{' '}
                          </Typography>
                          {activity.action}
                        </>
                      }
                      secondary={
                        <Typography variant="caption" color="textSecondary">
                          {activity.time}
                        </Typography>
                      }
                    />
                  </ListItem>
                  {index < stats.recentActivity.length - 1 && <Divider variant="inset" component="li" />}
                </React.Fragment>
              ))}
            </List>
          </Paper>
        </Grid>

        {/* Upcoming Events */}
        <Grid item xs={12} md={6} lg={4}>
          <Paper sx={{ p: 2, height: '100%' }}>
            <Box display="flex" alignItems="center" mb={2}>
              <EventIcon color="primary" sx={{ mr: 1 }} />
              <Typography variant="h6">Upcoming Events</Typography>
            </Box>
            <List sx={{ width: '100%' }}>
              {stats.upcomingEvents.map((event, index) => (
                <React.Fragment key={event.id}>
                  <ListItem sx={{ px: 0 }}>
                    <ListItemAvatar>
                      <Avatar sx={{ bgcolor: theme.palette.secondary.main }}>
                        {event.type === 'meeting' ? 'M' : event.type === 'event' ? 'E' : 'X'}
                      </Avatar>
                    </ListItemAvatar>
                    <ListItemText
                      primary={event.title}
                      secondary={
                        <Box component="span" display="flex" alignItems="center">
                          <EventIcon fontSize="small" sx={{ mr: 0.5, fontSize: '1rem' }} />
                          {event.date}
                        </Box>
                      }
                    />
                    <Chip 
                      label={event.type} 
                      size="small" 
                      color={event.type === 'meeting' ? 'primary' : event.type === 'event' ? 'secondary' : 'default'}
                    />
                  </ListItem>
                  {index < stats.upcomingEvents.length - 1 && <Divider variant="inset" component="li" />}
                </React.Fragment>
              ))}
            </List>
          </Paper>
        </Grid>

        {/* Class Distribution */}
        <Grid item xs={12} md={12} lg={4}>
          <Paper sx={{ p: 2, height: '100%' }}>
            <Box display="flex" alignItems="center" mb={2}>
              <BarChartIcon color="primary" sx={{ mr: 1 }} />
              <Typography variant="h6">Class Distribution</Typography>
            </Box>
            <Box sx={{ mt: 3 }}>
              {stats.classDistribution.map((item) => (
                <Box key={item.name} sx={{ mb: 2 }}>
                  <Box display="flex" justifyContent="space-between" mb={0.5}>
                    <Typography variant="body2">{item.name}</Typography>
                    <Typography variant="body2" fontWeight="bold">
                      {item.value}%
                    </Typography>
                  </Box>
                  <LinearProgress 
                    variant="determinate" 
                    value={item.value} 
                    color={
                      item.name === 'Freshman' ? 'primary' :
                      item.name === 'Sophomore' ? 'secondary' :
                      item.name === 'Junior' ? 'info' : 'success'
                    }
                    sx={{ height: 8, borderRadius: 4 }}
                  />
                </Box>
              ))}
            </Box>
            <Box mt={3} p={2} bgcolor="background.default" borderRadius={1}>
              <Typography variant="body2" color="textSecondary" align="center">
                <AssignmentIcon fontSize="small" sx={{ verticalAlign: 'middle', mr: 0.5 }} />
                {stats.assignmentCompletion}% of assignments submitted this week
              </Typography>
            </Box>
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
};

export default DashboardOverview;
