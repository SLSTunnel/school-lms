import React from 'react';
import { Box, Typography, Paper, Grid } from '@mui/material';
import {
  People as PeopleIcon,
  School as SchoolIcon,
  Assignment as AssignmentIcon,
  Assessment as AssessmentIcon
} from '@mui/icons-material';

const AdminDashboardPage: React.FC = () => {
  // Sample stats - in a real app, these would come from an API
  const stats = [
    { title: 'Total Users', value: '1,234', icon: <PeopleIcon fontSize="large" /> },
    { title: 'Active Courses', value: '45', icon: <SchoolIcon fontSize="large" /> },
    { title: 'Assignments', value: '156', icon: <AssignmentIcon fontSize="large" /> },
    { title: 'Active Sessions', value: '87', icon: <AssessmentIcon fontSize="large" /> },
  ];

  return (
    <Box sx={{ flexGrow: 1, p: 3 }}>
      <Typography variant="h4" component="h1" gutterBottom>
        Admin Dashboard
      </Typography>
      
      {/* Stats Cards */}
      <Grid container spacing={3} sx={{ mb: 4 }}>
        {stats.map((stat, index) => (
          <Grid item xs={12} sm={6} md={3} key={index}>
            <Paper
              sx={{
                p: 2,
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                height: '100%',
                textAlign: 'center',
              }}
            >
              <Box sx={{ color: 'primary.main', mb: 1 }}>
                {stat.icon}
              </Box>
              <Typography variant="h6" component="div">
                {stat.value}
              </Typography>
              <Typography variant="body2" color="text.secondary">
                {stat.title}
              </Typography>
            </Paper>
          </Grid>
        ))}
      </Grid>

      {/* Recent Activity Section */}
      <Paper sx={{ p: 3, mb: 3 }}>
        <Typography variant="h6" gutterBottom>
          Recent Activity
        </Typography>
        <Typography color="text.secondary">
          Admin activity feed will be displayed here.
        </Typography>
      </Paper>

      {/* Quick Actions */}
      <Paper sx={{ p: 3 }}>
        <Typography variant="h6" gutterBottom>
          Quick Actions
        </Typography>
        <Typography color="text.secondary">
          Quick action buttons will be added here.
        </Typography>
      </Paper>
    </Box>
  );
};

export default AdminDashboardPage;
