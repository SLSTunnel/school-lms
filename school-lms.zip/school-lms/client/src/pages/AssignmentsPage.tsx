import React, { useState } from 'react';
import {
  Container,
  Box,
  Typography,
  Button,
  Tabs,
  Tab,
  Card,
  CardContent,
  CardActions,
  Chip,
  Divider,
  List,
  ListItem,
  ListItemText,
  ListItemSecondaryAction,
  IconButton,
  TextField,
  InputAdornment,
  Menu,
  MenuItem,
  Avatar,
  Badge,
  LinearProgress,
  Paper,
} from '@mui/material';
import { styled } from '@mui/material/styles';
import {
  FilterList as FilterListIcon,
  Search as SearchIcon,
  MoreVert as MoreVertIcon,
  Assignment as AssignmentIcon,
  AssignmentTurnedIn as AssignmentTurnedInIcon,
  AssignmentLate as AssignmentLateIcon,
  AssignmentReturned as AssignmentReturnedIcon,
  CalendarToday as CalendarIcon,
  AccessTime as TimeIcon,
  Grade as GradeIcon,
  Download as DownloadIcon,
  Share as ShareIcon,
  ChatBubbleOutline as CommentIcon,
  CheckCircle as CheckCircleIcon,
  Error as ErrorIcon,
  WatchLater as WatchLaterIcon,
} from '@mui/icons-material';

// Styled Components
const StyledCard = styled(Card)(({ theme }) => ({
  marginBottom: theme.spacing(2),
  transition: 'box-shadow 0.3s ease-in-out',
  '&:hover': {
    boxShadow: theme.shadows[4],
  },
}));

const AssignmentStatusChip = styled(Chip)(({ theme, status }) => ({
  fontWeight: 600,
  ...(status === 'submitted' && {
    backgroundColor: theme.palette.success.light,
    color: theme.palette.success.dark,
  }),
  ...(status === 'missing' && {
    backgroundColor: theme.palette.error.light,
    color: theme.palette.error.dark,
  }),
  ...(status === 'graded' && {
    backgroundColor: theme.palette.primary.light,
    color: theme.palette.primary.dark,
  }),
  ...(status === 'upcoming' && {
    backgroundColor: theme.palette.warning.light,
    color: theme.palette.warning.dark,
  }),
}));

// Types
type Assignment = {
  id: string;
  title: string;
  course: {
    id: string;
    name: string;
    code: string;
  };
  dueDate: string;
  status: 'submitted' | 'missing' | 'graded' | 'upcoming';
  submittedDate?: string;
  grade?: string;
  totalPoints: number;
  description: string;
  attachments: Array<{
    id: string;
    name: string;
    type: string;
    size: string;
  }>;
  instructions: string;
  rubric?: {
    criteria: Array<{
      name: string;
      points: number;
      description: string;
    }>;
  };
};

// Mock data
const assignments: Assignment[] = [
  {
    id: 'asg-001',
    title: 'Problem Set 1: Limits and Continuity',
    course: {
      id: 'math-101',
      name: 'Calculus I',
      code: 'MATH-101',
    },
    dueDate: '2023-10-15T23:59:00',
    status: 'graded',
    submittedDate: '2023-10-14T15:30:00',
    grade: 'A-',
    totalPoints: 100,
    description: 'Complete the following problems from Chapter 2. Show all your work and justify your answers.',
    attachments: [
      { id: 'att-001', name: 'Problem_Set_1.pdf', type: 'pdf', size: '2.4 MB' },
      { id: 'att-002', name: 'Supplementary_Materials.zip', type: 'zip', size: '5.7 MB' },
    ],
    instructions: 'Submit your solutions as a single PDF file. Handwritten solutions are acceptable but must be clearly legible. Late submissions will be penalized by 10% per day.',
    rubric: {
      criteria: [
        { name: 'Correctness', points: 60, description: 'Mathematical accuracy and correctness of solutions' },
        { name: 'Completeness', points: 20, description: 'All problems attempted and fully addressed' },
        { name: 'Clarity', points: 15, description: 'Clear and logical presentation of solutions' },
        { name: 'Neatness', points: 5, description: 'Readable and well-organized work' },
      ],
    },
  },
  {
    id: 'asg-002',
    title: 'Midterm Project: Data Analysis',
    course: {
      id: 'cs-201',
      name: 'Data Science Fundamentals',
      code: 'CS-201',
    },
    dueDate: '2023-10-20T23:59:00',
    status: 'submitted',
    submittedDate: '2023-10-20T22:15:00',
    totalPoints: 100,
    description: 'Analyze the provided dataset and prepare a report with your findings.',
    attachments: [
      { id: 'att-003', name: 'Project_Guidelines.pdf', type: 'pdf', size: '1.8 MB' },
      { id: 'att-004', name: 'dataset.csv', type: 'csv', size: '3.2 MB' },
    ],
    instructions: 'Submit your Jupyter notebook and a PDF report. The report should not exceed 5 pages.',
  },
  {
    id: 'asg-003',
    title: 'Essay: Modern History',
    course: {
      id: 'hist-101',
      name: 'World History',
      code: 'HIST-101',
    },
    dueDate: '2023-10-10T23:59:00',
    status: 'missing',
    totalPoints: 100,
    description: 'Write a 1500-word essay on the causes and consequences of a major 20th-century event.',
    attachments: [
      { id: 'att-005', name: 'Essay_Topics.pdf', type: 'pdf', size: '1.1 MB' },
    ],
    instructions: 'Use at least 5 academic sources. Format: 12pt Times New Roman, double-spaced, 1-inch margins.',
  },
  {
    id: 'asg-004',
    title: 'Lab Report: Chemical Reactions',
    course: {
      id: 'chem-101',
      name: 'General Chemistry',
      code: 'CHEM-101',
    },
    dueDate: '2023-10-25T23:59:00',
    status: 'upcoming',
    totalPoints: 50,
    description: 'Complete the lab experiment and submit a detailed report following the provided template.',
    attachments: [
      { id: 'att-006', name: 'Lab_Manual_Week5.pdf', type: 'pdf', size: '3.5 MB' },
      { id: 'att-007', name: 'Lab_Report_Template.docx', type: 'docx', size: '0.5 MB' },
    ],
    instructions: 'Include all raw data, calculations, and answers to the discussion questions. Submit as a single PDF.',
  },
];

const AssignmentsPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState(0);
  const [searchTerm, setSearchTerm] = useState('');
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [selectedAssignment, setSelectedAssignment] = useState<Assignment | null>(null);
  const [viewMode, setViewMode] = useState<'list' | 'detail'>('list');

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setActiveTab(newValue);
  };

  const handleMenuClick = (event: React.MouseEvent<HTMLElement>, assignment: Assignment) => {
    setAnchorEl(event.currentTarget);
    setSelectedAssignment(assignment);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleViewDetails = (assignment: Assignment) => {
    setSelectedAssignment(assignment);
    setViewMode('detail');
  };

  const handleBackToList = () => {
    setViewMode('list');
    setSelectedAssignment(null);
  };

  const handleDownloadAttachment = (attachmentId: string) => {
    console.log(`Downloading attachment ${attachmentId}`);
    // Implement download functionality
  };

  const filteredAssignments = assignments.filter(assignment => {
    const matchesSearch = assignment.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         assignment.course.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         assignment.course.code.toLowerCase().includes(searchTerm.toLowerCase());
    
    if (activeTab === 0) return matchesSearch; // All
    if (activeTab === 1) return matchesSearch && assignment.status === 'upcoming';
    if (activeTab === 2) return matchesSearch && assignment.status === 'submitted';
    if (activeTab === 3) return matchesSearch && assignment.status === 'graded';
    if (activeTab === 4) return matchesSearch && assignment.status === 'missing';
    
    return matchesSearch;
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'submitted':
        return <AssignmentTurnedInIcon color="success" />;
      case 'missing':
        return <AssignmentLateIcon color="error" />;
      case 'graded':
        return <AssignmentReturnedIcon color="primary" />;
      case 'upcoming':
        return <WatchLaterIcon color="warning" />;
      default:
        return <AssignmentIcon />;
    }
  };

  const formatDueDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  };

  const getDaysRemaining = (dueDate: string) => {
    const now = new Date();
    const due = new Date(dueDate);
    const diffTime = due.getTime() - now.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    
    if (diffDays < 0) return `Overdue by ${Math.abs(diffDays)} days`;
    if (diffDays === 0) return 'Due today';
    if (diffDays === 1) return 'Due tomorrow';
    return `Due in ${diffDays} days`;
  };

  // Detail View Component
  const AssignmentDetailView = ({ assignment }: { assignment: Assignment }) => (
    <Box>
      <Box display="flex" alignItems="center" mb={2}>
        <IconButton onClick={handleBackToList} sx={{ mr: 1 }}>
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M15 18L9 12L15 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </IconButton>
        <Typography variant="h5" component="h1">
          {assignment.title}
        </Typography>
      </Box>

      <Grid container spacing={3}>
        <Grid item xs={12} md={8}>
          <Card sx={{ mb: 3 }}>
            <CardContent>
              <Box display="flex" justifyContent="space-between" alignItems="flex-start" mb={2}>
                <Box>
                  <Chip 
                    label={assignment.course.code}
                    size="small"
                    variant="outlined"
                    sx={{ mb: 1 }}
                  />
                  <Typography variant="h6" gutterBottom>
                    {assignment.title}
                  </Typography>
                  
                  <Box display="flex" alignItems="center" mb={2}>
                    <CalendarIcon color="action" fontSize="small" sx={{ mr: 0.5 }} />
                    <Typography variant="body2" color="text.secondary">
                      {formatDueDate(assignment.dueDate)} • {getDaysRemaining(assignment.dueDate)}
                    </Typography>
                  </Box>
                  
                  {assignment.status === 'graded' && assignment.grade && (
                    <Box display="flex" alignItems="center" mb={2}>
                      <GradeIcon color="primary" fontSize="small" sx={{ mr: 0.5 }} />
                      <Typography variant="body1">
                        <strong>Grade:</strong> {assignment.grade} / {assignment.totalPoints} points
                      </Typography>
                    </Box>
                  )}
                </Box>
                
                <Box>
                  <AssignmentStatusChip 
                    label={assignment.status.charAt(0).toUpperCase() + assignment.status.slice(1)}
                    status={assignment.status}
                    icon={getStatusIcon(assignment.status)}
                  />
                </Box>
              </Box>
              
              <Divider sx={{ my: 2 }} />
              
              <Box mb={3}>
                <Typography variant="subtitle1" gutterBottom>
                  Description
                </Typography>
                <Typography variant="body1" paragraph>
                  {assignment.description}
                </Typography>
              </Box>
              
              <Box mb={3}>
                <Typography variant="subtitle1" gutterBottom>
                  Instructions
                </Typography>
                <Typography variant="body1" paragraph>
                  {assignment.instructions}
                </Typography>
              </Box>
              
              {assignment.attachments && assignment.attachments.length > 0 && (
                <Box mb={3}>
                  <Typography variant="subtitle1" gutterBottom>
                    Attachments ({assignment.attachments.length})
                  </Typography>
                  <List disablePadding>
                    {assignment.attachments.map((file) => (
                      <ListItem 
                        key={file.id} 
                        button 
                        onClick={() => handleDownloadAttachment(file.id)}
                        sx={{
                          border: '1px solid',
                          borderColor: 'divider',
                          borderRadius: 1,
                          mb: 1,
                          '&:hover': {
                            backgroundColor: 'action.hover',
                          },
                        }}
                      >
                        <Box sx={{ mr: 2 }}>
                          <DescriptionIcon color="action" />
                        </Box>
                        <ListItemText 
                          primary={file.name}
                          secondary={`${file.type.toUpperCase()} • ${file.size}`}
                        />
                        <DownloadIcon color="action" />
                      </ListItem>
                    ))}
                  </List>
                </Box>
              )}
              
              {assignment.rubric && (
                <Box>
                  <Typography variant="subtitle1" gutterBottom>
                    Grading Rubric
                  </Typography>
                  <Paper variant="outlined" sx={{ p: 2, borderRadius: 1 }}>
                    <List disablePadding>
                      {assignment.rubric.criteria.map((criterion, index) => (
                        <React.Fragment key={index}>
                          <ListItem disableGutters>
                            <Box sx={{ width: '100%' }}>
                              <Box display="flex" justifyContent="space-between" mb={0.5}>
                                <Typography variant="body2" fontWeight="medium">
                                  {criterion.name}
                                </Typography>
                                <Typography variant="body2" color="text.secondary">
                                  {criterion.points} pts
                                </Typography>
                              </Box>
                              <Typography variant="body2" color="text.secondary" paragraph>
                                {criterion.description}
                              </Typography>
                              {index < assignment.rubric!.criteria.length - 1 && <Divider />}
                            </Box>
                          </ListItem>
                          {index < assignment.rubric!.criteria.length - 1 && <Divider />}
                        </React.Fragment>
                      ))}
                    </List>
                  </Paper>
                </Box>
              )}
            </CardContent>
            
            <CardActions sx={{ justifyContent: 'flex-end', p: 2 }}>
              {assignment.status === 'missing' && (
                <Button 
                  variant="contained" 
                  color="primary"
                  startIcon={<AssignmentTurnedInIcon />}
                >
                  Submit Assignment
                </Button>
              )}
              {assignment.status === 'upcoming' && (
                <Button 
                  variant="outlined" 
                  color="primary"
                  startIcon={<WatchLaterIcon />}
                >
                  Start Assignment
                </Button>
              )}
              {assignment.status === 'submitted' && (
                <Button 
                  variant="outlined" 
                  color="primary"
                  startIcon={<WatchLaterIcon />}
                >
                  View Submission
                </Button>
              )}
              {assignment.status === 'graded' && (
                <Button 
                  variant="outlined" 
                  color="primary"
                  startIcon={<GradeIcon />}
                >
                  View Feedback
                </Button>
              )}
              <Button 
                variant="text" 
                color="primary"
                startIcon={<ShareIcon />}
                sx={{ ml: 1 }}
              >
                Share
              </Button>
            </CardActions>
          </Card>
        </Grid>
        
        <Grid item xs={12} md={4}>
          <Card sx={{ mb: 3 }}>
            <CardContent>
              <Typography variant="subtitle1" gutterBottom>
                Assignment Status
              </Typography>
              
              <Box mb={2}>
                <Box display="flex" justifyContent="space-between" mb={0.5}>
                  <Typography variant="body2" color="text.secondary">
                    Due Date
                  </Typography>
                  <Typography variant="body2" fontWeight="medium">
                    {formatDueDate(assignment.dueDate)}
                  </Typography>
                </Box>
                
                <Box display="flex" justifyContent="space-between" mb={0.5}>
                  <Typography variant="body2" color="text.secondary">
                    Status
                  </Typography>
                  <Box>
                    <AssignmentStatusChip 
                      label={assignment.status.charAt(0).toUpperCase() + assignment.status.slice(1)}
                      status={assignment.status}
                      size="small"
                    />
                  </Box>
                </Box>
                
                {assignment.submittedDate && (
                  <Box display="flex" justifyContent="space-between" mb={0.5}>
                    <Typography variant="body2" color="text.secondary">
                      Submitted
                    </Typography>
                    <Typography variant="body2">
                      {new Date(assignment.submittedDate).toLocaleDateString()}
                    </Typography>
                  </Box>
                )}
                
                {assignment.grade && (
                  <Box display="flex" justifyContent="space-between" mb={0.5}>
                    <Typography variant="body2" color="text.secondary">
                      Grade
                    </Typography>
                    <Box display="flex" alignItems="center">
                      <GradeIcon color="primary" fontSize="small" sx={{ mr: 0.5 }} />
                      <Typography variant="body2" fontWeight="medium">
                        {assignment.grade} / {assignment.totalPoints}
                      </Typography>
                    </Box>
                  </Box>
                )}
              </Box>
              
              <Divider sx={{ my: 2 }} />
              
              <Box>
                <Typography variant="subtitle2" gutterBottom>
                  Time Remaining
                </Typography>
                <Box display="flex" alignItems="center" mb={1}>
                  <TimeIcon color="action" fontSize="small" sx={{ mr: 1 }} />
                  <Typography variant="body2">
                    {getDaysRemaining(assignment.dueDate)}
                  </Typography>
                </Box>
                
                {assignment.status === 'upcoming' && (
                  <Box mt={2}>
                    <LinearProgress 
                      variant="determinate" 
                      value={Math.max(0, Math.min(100, 100 - (new Date(assignment.dueDate).getTime() - Date.now()) / (7 * 24 * 60 * 60 * 1000) * 100))}
                      color="primary"
                      sx={{ height: 8, borderRadius: 4, mb: 1 }}
                    />
                    <Typography variant="caption" color="text.secondary">
                      Time until due date
                    </Typography>
                  </Box>
                )}
              </Box>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent>
              <Typography variant="subtitle1" gutterBottom>
                Instructor Feedback
              </Typography>
              
              {assignment.status === 'graded' ? (
                <Box>
                  <Box display="flex" alignItems="center" mb={2}>
                    <Avatar sx={{ bgcolor: 'primary.main', width: 40, height: 40, mr: 1 }}>
                      {assignment.course.name.charAt(0)}
                    </Avatar>
                    <Box>
                      <Typography variant="subtitle2">Dr. {assignment.course.name.split(' ')[0]} Johnson</Typography>
                      <Typography variant="caption" color="text.secondary">
                        {new Date().toLocaleDateString()}
                      </Typography>
                    </Box>
                  </Box>
                  
                  <Paper 
                    variant="outlined" 
                    sx={{ 
                      p: 2, 
                      borderRadius: 1,
                      backgroundColor: 'background.default',
                      mb: 2,
                    }}
                  >
                    <Typography variant="body2" paragraph>
                      {assignment.grade === 'A-' 
                        ? 'Excellent work on this assignment! Your solutions are well-reasoned and clearly presented. You demonstrated a strong understanding of the concepts covered in this module.'
                        : 'Good effort on this assignment. Your solutions show understanding but could benefit from more detailed explanations in some areas.'}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Please review the comments I've added to your submission for more specific feedback.
                    </Typography>
                  </Paper>
                  
                  <Button 
                    variant="outlined" 
                    size="small" 
                    startIcon={<ChatIcon />}
                    fullWidth
                  >
                    Reply to Feedback
                  </Button>
                </Box>
              ) : assignment.status === 'submitted' ? (
                <Box textAlign="center" py={2}>
                  <WatchLaterIcon color="action" sx={{ fontSize: 40, mb: 1, opacity: 0.7 }} />
                  <Typography variant="body2" color="text.secondary">
                    Your submission is being reviewed by the instructor. You'll receive feedback once grading is complete.
                  </Typography>
                </Box>
              ) : (
                <Box textAlign="center" py={2}>
                  <ErrorIcon color="action" sx={{ fontSize: 40, mb: 1, opacity: 0.7 }} />
                  <Typography variant="body2" color="text.secondary">
                    {assignment.status === 'missing' 
                      ? 'This assignment is missing. Please submit your work as soon as possible.'
                      : 'Submit your assignment to receive feedback from your instructor.'}
                  </Typography>
                </Box>
              )}
            </CardContent>
          </Card>
        </Grid>
      </Grid>
    </Box>
  );

  // Main render
  if (viewMode === 'detail' && selectedAssignment) {
    return <AssignmentDetailView assignment={selectedAssignment} />;
  }

  return (
    <Container maxWidth="xl" sx={{ mt: 4, mb: 6 }}>
      <Box display="flex" justifyContent="space-between" alignItems="center" flexWrap="wrap" gap={2} mb={3}>
        <Typography variant="h4" component="h1">
          Assignments
        </Typography>
        <Box display="flex" gap={1}>
          <TextField
            placeholder="Search assignments..."
            variant="outlined"
            size="small"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon color="action" />
                </InputAdornment>
              ),
            }}
            sx={{ minWidth: 250 }}
          />
          <Button
            variant="outlined"
            startIcon={<FilterListIcon />}
            size="small"
          >
            Filter
          </Button>
        </Box>
      </Box>

      <Paper sx={{ mb: 3, borderRadius: 1, overflow: 'hidden' }}>
        <Tabs 
          value={activeTab}
          onChange={handleTabChange}
          variant="scrollable"
          scrollButtons="auto"
          allowScrollButtonsMobile
          sx={{
            borderBottom: 1,
            borderColor: 'divider',
            '& .MuiTab-root': {
              minHeight: 56,
            },
          }}
        >
          <Tab label="All" icon={<AssignmentIcon />} iconPosition="start" />
          <Tab 
            label="Upcoming" 
            icon={
              <Badge badgeContent={assignments.filter(a => a.status === 'upcoming').length} color="warning">
                <WatchLaterIcon />
              </Badge>
            } 
            iconPosition="start" 
          />
          <Tab 
            label="Submitted" 
            icon={
              <Badge badgeContent={assignments.filter(a => a.status === 'submitted').length} color="info">
                <AssignmentTurnedInIcon />
              </Badge>
            } 
            iconPosition="start" 
          />
          <Tab 
            label="Graded" 
            icon={
              <Badge badgeContent={assignments.filter(a => a.status === 'graded').length} color="success">
                <AssignmentReturnedIcon />
              </Badge>
            } 
            iconPosition="start" 
          />
          <Tab 
            label="Missing" 
            icon={
              <Badge badgeContent={assignments.filter(a => a.status === 'missing').length} color="error">
                <AssignmentLateIcon />
              </Badge>
            } 
            iconPosition="start" 
          />
        </Tabs>
      </Paper>

      {filteredAssignments.length > 0 ? (
        <List disablePadding>
          {filteredAssignments.map((assignment, index) => (
            <React.Fragment key={assignment.id}>
              <Paper 
                elevation={0}
                sx={{
                  mb: 2,
                  border: '1px solid',
                  borderColor: 'divider',
                  borderRadius: 1,
                  overflow: 'hidden',
                  '&:hover': {
                    boxShadow: (theme) => theme.shadows[2],
                  },
                }}
              >
                <ListItem 
                  button 
                  onClick={() => handleViewDetails(assignment)}
                  sx={{
                    display: 'flex',
                    flexDirection: { xs: 'column', sm: 'row' },
                    alignItems: 'flex-start',
                    py: 2,
                  }}
                >
                  <Box flex={1} width="100%" mb={{ xs: 2, sm: 0 }}>
                    <Box display="flex" alignItems="center" mb={1}>
                      <Box sx={{ mr: 1 }}>
                        {getStatusIcon(assignment.status)}
                      </Box>
                      <Chip 
                        label={assignment.course.code}
                        size="small"
                        variant="outlined"
                        sx={{ mr: 1 }}
                      />
                      <Typography variant="body2" color="text.secondary">
                        {formatDueDate(assignment.dueDate)}
                      </Typography>
                    </Box>
                    
                    <Typography variant="subtitle1" component="div" gutterBottom>
                      {assignment.title}
                    </Typography>
                    
                    <Box display="flex" flexWrap="wrap" gap={1} mb={1}>
                      <AssignmentStatusChip 
                        label={
                          assignment.status === 'submitted' 
                            ? 'Submitted' 
                            : assignment.status === 'graded'
                            ? `Graded: ${assignment.grade}`
                            : assignment.status === 'missing'
                            ? 'Missing'
                            : 'Upcoming'
                        }
                        status={assignment.status}
                        size="small"
                      />
                      
                      {assignment.status === 'graded' && assignment.grade && (
                        <Chip 
                          label={`${assignment.grade} / ${assignment.totalPoints}`}
                          color="primary"
                          variant="outlined"
                          size="small"
                          icon={<GradeIcon />}
                        />
                      )}
                      
                      <Chip 
                        label={getDaysRemaining(assignment.dueDate)}
                        color={
                          assignment.status === 'missing' 
                            ? 'error' 
                            : assignment.status === 'upcoming' && new Date(assignment.dueDate).getTime() - Date.now() < 3 * 24 * 60 * 60 * 1000
                            ? 'warning'
                            : 'default'
                        }
                        variant="outlined"
                        size="small"
                        icon={
                          assignment.status === 'missing' 
                            ? <ErrorIcon fontSize="small" /> 
                            : <TimeIcon fontSize="small" />
                        }
                      />
                    </Box>
                    
                    <Typography variant="body2" color="text.secondary" noWrap>
                      {assignment.description.substring(0, 100)}{assignment.description.length > 100 ? '...' : ''}
                    </Typography>
                  </Box>
                  
                  <Box 
                    display="flex" 
                    alignItems="center" 
                    justifyContent="flex-end"
                    width={{ xs: '100%', sm: 'auto' }}
                    mt={{ xs: 1, sm: 0 }}
                  >
                    <Button 
                      variant="outlined" 
                      size="small" 
                      onClick={(e) => {
                        e.stopPropagation();
                        handleViewDetails(assignment);
                      }}
                      sx={{ mr: 1 }}
                    >
                      View
                    </Button>
                    <IconButton 
                      size="small" 
                      onClick={(e) => {
                        e.stopPropagation();
                        handleMenuClick(e, assignment);
                      }}
                    >
                      <MoreVertIcon />
                    </IconButton>
                  </Box>
                </ListItem>
                
                {assignment.status === 'upcoming' && (
                  <Box sx={{ px: 2, pb: 1 }}>
                    <Box display="flex" alignItems="center" mb={0.5}>
                      <Typography variant="caption" color="text.secondary" sx={{ width: 80 }}>
                        Progress
                      </Typography>
                      <Box flex={1} mr={1}>
                        <LinearProgress 
                          variant="determinate" 
                          value={Math.max(0, Math.min(100, 100 - (new Date(assignment.dueDate).getTime() - Date.now()) / (7 * 24 * 60 * 60 * 1000) * 100))}
                          color="primary"
                          sx={{ height: 6, borderRadius: 3 }}
                        />
                      </Box>
                      <Typography variant="caption" color="text.secondary">
                        {Math.max(0, Math.min(100, 100 - Math.round((new Date(assignment.dueDate).getTime() - Date.now()) / (7 * 24 * 60 * 60 * 1000) * 100)))}%
                      </Typography>
                    </Box>
                  </Box>
                )}
              </Paper>
              
              {index < filteredAssignments.length - 1 && <Divider />}
            </React.Fragment>
          ))}
        </List>
      ) : (
        <Box 
          display="flex" 
          flexDirection="column" 
          alignItems="center" 
          justifyContent="center" 
          minHeight="300px"
          textAlign="center"
          p={4}
          bgcolor="background.paper"
          borderRadius={1}
          boxShadow={1}
        >
          <AssignmentIcon sx={{ fontSize: 60, color: 'text.disabled', mb: 2, opacity: 0.5 }} />
          <Typography variant="h6" color="text.secondary" gutterBottom>
            No assignments found
          </Typography>
          <Typography variant="body1" color="text.secondary" paragraph>
            {searchTerm
              ? 'No assignments match your search criteria. Try adjusting your search or filters.'
              : activeTab === 0
              ? 'You have no assignments at this time.'
              : `You have no ${activeTab === 1 ? 'upcoming' : activeTab === 2 ? 'submitted' : activeTab === 3 ? 'graded' : 'missing'} assignments.`}
          </Typography>
          {searchTerm && (
            <Button variant="outlined" onClick={() => setSearchTerm('')}>
              Clear Search
            </Button>
          )}
        </Box>
      )}
      
      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleMenuClose}
        onClick={(e) => e.stopPropagation()}
      >
        <MenuItem onClick={() => {
          if (selectedAssignment) handleViewDetails(selectedAssignment);
          handleMenuClose();
        }}>
          <ListItemIcon>
            <DescriptionIcon fontSize="small" />
          </ListItemIcon>
          <ListItemText>View Details</ListItemText>
        </MenuItem>
        
        <MenuItem onClick={() => {
          console.log('Download assignment:', selectedAssignment?.id);
          handleMenuClose();
        }}>
          <ListItemIcon>
            <DownloadIcon fontSize="small" />
          </ListItemIcon>
          <ListItemText>Download</ListItemText>
        </MenuItem>
        
        <Divider />
        
        <MenuItem onClick={() => {
          console.log('Share assignment:', selectedAssignment?.id);
          handleMenuClose();
        }}>
          <ListItemIcon>
            <ShareIcon fontSize="small" />
          </ListItemIcon>
          <ListItemText>Share</ListItemText>
        </MenuItem>
        
        {selectedAssignment?.status === 'missing' && (
          <MenuItem 
            onClick={() => {
              console.log('Submit assignment:', selectedAssignment.id);
              handleMenuClose();
            }}
            sx={{ color: 'primary.main' }}
          >
            <ListItemIcon>
              <AssignmentTurnedInIcon color="primary" fontSize="small" />
            </ListItemIcon>
            <ListItemText primary="Submit Assignment" />
          </MenuItem>
        )}
      </Menu>
    </Container>
  );
};

export default AssignmentsPage;
