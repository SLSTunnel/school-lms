import React, { useState, useRef, useCallback } from 'react';
import { format, startOfWeek, addDays, isSameDay, isSameMonth, isBefore, endOfDay, isToday, parseISO } from 'date-fns';
import { utcToZonedTime, zonedTimeToUtc } from 'date-fns-tz';
import {
  Box,
  Button,
  Card,
  CardContent,
  CardHeader,
  Chip,
  Divider,
  Grid,
  IconButton,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Menu,
  MenuItem,
  Paper,
  TextField,
  Typography,
  useTheme,
  Tabs,
  Tab,
  Badge,
  Avatar,
  Tooltip,
  Zoom,
  Fab,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  DialogContentText,
  FormControl,
  InputLabel,
  Select,
  Checkbox,
  ListItemButton,
  ListItemSecondaryAction,
  FormControlLabel,
  Switch,
  useMediaQuery,
} from '@mui/material';
import {
  Add as AddIcon,
  Today as TodayIcon,
  Event as EventIcon,
  Assignment as AssignmentIcon,
  Quiz as QuizIcon,
  School as SchoolIcon,
  MoreVert as MoreVertIcon,
  Edit as EditIcon,
  Delete as DeleteIcon,
  Notifications as NotificationsIcon,
  NotificationsOff as NotificationsOffIcon,
  ViewWeek as ViewWeekIcon,
  ViewDay as ViewDayIcon,
  ViewAgenda as ViewAgendaIcon,
  CalendarToday as CalendarTodayIcon,
  ChevronLeft as ChevronLeftIcon,
  ChevronRight as ChevronRightIcon,
  FilterList as FilterListIcon,
  Search as SearchIcon,
  ExpandMore as ExpandMoreIcon,
  ExpandLess as ExpandLessIcon,
  CheckCircle as CheckCircleIcon,
  RadioButtonUnchecked as RadioButtonUncheckedIcon,
} from '@mui/icons-material';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { TimePicker } from '@mui/x-date-pickers/TimePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDateFns } from '@mui/x-date-pickers/AdapterDateFns';
import { styled } from '@mui/material/styles';

// Types
type EventType = 'assignment' | 'quiz' | 'exam' | 'lecture' | 'meeting' | 'other';

interface CalendarEvent {
  id: string;
  title: string;
  description?: string;
  type: EventType;
  start: Date;
  end: Date;
  allDay: boolean;
  course?: {
    id: string;
    name: string;
    color: string;
  };
  location?: string;
  url?: string;
  completed?: boolean;
  reminder?: Date | null;
  attachments?: Array<{
    id: string;
    name: string;
    type: string;
    size: string;
    url: string;
  }>;
  notes?: string;
  priority?: 'low' | 'medium' | 'high';
  repeat?: {
    frequency: 'daily' | 'weekly' | 'monthly' | 'yearly';
    interval: number;
    endDate?: Date;
    count?: number;
    byWeekDay?: number[];
  };
  createdAt: Date;
  updatedAt: Date;
}

// Mock data
const courses = [
  { id: 'math101', name: 'Calculus I', color: '#3f51b5' },
  { id: 'cs101', name: 'Introduction to Computer Science', color: '#f44336' },
  { id: 'eng201', name: 'Academic Writing', color: '#4caf50' },
  { id: 'phy101', name: 'Physics I', color: '#ff9800' },
  { id: 'his101', name: 'World History', color: '#9c27b0' },
];

const mockEvents: CalendarEvent[] = [
  {
    id: 'e1',
    title: 'Problem Set 1 Due',
    type: 'assignment',
    start: new Date('2023-10-15T23:59:00'),
    end: new Date('2023-10-15T23:59:00'),
    allDay: false,
    course: courses[0],
    completed: true,
    priority: 'high',
    createdAt: new Date('2023-09-01T10:00:00'),
    updatedAt: new Date('2023-10-14T15:30:00'),
  },
  {
    id: 'e2',
    title: 'Chapter 1 Quiz',
    type: 'quiz',
    start: new Date('2023-10-20T10:00:00'),
    end: new Date('2023-10-20T11:30:00'),
    allDay: false,
    course: courses[0],
    location: 'Room 205',
    reminder: new Date('2023-10-19T20:00:00'),
    priority: 'high',
    createdAt: new Date('2023-09-01T10:00:00'),
    updatedAt: new Date('2023-10-10T14:30:00'),
  },
  {
    id: 'e3',
    title: 'Research Paper Draft',
    type: 'assignment',
    start: new Date('2023-10-22T23:59:00'),
    end: new Date('2023-10-22T23:59:00'),
    allDay: true,
    course: courses[2],
    priority: 'high',
    createdAt: new Date('2023-09-01T10:00:00'),
    updatedAt: new Date('2023-10-15T09:15:00'),
  },
  {
    id: 'e4',
    title: 'Midterm Exam',
    type: 'exam',
    start: new Date('2023-10-25T09:00:00'),
    end: new Date('2023-10-25T11:00:00'),
    allDay: false,
    course: courses[0],
    location: 'Exam Hall A',
    priority: 'high',
    createdAt: new Date('2023-09-01T10:00:00'),
    updatedAt: new Date('2023-10-01T16:45:00'),
  },
  {
    id: 'e5',
    title: 'Group Project Meeting',
    type: 'meeting',
    start: new Date('2023-10-26T14:00:00'),
    end: new Date('2023-10-26T15:30:00'),
    allDay: false,
    course: courses[1],
    location: 'Library Study Room 3',
    url: 'https://meet.google.com/abc-xyz-123',
    priority: 'medium',
    reminder: new Date('2023-10-26T13:30:00'),
    createdAt: new Date('2023-10-10T11:20:00'),
    updatedAt: new Date('2023-10-10T11:20:00'),
  },
  {
    id: 'e6',
    title: 'Physics Lab',
    type: 'lecture',
    start: new Date('2023-10-27T13:00:00'),
    end: new Date('2023-10-27T16:00:00'),
    allDay: false,
    course: courses[3],
    location: 'Science Building Lab 2',
    priority: 'medium',
    repeat: {
      frequency: 'weekly',
      interval: 1,
      endDate: new Date('2023-12-15T00:00:00'),
      byWeekDay: [5], // Friday
    },
    createdAt: new Date('2023-09-01T10:00:00'),
    updatedAt: new Date('2023-09-01T10:00:00'),
  },
  {
    id: 'e7',
    title: 'History Essay Outline',
    type: 'assignment',
    start: new Date('2023-10-28T23:59:00'),
    end: new Date('2023-10-28T23:59:00'),
    allDay: true,
    course: courses[4],
    priority: 'medium',
    createdAt: new Date('2023-10-05T14:30:00'),
    updatedAt: new Date('2023-10-20T09:45:00'),
  },
  {
    id: 'e8',
    title: 'Programming Assignment 2',
    type: 'assignment',
    start: new Date('2023-10-30T23:59:00'),
    end: new Date('2023-10-30T23:59:00'),
    allDay: true,
    course: courses[1],
    priority: 'high',
    createdAt: new Date('2023-10-01T10:00:00'),
    updatedAt: new Date('2023-10-15T16:20:00'),
  },
];

// Styled components
const CalendarContainer = styled(Box)({
  display: 'flex',
  flexDirection: 'column',
  height: '100%',
  overflow: 'hidden',
});

const CalendarHeader = styled(Box)(({ theme }) => ({
  display: 'flex',
  justifyContent: 'space-between',
  alignItems: 'center',
  marginBottom: theme.spacing(2),
  flexWrap: 'wrap',
  gap: theme.spacing(1),
}));

const CalendarViewControls = styled(Box)(({ theme }) => ({
  display: 'flex',
  alignItems: 'center',
  gap: theme.spacing(1),
}));

const CalendarGrid = styled(Box)({
  display: 'grid',
  gridTemplateColumns: 'repeat(7, 1fr)',
  gridTemplate-rows: 'auto 1fr',
  flex: 1,
  minHeight: 0,
  border: '1px solid',
  borderColor: 'divider',
  borderRadius: 1,
  overflow: 'hidden',
});

const DayHeader = styled(Box)(({ theme }) => ({
  padding: theme.spacing(1),
  textAlign: 'center',
  fontWeight: 'bold',
  backgroundColor: theme.palette.grey[100],
  borderBottom: '1px solid',
  borderColor: 'divider',
}));

const DayCell = styled(Box, {
  shouldForwardProp: (prop) => prop !== 'isCurrentMonth' && prop !== 'isToday' && prop !== 'isWeekend',
})<{ isCurrentMonth: boolean; isToday: boolean; isWeekend: boolean }>(({ theme, isCurrentMonth, isToday, isWeekend }) => ({
  minHeight: 120,
  padding: theme.spacing(1),
  borderRight: '1px solid',
  borderBottom: '1px solid',
  borderColor: 'divider',
  backgroundColor: isToday 
    ? theme.palette.primary.light + '22' 
    : isWeekend 
      ? theme.palette.grey[50] 
      : theme.palette.background.paper,
  color: isCurrentMonth ? 'text.primary' : 'text.secondary',
  position: 'relative',
  overflow: 'hidden',
  '&:hover': {
    backgroundColor: theme.palette.action.hover,
  },
  '&:last-child': {
    borderRight: 'none',
  },
}));

const DayNumber = styled(Box, {
  shouldForwardProp: (prop) => prop !== 'isToday',
})<{ isToday: boolean }>(({ theme, isToday }) => ({
  width: 24,
  height: 24,
  display: 'flex',
  alignItems: 'center',
  justifyContent: 'center',
  borderRadius: '50%',
  marginBottom: theme.spacing(1),
  fontWeight: 'bold',
  backgroundColor: isToday ? theme.palette.primary.main : 'transparent',
  color: isToday ? theme.palette.primary.contrastText : 'inherit',
}));

const EventItem = styled(Box, {
  shouldForwardProp: (prop) => prop !== 'eventType' && prop !== 'isPast' && prop !== 'isCompleted',
})<{ eventType: EventType; isPast: boolean; isCompleted?: boolean }>(({ theme, eventType, isPast, isCompleted }) => {
  let color = theme.palette.grey[600];
  
  if (isCompleted) return {
    backgroundColor: theme.palette.grey[200],
    color: theme.palette.text.secondary,
    textDecoration: 'line-through',
    opacity: 0.7,
    borderRadius: theme.shape.borderRadius,
    padding: theme.spacing(0.5, 1),
    marginBottom: theme.spacing(0.5),
    fontSize: '0.75rem',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    whiteSpace: 'nowrap',
    cursor: 'pointer',
    '&:hover': {
      backgroundColor: theme.palette.grey[300],
    },
  };
  
  switch (eventType) {
    case 'assignment':
      color = theme.palette.primary.main;
      break;
    case 'quiz':
      color = theme.palette.secondary.main;
      break;
    case 'exam':
      color = theme.palette.error.main;
      break;
    case 'lecture':
      color = theme.palette.info.main;
      break;
    case 'meeting':
      color = theme.palette.warning.main;
      break;
    default:
      color = theme.palette.grey[600];
  }
  
  return {
    backgroundColor: isPast ? theme.palette.action.selected : color + '1a',
    color: isPast ? theme.palette.text.secondary : color,
    borderLeft: `3px solid ${color}`,
    borderRadius: theme.shape.borderRadius,
    padding: theme.spacing(0.5, 1),
    marginBottom: theme.spacing(0.5),
    fontSize: '0.75rem',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    whiteSpace: 'nowrap',
    cursor: 'pointer',
    '&:hover': {
      backgroundColor: isPast ? theme.palette.action.hover : color + '33',
    },
  };
});

const EventDot = styled('span', {
  shouldForwardProp: (prop) => prop !== 'color',
})<{ color: string }>(({ color }) => ({
  display: 'inline-block',
  width: 8,
  height: 8,
  borderRadius: '50%',
  backgroundColor: color,
  marginRight: 4,
}));

const TimeText = styled('span')(({ theme }) => ({
  fontSize: '0.7rem',
  opacity: 0.8,
  marginRight: theme.spacing(0.5),
}));

const CalendarPage: React.FC = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('sm'));
  
  // State
  const [currentDate, setCurrentDate] = useState<Date>(new Date());
  const [view, setView] = useState<'month' | 'week' | 'day' | 'agenda'>('month');
  const [selectedEvent, setSelectedEvent] = useState<CalendarEvent | null>(null);
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [openEventDialog, setOpenEventDialog] = useState(false);
  const [openAddDialog, setOpenAddDialog] = useState(false);
  const [selectedDate, setSelectedDate] = useState<Date | null>(new Date());
  const [filterCourse, setFilterCourse] = useState<string>('all');
  const [filterType, setFilterType] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [expandedDays, setExpandedDays] = useState<Record<string, boolean>>({});
  
  // Event form state
  const [eventForm, setEventForm] = useState<Partial<CalendarEvent>>({
    title: '',
    type: 'assignment',
    start: new Date(),
    end: new Date(Date.now() + 60 * 60 * 1000), // 1 hour later
    allDay: false,
    priority: 'medium',
  });
  
  // Refs
  const calendarRef = useRef<HTMLDivElement>(null);
  
  // Constants
  const weekDays = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
  
  // Get events for the current view
  const getFilteredEvents = useCallback(() => {
    return mockEvents.filter(event => {
      // Filter by course
      if (filterCourse !== 'all' && event.course?.id !== filterCourse) {
        return false;
      }
      
      // Filter by type
      if (filterType !== 'all' && event.type !== filterType) {
        return false;
      }
      
      // Filter by search query
      if (searchQuery && !event.title.toLowerCase().includes(searchQuery.toLowerCase())) {
        return false;
      }
      
      return true;
    });
  }, [filterCourse, filterType, searchQuery]);
  
  const filteredEvents = getFilteredEvents();
  
  // Navigation
  const goToToday = () => {
    setCurrentDate(new Date());
  };
  
  const goToPreviousPeriod = () => {
    if (view === 'month') {
      setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1, 1));
    } else if (view === 'week') {
      setCurrentDate(new Date(currentDate.getTime() - 7 * 24 * 60 * 60 * 1000));
    } else {
      setCurrentDate(new Date(currentDate.getTime() - 24 * 60 * 60 * 1000));
    }
  };
  
  const goToNextPeriod = () => {
    if (view === 'month') {
      setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 1));
    } else if (view === 'week') {
      setCurrentDate(new Date(currentDate.getTime() + 7 * 24 * 60 * 60 * 1000));
    } else {
      setCurrentDate(new Date(currentDate.getTime() + 24 * 60 * 60 * 1000));
    }
  };
  
  // Event handlers
  const handleEventClick = (event: CalendarEvent, e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedEvent(event);
    setOpenEventDialog(true);
  };
  
  const handleAddEvent = (date: Date) => {
    setSelectedDate(date);
    setEventForm({
      title: '',
      type: 'assignment',
      start: date,
      end: new Date(date.getTime() + 60 * 60 * 1000), // 1 hour later
      allDay: false,
      priority: 'medium',
    });
    setOpenAddDialog(true);
  };
  
  const handleMenuClick = (event: React.MouseEvent<HTMLButtonElement>, eventItem: CalendarEvent) => {
    event.stopPropagation();
    setSelectedEvent(eventItem);
    setAnchorEl(event.currentTarget);
  };
  
  const handleMenuClose = () => {
    setAnchorEl(null);
  };
  
  const handleDeleteEvent = () => {
    // In a real app, you would make an API call to delete the event
    console.log('Delete event:', selectedEvent?.id);
    handleMenuClose();
    setOpenEventDialog(false);
  };
  
  const handleEditEvent = () => {
    if (selectedEvent) {
      setEventForm(selectedEvent);
      setOpenEventDialog(false);
      setOpenAddDialog(true);
    }
    handleMenuClose();
  };
  
  const handleToggleComplete = () => {
    if (selectedEvent) {
      // In a real app, you would make an API call to update the event
      console.log('Toggle complete:', selectedEvent.id, !selectedEvent.completed);
      setOpenEventDialog(false);
    }
    handleMenuClose();
  };
  
  const handleEventFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, you would make an API call to create/update the event
    console.log('Save event:', eventForm);
    setOpenAddDialog(false);
  };
  
  const toggleDayExpanded = (date: Date) => {
    const dateStr = date.toISOString().split('T')[0];
    setExpandedDays(prev => ({
      ...prev,
      [dateStr]: !prev[dateStr],
    }));
  };
  
  // Render the month view
  const renderMonthView = () => {
    const startOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth(), 1);
    const endOfMonth = new Date(currentDate.getFullYear(), currentDate.getMonth() + 1, 0);
    
    // Get the start of the week for the first day of the month
    const startDate = startOfWeek(startOfMonth, { weekStartsOn: 0 });
    // Get the end of the week for the last day of the month
    const endDate = addDays(startOfWeek(endOfMonth, { weekStartsOn: 0 }), 6);
    
    const days = [];
    let currentDay = new Date(startDate);
    
    while (currentDay <= endDate) {
      days.push(new Date(currentDay));
      currentDay = addDays(currentDay, 1);
    }
    
    // Group events by day
    const eventsByDay: Record<string, CalendarEvent[]> = {};
    filteredEvents.forEach(event => {
      const eventDate = new Date(event.start);
      const dateKey = eventDate.toISOString().split('T')[0];
      
      if (!eventsByDay[dateKey]) {
        eventsByDay[dateKey] = [];
      }
      eventsByDay[dateKey].push(event);
    });
    
    return (
      <CalendarGrid>
        {weekDays.map(day => (
          <DayHeader key={day}>
            {day.substring(0, 3)}
          </DayHeader>
        ))}
        
        {days.map((day, index) => {
          const dateKey = day.toISOString().split('T')[0];
          const dayEvents = eventsByDay[dateKey] || [];
          const isCurrentMonth = day.getMonth() === currentDate.getMonth();
          const isTodayDate = isToday(day);
          const isWeekend = day.getDay() === 0 || day.getDay() === 6;
          const isExpanded = expandedDays[dateKey];
          const maxEvents = isExpanded ? dayEvents.length : 2;
          
          return (
            <DayCell 
              key={index} 
              isCurrentMonth={isCurrentMonth}
              isToday={isTodayDate}
              isWeekend={isWeekend}
              onClick={() => handleAddEvent(day)}
            >
              <Box display="flex" justifyContent="space-between" alignItems="flex-start">
                <DayNumber isToday={isTodayDate}>
                  {day.getDate()}
                </DayNumber>
                {dayEvents.length > 2 && (
                  <IconButton 
                    size="small" 
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleDayExpanded(day);
                    }}
                    sx={{ p: 0 }}
                  >
                    {isExpanded ? <ExpandLessIcon fontSize="small" /> : <ExpandMoreIcon fontSize="small" />}
                  </IconButton>
                )}
              </Box>
              
              {dayEvents.slice(0, maxEvents).map(event => (
                <EventItem
                  key={event.id}
                  eventType={event.type}
                  isPast={isBefore(new Date(event.end), new Date())}
                  isCompleted={event.completed}
                  onClick={(e) => handleEventClick(event, e)}
                >
                  <Box display="flex" alignItems="center">
                    <EventDot color={event.course?.color || theme.palette.grey[500]} />
                    <Box sx={{ overflow: 'hidden', textOverflow: 'ellipsis' }}>
                      {!event.allDay && (
                        <TimeText>
                          {format(new Date(event.start), 'h:mm a')}
                        </TimeText>
                      )}
                      {event.title}
                    </Box>
                  </Box>
                </EventItem>
              ))}
              
              {dayEvents.length > 2 && !isExpanded && (
                <Typography variant="caption" color="text.secondary">
                  +{dayEvents.length - 2} more
                </Typography>
              )}
            </DayCell>
          );
        })}
      </CalendarGrid>
    );
  };
  
  // Render the agenda view
  const renderAgendaView = () => {
    // Get all days with events
    const daysWithEvents: Record<string, CalendarEvent[]> = {};
    
    filteredEvents.forEach(event => {
      const dateKey = new Date(event.start).toISOString().split('T')[0];
      
      if (!daysWithEvents[dateKey]) {
        daysWithEvents[dateKey] = [];
      }
      daysWithEvents[dateKey].push(event);
    });
    
    // Sort days chronologically
    const sortedDays = Object.keys(daysWithEvents).sort();
    
    return (
      <Box sx={{ flex: 1, overflowY: 'auto' }}>
        {sortedDays.length > 0 ? (
          sortedDays.map(dateKey => {
            const date = new Date(dateKey);
            const events = daysWithEvents[dateKey];
            const isTodayDate = isToday(date);
            
            return (
              <Box key={dateKey} mb={3}>
                <Box 
                  display="flex" 
                  alignItems="center" 
                  mb={1}
                  sx={{
                    position: 'sticky',
                    top: 0,
                    zIndex: 1,
                    backgroundColor: 'background.paper',
                    py: 1,
                    borderBottom: '1px solid',
                    borderColor: 'divider',
                  }}
                >
                  <Box 
                    sx={{
                      width: 40,
                      height: 40,
                      display: 'flex',
                      flexDirection: 'column',
                      alignItems: 'center',
                      justifyContent: 'center',
                      backgroundColor: isTodayDate ? 'primary.main' : 'transparent',
                      color: isTodayDate ? 'primary.contrastText' : 'text.primary',
                      borderRadius: 1,
                      mr: 2,
                    }}
                  >
                    <Typography variant="caption" lineHeight={1}>
                      {format(date, 'MMM')}
                    </Typography>
                    <Typography variant="subtitle2" lineHeight={1}>
                      {format(date, 'd')}
                    </Typography>
                  </Box>
                  <Typography variant="subtitle1" fontWeight="medium">
                    {format(date, 'EEEE, MMMM d, yyyy')}
                  </Typography>
                </Box>
                
                <List disablePadding>
                  {events.map(event => (
                    <ListItem 
                      key={event.id} 
                      disablePadding 
                      sx={{ mb: 1 }}
                      onClick={(e) => handleEventClick(event, e as any)}
                    >
                      <ListItemButton sx={{ borderRadius: 1 }}>
                        <ListItemIcon sx={{ minWidth: 40 }}>
                          {event.type === 'assignment' && <AssignmentIcon color="primary" />}
                          {event.type === 'quiz' && <QuizIcon color="secondary" />}
                          {event.type === 'exam' && <SchoolIcon color="error" />}
                          {event.type === 'lecture' && <EventIcon color="info" />}
                          {event.type === 'meeting' && <EventIcon color="warning" />}
                          {event.type === 'other' && <EventIcon color="action" />}
                        </ListItemIcon>
                        <ListItemText 
                          primary={
                            <Box display="flex" alignItems="center">
                              <Typography variant="body1" component="span" sx={{ textDecoration: event.completed ? 'line-through' : 'none' }}>
                                {event.title}
                              </Typography>
                              {event.priority === 'high' && (
                                <Chip 
                                  label="High" 
                                  size="small" 
                                  color="error" 
                                  variant="outlined" 
                                  sx={{ ml: 1, height: 20, fontSize: '0.65rem' }} 
                                />
                              )}
                            </Box>
                          }
                          secondary={
                            <>
                              <Box component="span" display="flex" alignItems="center">
                                <Typography variant="caption" color="text.secondary">
                                  {format(new Date(event.start), 'h:mm a')} - {format(new Date(event.end), 'h:mm a')}
                                </Typography>
                                {event.course && (
                                  <Chip 
                                    label={event.course.name}
                                    size="small"
                                    variant="outlined"
                                    sx={{ 
                                      ml: 1, 
                                      height: 20, 
                                      fontSize: '0.65rem',
                                      borderLeft: `3px solid ${event.course.color}`,
                                      borderRadius: '4px',
                                    }} 
                                  />
                                )}
                              </Box>
                              {event.location && (
                                <Typography variant="caption" color="text.secondary" display="block">
                                  {event.location}
                                </Typography>
                              )}
                            </>
                          }
                        />
                        <ListItemSecondaryAction>
                          <IconButton 
                            edge="end" 
                            aria-label="more"
                            onClick={(e) => handleMenuClick(e, event)}
                          >
                            <MoreVertIcon />
                          </IconButton>
                        </ListItemSecondaryAction>
                      </ListItemButton>
                    </ListItem>
                  ))}
                </List>
              </Box>
            );
          })
        ) : (
          <Box 
            display="flex" 
            flexDirection="column" 
            alignItems="center" 
            justifyContent="center" 
            minHeight="300px"
            textAlign="center"
            p={4}
          >
            <EventIcon sx={{ fontSize: 60, color: 'text.disabled', mb: 2, opacity: 0.5 }} />
            <Typography variant="h6" color="text.secondary" gutterBottom>
              No events found
            </Typography>
            <Typography variant="body1" color="text.secondary" paragraph>
              {searchQuery || filterCourse !== 'all' || filterType !== 'all'
                ? 'Try adjusting your search or filters.'
                : 'You have no upcoming events. Add an event to get started.'}
            </Typography>
            <Button 
              variant="contained" 
              color="primary" 
              startIcon={<AddIcon />}
              onClick={() => setOpenAddDialog(true)}
            >
              Add Event
            </Button>
          </Box>
        )}
      </Box>
    );
  };
  
  // Render the day view (simplified for brevity)
  const renderDayView = () => {
    return (
      <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
        <Box sx={{ p: 2, borderBottom: 1, borderColor: 'divider' }}>
          <Typography variant="h6">
            {format(currentDate, 'EEEE, MMMM d, yyyy')}
          </Typography>
        </Box>
        <Box sx={{ flex: 1, overflowY: 'auto', p: 2 }}>
          <Typography variant="body1" color="text.secondary" align="center" sx={{ mt: 4 }}>
            Day view is not implemented yet. Please use Month or Agenda view.
          </Typography>
        </Box>
      </Box>
    );
  };
  
  // Render the week view (simplified for brevity)
  const renderWeekView = () => {
    return (
      <Box sx={{ flex: 1, display: 'flex', flexDirection: 'column' }}>
        <Box sx={{ p: 2, borderBottom: 1, borderColor: 'divider' }}>
          <Typography variant="h6">
            Week of {format(startOfWeek(currentDate, { weekStartsOn: 0 }), 'MMM d')} - {format(addDays(startOfWeek(currentDate, { weekStartsOn: 0 }), 6), 'MMM d, yyyy')}
          </Typography>
        </Box>
        <Box sx={{ flex: 1, overflowY: 'auto', p: 2 }}>
          <Typography variant="body1" color="text.secondary" align="center" sx={{ mt: 4 }}>
            Week view is not implemented yet. Please use Month or Agenda view.
          </Typography>
        </Box>
      </Box>
    );
  };
  
  // Render the current view
  const renderView = () => {
    switch (view) {
      case 'month':
        return renderMonthView();
      case 'week':
        return renderWeekView();
      case 'day':
        return renderDayView();
      case 'agenda':
        return renderAgendaView();
      default:
        return renderMonthView();
    }
  };
  
  return (
    <LocalizationProvider dateAdapter={AdapterDateFns}>
      <CalendarContainer>
        <Card>
          <CardHeader
            title={
              <Box display="flex" alignItems="center" flexWrap="wrap" gap={2}>
                <Typography variant="h5" component="h1">
                  Calendar
                </Typography>
                
                <Box display="flex" alignItems="center" gap={1} ml="auto">
                  <TextField
                    size="small"
                    placeholder="Search events..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    InputProps={{
                      startAdornment: <SearchIcon color="action" sx={{ mr: 1 }} />,
                      sx: { minWidth: 200 },
                    }}
                    sx={{ mr: 1 }}
                  />
                  
                  <TextField
                    select
                    size="small"
                    label="Course"
                    value={filterCourse}
                    onChange={(e) => setFilterCourse(e.target.value)}
                    sx={{ minWidth: 180, mr: 1 }}
                  >
                    <MenuItem value="all">All Courses</MenuItem>
                    {courses.map(course => (
                      <MenuItem key={course.id} value={course.id}>
                        {course.name}
                      </MenuItem>
                    ))}
                  </TextField>
                  
                  <TextField
                    select
                    size="small"
                    label="Type"
                    value={filterType}
                    onChange={(e) => setFilterType(e.target.value)}
                    sx={{ minWidth: 150 }}
                  >
                    <MenuItem value="all">All Types</MenuItem>
                    <MenuItem value="assignment">Assignments</MenuItem>
                    <MenuItem value="quiz">Quizzes</MenuItem>
                    <MenuItem value="exam">Exams</MenuItem>
                    <MenuItem value="lecture">Lectures</MenuItem>
                    <MenuItem value="meeting">Meetings</MenuItem>
                    <MenuItem value="other">Other</MenuItem>
                  </TextField>
                </Box>
              </Box>
            }
            action={
              <Box display="flex" alignItems="center" gap={1}>
                <Button 
                  variant={view === 'month' ? 'contained' : 'outlined'} 
                  size="small" 
                  startIcon={<ViewWeekIcon />}
                  onClick={() => setView('month')}
                >
                  {!isMobile && 'Month'}
                </Button>
                <Button 
                  variant={view === 'agenda' ? 'contained' : 'outlined'} 
                  size="small" 
                  startIcon={<ViewAgendaIcon />}
                  onClick={() => setView('agenda')}
                >
                  {!isMobile && 'Agenda'}
                </Button>
                {!isMobile && (
                  <>
                    <Button 
                      variant={view === 'week' ? 'contained' : 'outlined'} 
                      size="small" 
                      startIcon={<ViewWeekIcon />}
                      onClick={() => setView('week')}
                    >
                      Week
                    </Button>
                    <Button 
                      variant={view === 'day' ? 'contained' : 'outlined'} 
                      size="small" 
                      startIcon={<ViewDayIcon />}
                      onClick={() => setView('day')}
                    >
                      Day
                    </Button>
                  </>
                )}
              </Box>
            }
            sx={{
              borderBottom: 1,
              borderColor: 'divider',
              '& .MuiCardHeader-action': {
                alignSelf: 'center',
                m: 0,
              },
            }}
          />
          
          <Box sx={{ p: 2, borderBottom: 1, borderColor: 'divider' }}>
            <Box display="flex" alignItems="center" justifyContent="space-between">
              <Box display="flex" alignItems="center" gap={2}>
                <IconButton onClick={goToPreviousPeriod} size="small">
                  <ChevronLeftIcon />
                </IconButton>
                
                <Button 
                  variant="outlined" 
                  size="small" 
                  startIcon={<TodayIcon />}
                  onClick={goToToday}
                >
                  Today
                </Button>
                
                <IconButton onClick={goToNextPeriod} size="small">
                  <ChevronRightIcon />
                </IconButton>
                
                <Typography variant="h6" component="h2">
                  {view === 'month' 
                    ? `${monthNames[currentDate.getMonth()]} ${currentDate.getFullYear()}`
                    : view === 'week'
                    ? `Week of ${format(startOfWeek(currentDate, { weekStartsOn: 0 }), 'MMM d')}`
                    : format(currentDate, 'MMMM d, yyyy')}
                </Typography>
              </Box>
              
              <Button 
                variant="contained" 
                color="primary" 
                size="small" 
                startIcon={<AddIcon />}
                onClick={() => setOpenAddDialog(true)}
              >
                {!isMobile ? 'Add Event' : 'Add'}
              </Button>
            </Box>
          </Box>
          
          <Box sx={{ flex: 1, overflow: 'hidden' }} ref={calendarRef}>
            {renderView()}
          </Box>
        </Card>
        
        {/* Event Dialog */}
        <Dialog 
          open={openEventDialog} 
          onClose={() => setOpenEventDialog(false)}
          maxWidth="sm"
          fullWidth
        >
          {selectedEvent && (
            <>
              <DialogTitle sx={{ 
                backgroundColor: selectedEvent.course?.color || 'primary.main',
                color: 'white',
                py: 1.5,
                display: 'flex',
                justifyContent: 'space-between',
                alignItems: 'center',
              }}>
                <Box display="flex" alignItems="center">
                  {selectedEvent.type === 'assignment' && <AssignmentIcon sx={{ mr: 1 }} />}
                  {selectedEvent.type === 'quiz' && <QuizIcon sx={{ mr: 1 }} />}
                  {selectedEvent.type === 'exam' && <SchoolIcon sx={{ mr: 1 }} />}
                  {selectedEvent.type === 'lecture' && <EventIcon sx={{ mr: 1 }} />}
                  {selectedEvent.type === 'meeting' && <EventIcon sx={{ mr: 1 }} />}
                  {selectedEvent.type === 'other' && <EventIcon sx={{ mr: 1 }} />}
                  <span style={{ textTransform: 'capitalize' }}>
                    {selectedEvent.type}
                  </span>
                </Box>
                <IconButton 
                  edge="end" 
                  color="inherit" 
                  onClick={() => setOpenEventDialog(false)}
                  size="small"
                  sx={{ color: 'white' }}
                >
                  <CloseIcon />
                </IconButton>
              </DialogTitle>
              
              <DialogContent sx={{ pt: 3 }}>
                <Typography variant="h5" component="div" gutterBottom>
                  {selectedEvent.title}
                </Typography>
                
                {selectedEvent.course && (
                  <Chip 
                    label={selectedEvent.course.name}
                    size="small"
                    sx={{ 
                      mb: 2,
                      backgroundColor: `${selectedEvent.course.color}1a`,
                      color: selectedEvent.course.color,
                      borderLeft: `3px solid ${selectedEvent.course.color}`,
                      borderRadius: '4px',
                      fontWeight: 'medium',
                    }}
                  />
                )}
                
                <Box sx={{ mb: 3 }}>
                  <Box display="flex" alignItems="center" mb={1}>
                    <CalendarTodayIcon color="action" sx={{ mr: 1, fontSize: 20 }} />
                    <Typography variant="body1">
                      {selectedEvent.allDay 
                        ? format(new Date(selectedEvent.start), 'EEEE, MMMM d, yyyy')
                        : `${format(new Date(selectedEvent.start), 'EEEE, MMMM d, yyyy • h:mm a')} - 
                           ${format(new Date(selectedEvent.end), 'h:mm a')}`}
                    </Typography>
                  </Box>
                  
                  {selectedEvent.location && (
                    <Box display="flex" alignItems="center" mb={1}>
                      <RoomIcon color="action" sx={{ mr: 1, fontSize: 20 }} />
                      <Typography variant="body1">
                        {selectedEvent.location}
                      </Typography>
                    </Box>
                  )}
                  
                  {selectedEvent.url && (
                    <Box display="flex" alignItems="center" mb={1}>
                      <LinkIcon color="action" sx={{ mr: 1, fontSize: 20 }} />
                      <Link href={selectedEvent.url} target="_blank" rel="noopener noreferrer">
                        {selectedEvent.url}
                      </Link>
                    </Box>
                  )}
                </Box>
                
                {selectedEvent.description && (
                  <Box sx={{ mb: 3 }}>
                    <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                      DESCRIPTION
                    </Typography>
                    <Typography variant="body1" paragraph>
                      {selectedEvent.description}
                    </Typography>
                  </Box>
                )}
                
                {selectedEvent.notes && (
                  <Box sx={{ mb: 3 }}>
                    <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                      NOTES
                    </Typography>
                    <Paper variant="outlined" sx={{ p: 2, backgroundColor: 'background.default' }}>
                      <Typography variant="body1">
                        {selectedEvent.notes}
                      </Typography>
                    </Paper>
                  </Box>
                )}
                
                {selectedEvent.attachments && selectedEvent.attachments.length > 0 && (
                  <Box sx={{ mb: 3 }}>
                    <Typography variant="subtitle2" color="text.secondary" gutterBottom>
                      ATTACHMENTS ({selectedEvent.attachments.length})
                    </Typography>
                    <List dense disablePadding>
                      {selectedEvent.attachments.map((file, index) => (
                        <ListItem 
                          key={index} 
                          button 
                          component="a" 
                          href={file.url} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          sx={{
                            border: '1px solid',
                            borderColor: 'divider',
                            borderRadius: 1,
                            mb: 1,
                            '&:hover': {
                              backgroundColor: 'action.hover',
                            },
                          }}
                        >
                          <ListItemIcon>
                            <DescriptionIcon color="primary" />
                          </ListItemIcon>
                          <ListItemText 
                            primary={file.name}
                            secondary={`${file.type.toUpperCase()} • ${file.size}`}
                          />
                          <GetAppIcon color="action" />
                        </ListItem>
                      ))}
                    </List>
                  </Box>
                )}
              </DialogContent>
              
              <DialogActions sx={{ p: 2, borderTop: 1, borderColor: 'divider' }}>
                <Box display="flex" justifyContent="space-between" width="100%">
                  <Box>
                    <FormControlLabel
                      control={
                        <Checkbox
                          checked={!!selectedEvent.completed}
                          onChange={handleToggleComplete}
                          color="primary"
                          icon={<RadioButtonUncheckedIcon />}
                          checkedIcon={<CheckCircleIcon />}
                        />
                      }
                      label={selectedEvent.completed ? 'Completed' : 'Mark as completed'}
                    />
                  </Box>
                  <Box>
                    <Button 
                      onClick={handleEditEvent}
                      startIcon={<EditIcon />}
                      sx={{ mr: 1 }}
                    >
                      Edit
                    </Button>
                    <Button 
                      onClick={handleDeleteEvent}
                      startIcon={<DeleteIcon />}
                      color="error"
                    >
                      Delete
                    </Button>
                  </Box>
                </Box>
              </DialogActions>
            </>
          )}
        </Dialog>
        
        {/* Add/Edit Event Dialog */}
        <Dialog 
          open={openAddDialog} 
          onClose={() => setOpenAddDialog(false)}
          maxWidth="sm"
          fullWidth
        >
          <form onSubmit={handleEventFormSubmit}>
            <DialogTitle sx={{ 
              backgroundColor: 'primary.main',
              color: 'white',
              py: 1.5,
              display: 'flex',
              justifyContent: 'space-between',
              alignItems: 'center',
            }}>
              <Box display="flex" alignItems="center">
                <AddIcon sx={{ mr: 1 }} />
                Add New Event
              </Box>
              <IconButton 
                edge="end" 
                color="inherit" 
                onClick={() => setOpenAddDialog(false)}
                size="small"
                sx={{ color: 'white' }}
              >
                <CloseIcon />
              </IconButton>
            </DialogTitle>
            
            <DialogContent sx={{ pt: 3 }}>
              <Grid container spacing={2}>
                <Grid item xs={12}>
                  <TextField
                    autoFocus
                    margin="dense"
                    id="title"
                    label="Event Title"
                    type="text"
                    fullWidth
                    variant="outlined"
                    value={eventForm.title}
                    onChange={(e) => setEventForm({ ...eventForm, title: e.target.value })}
                    required
                  />
                </Grid>
                
                <Grid item xs={12} sm={6}>
                  <FormControl fullWidth margin="dense">
                    <InputLabel id="event-type-label">Event Type</InputLabel>
                    <Select
                      labelId="event-type-label"
                      id="event-type"
                      value={eventForm.type}
                      label="Event Type"
                      onChange={(e) => setEventForm({ ...eventForm, type: e.target.value as EventType })}
                      required
                    >
                      <MenuItem value="assignment">Assignment</MenuItem>
                      <MenuItem value="quiz">Quiz</MenuItem>
                      <MenuItem value="exam">Exam</MenuItem>
                      <MenuItem value="lecture">Lecture</MenuItem>
                      <MenuItem value="meeting">Meeting</MenuItem>
                      <MenuItem value="other">Other</MenuItem>
                    </Select>
                  </FormControl>
                </Grid>
                
                <Grid item xs={12} sm={6}>
                  <FormControl fullWidth margin="dense">
                    <InputLabel id="course-label">Course (Optional)</InputLabel>
                    <Select
                      labelId="course-label"
                      id="course"
                      value={eventForm.course?.id || ''}
                      label="Course (Optional)"
                      onChange={(e) => {
                        const course = courses.find(c => c.id === e.target.value);
                        setEventForm({ 
                          ...eventForm, 
                          course: course || undefined 
                        });
                      }}
                    >
                      <MenuItem value="">
                        <em>None</em>
                      </MenuItem>
                      {courses.map(course => (
                        <MenuItem key={course.id} value={course.id}>
                          {course.name}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>
                </Grid>
                
                <Grid item xs={12}>
                  <FormControlLabel
                    control={
                      <Switch
                        checked={eventForm.allDay || false}
                        onChange={(e) => setEventForm({ ...eventForm, allDay: e.target.checked })}
                        color="primary"
                      />
                    }
                    label="All day event"
                  />
                </Grid>
                
                <Grid item xs={12} sm={6}>
                  {eventForm.allDay ? (
                    <DatePicker
                      label="Start Date"
                      value={eventForm.start}
                      onChange={(date) => {
                        if (date) {
                          const newStart = new Date(date);
                          const newEnd = new Date(newStart);
                          newEnd.setDate(newStart.getDate() + 1);
                          setEventForm({ 
                            ...eventForm, 
                            start: newStart,
                            end: newEnd,
                          });
                        }
                      }}
                      renderInput={(params) => (
                        <TextField 
                          {...params} 
                          fullWidth 
                          margin="dense" 
                          required 
                        />
                      )}
                    />
                  ) : (
                    <>
                      <DatePicker
                        label="Start Date"
                        value={eventForm.start}
                        onChange={(date) => {
                          if (date) {
                            const newStart = new Date(date);
                            const newEnd = new Date(eventForm.end || newStart);
                            
                            // If the date part changed, update both dates
                            if (newStart.toDateString() !== new Date(eventForm.start || new Date()).toDateString()) {
                              newEnd.setDate(newStart.getDate());
                            }
                            
                            setEventForm({ 
                              ...eventForm, 
                              start: newStart,
                              end: newEnd,
                            });
                          }
                        }}
                        renderInput={(params) => (
                          <TextField 
                            {...params} 
                            fullWidth 
                            margin="dense" 
                            required 
                          />
                        )}
                      />
                      
                      <TimePicker
                        label="Start Time"
                        value={eventForm.start}
                        onChange={(date) => {
                          if (date) {
                            const newStart = new Date(date);
                            const newEnd = new Date(eventForm.end || newStart);
                            
                            // Update the time part of the start date
                            const newDateTime = new Date(eventForm.start || new Date());
                            newDateTime.setHours(newStart.getHours(), newStart.getMinutes(), 0, 0);
                            
                            // If the new start time is after the end time, adjust the end time
                            if (newDateTime > newEnd) {
                              newEnd.setHours(newStart.getHours() + 1, newStart.getMinutes(), 0, 0);
                            }
                            
                            setEventForm({ 
                              ...eventForm, 
                              start: newDateTime,
                              end: newEnd,
                            });
                          }
                        }}
                        renderInput={(params) => (
                          <TextField 
                            {...params} 
                            fullWidth 
                            margin="dense" 
                            required 
                          />
                        )}
                      />
                    </>
                  )}
                </Grid>
                
                {!eventForm.allDay && (
                  <Grid item xs={12} sm={6}>
                    <DatePicker
                      label="End Date"
                      value={eventForm.end}
                      onChange={(date) => {
                        if (date) {
                          const newEnd = new Date(date);
                          setEventForm({ 
                            ...eventForm, 
                            end: newEnd,
                          });
                        }
                      }}
                      renderInput={(params) => (
                        <TextField 
                          {...params} 
                          fullWidth 
                          margin="dense" 
                          required 
                        />
                      )}
                    />
                    
                    <TimePicker
                      label="End Time"
                      value={eventForm.end}
                      onChange={(date) => {
                        if (date) {
                          const newEnd = new Date(date);
                          const newEndTime = new Date(eventForm.end || new Date());
                          newEndTime.setHours(newEnd.getHours(), newEnd.getMinutes(), 0, 0);
                          
                          setEventForm({ 
                            ...eventForm, 
                            end: newEndTime,
                          });
                        }
                      }}
                      renderInput={(params) => (
                        <TextField 
                          {...params} 
                          fullWidth 
                          margin="dense" 
                          required 
                        />
                      )}
                    />
                  </Grid>
                )}
                
                <Grid item xs={12}>
                  <TextField
                    margin="dense"
                    id="location"
                    label="Location"
                    type="text"
                    fullWidth
                    variant="outlined"
                    value={eventForm.location || ''}
                    onChange={(e) => setEventForm({ ...eventForm, location: e.target.value })}
                  />
                </Grid>
                
                <Grid item xs={12}>
                  <TextField
                    margin="dense"
                    id="url"
                    label="URL"
                    type="url"
                    fullWidth
                    variant="outlined"
                    value={eventForm.url || ''}
                    onChange={(e) => setEventForm({ ...eventForm, url: e.target.value })}
                  />
                </Grid>
                
                <Grid item xs={12}>
                  <TextField
                    margin="dense"
                    id="description"
                    label="Description"
                    multiline
                    rows={3}
                    fullWidth
                    variant="outlined"
                    value={eventForm.description || ''}
                    onChange={(e) => setEventForm({ ...eventForm, description: e.target.value })}
                  />
                </Grid>
                
                <Grid item xs={12} sm={6}>
                  <FormControl fullWidth margin="dense">
                    <InputLabel id="priority-label">Priority</InputLabel>
                    <Select
                      labelId="priority-label"
                      id="priority"
                      value={eventForm.priority || 'medium'}
                      label="Priority"
                      onChange={(e) => setEventForm({ ...eventForm, priority: e.target.value as 'low' | 'medium' | 'high' })}
                    >
                      <MenuItem value="low">Low</MenuItem>
                      <MenuItem value="medium">Medium</MenuItem>
                      <MenuItem value="high">High</MenuItem>
                    </Select>
                  </FormControl>
                </Grid>
                
                <Grid item xs={12} sm={6}>
                  <FormControl fullWidth margin="dense">
                    <InputLabel id="reminder-label">Reminder</InputLabel>
                    <Select
                      labelId="reminder-label"
                      id="reminder"
                      value={eventForm.reminder ? 'custom' : 'none'}
                      label="Reminder"
                      onChange={(e) => {
                        if (e.target.value === 'none') {
                          setEventForm({ ...eventForm, reminder: null });
                        } else {
                          // Set a default reminder (e.g., 30 minutes before)
                          const reminderTime = new Date(eventForm.start || new Date());
                          reminderTime.setMinutes(reminderTime.getMinutes() - 30);
                          setEventForm({ ...eventForm, reminder: reminderTime });
                        }
                      }}
                    >
                      <MenuItem value="none">None</MenuItem>
                      <MenuItem value="5min">5 minutes before</MenuItem>
                      <MenuItem value="15min">15 minutes before</MenuItem>
                      <MenuItem value="30min">30 minutes before</MenuItem>
                      <MenuItem value="1hour">1 hour before</MenuItem>
                      <MenuItem value="1day">1 day before</MenuItem>
                      <MenuItem value="custom">Custom</MenuItem>
                    </Select>
                  </FormControl>
                </Grid>
                
                {eventForm.reminder && (
                  <Grid item xs={12}>
                    <DatePicker
                      label="Reminder Date & Time"
                      value={eventForm.reminder}
                      onChange={(date) => {
                        if (date) {
                          setEventForm({ 
                            ...eventForm, 
                            reminder: new Date(date),
                          });
                        }
                      }}
                      renderInput={(params) => (
                        <TextField 
                          {...params} 
                          fullWidth 
                          margin="dense" 
                        />
                      )}
                    />
                  </Grid>
                )}
                
                <Grid item xs={12}>
                  <FormControlLabel
                    control={
                      <Checkbox
                        checked={eventForm.repeat !== undefined}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setEventForm({ 
                              ...eventForm, 
                              repeat: {
                                frequency: 'weekly',
                                interval: 1,
                                endDate: new Date(new Date().setFullYear(new Date().getFullYear() + 1)),
                              },
                            });
                          } else {
                            const { repeat, ...rest } = eventForm;
                            setEventForm(rest);
                          }
                        }}
                        color="primary"
                      />
                    }
                    label="Repeat"
                  />
                  
                  {eventForm.repeat && (
                    <Box mt={1} ml={4}>
                      <FormControl fullWidth margin="dense">
                        <InputLabel id="repeat-frequency-label">Repeat every</InputLabel>
                        <Select
                          labelId="repeat-frequency-label"
                          id="repeat-frequency"
                          value={eventForm.repeat.frequency}
                          label="Repeat every"
                          onChange={(e) => {
                            setEventForm({
                              ...eventForm,
                              repeat: {
                                ...eventForm.repeat!,
                                frequency: e.target.value as 'daily' | 'weekly' | 'monthly' | 'yearly',
                              },
                            });
                          }}
                        >
                          <MenuItem value="daily">Day</MenuItem>
                          <MenuItem value="weekly">Week</MenuItem>
                          <MenuItem value="monthly">Month</MenuItem>
                          <MenuItem value="yearly">Year</MenuItem>
                        </Select>
                      </FormControl>
                      
                      <Box mt={2}>
                        <Typography variant="subtitle2" gutterBottom>
                          End
                        </Typography>
                        <FormControl fullWidth margin="dense">
                          <InputLabel id="repeat-end-label">Ends</InputLabel>
                          <Select
                            labelId="repeat-end-label"
                            id="repeat-end"
                            value={eventForm.repeat.endDate ? 'on' : 'never'}
                            label="Ends"
                            onChange={(e) => {
                              setEventForm({
                                ...eventForm,
                                repeat: {
                                  ...eventForm.repeat!,
                                  endDate: e.target.value === 'on' ? new Date() : undefined,
                                },
                              });
                            }}
                          >
                            <MenuItem value="never">Never</MenuItem>
                            <MenuItem value="on">On</MenuItem>
                          </Select>
                        </FormControl>
                        
                        {eventForm.repeat.endDate && (
                          <Box mt={1}>
                            <DatePicker
                              label="End Date"
                              value={eventForm.repeat.endDate}
                              onChange={(date) => {
                                if (date) {
                                  setEventForm({
                                    ...eventForm,
                                    repeat: {
                                      ...eventForm.repeat!,
                                      endDate: new Date(date),
                                    },
                                  });
                                }
                              }}
                              renderInput={(params) => (
                                <TextField 
                                  {...params} 
                                  fullWidth 
                                  margin="dense" 
                                />
                              )}
                            />
                          </Box>
                        )}
                      </Box>
                    </Box>
                  )}
                </Grid>
              </Grid>
            </DialogContent>
            
            <DialogActions sx={{ p: 2, borderTop: 1, borderColor: 'divider' }}>
              <Button onClick={() => setOpenAddDialog(false)}>
                Cancel
              </Button>
              <Button type="submit" variant="contained" color="primary">
                Save
              </Button>
            </DialogActions>
          </form>
        </Dialog>
        
        {/* Event Menu */}
        <Menu
          id="event-menu"
          anchorEl={anchorEl}
          open={Boolean(anchorEl)}
          onClose={handleMenuClose}
          onClick={handleMenuClose}
          MenuListProps={{
            'aria-labelledby': 'event-menu-button',
          }}
        >
          <MenuItem onClick={handleEditEvent}>
            <ListItemIcon>
              <EditIcon fontSize="small" />
            </ListItemIcon>
            <ListItemText>Edit</ListItemText>
          </MenuItem>
          <MenuItem onClick={handleDeleteEvent}>
            <ListItemIcon>
              <DeleteIcon fontSize="small" color="error" />
            </ListItemIcon>
            <ListItemText primaryTypographyProps={{ color: 'error' }}>
              Delete
            </ListItemText>
          </MenuItem>
          <Divider />
          <MenuItem onClick={handleToggleComplete}>
            <ListItemIcon>
              {selectedEvent?.completed ? (
                <RadioButtonUncheckedIcon fontSize="small" />
              ) : (
                <CheckCircleIcon fontSize="small" color="primary" />
              )}
            </ListItemIcon>
            <ListItemText>
              {selectedEvent?.completed ? 'Mark as incomplete' : 'Mark as completed'}
            </ListItemText>
          </MenuItem>
        </Menu>
        
        {/* Add Event FAB */}
        <Zoom in={!openAddDialog}>
          <Fab
            color="primary"
            aria-label="add event"
            sx={{
              position: 'fixed',
              bottom: 24,
              right: 24,
            }}
            onClick={() => setOpenAddDialog(true)}
          >
            <AddIcon />
          </Fab>
        </Zoom>
      </CalendarContainer>
    </LocalizationProvider>
  );
};

export default CalendarPage;
