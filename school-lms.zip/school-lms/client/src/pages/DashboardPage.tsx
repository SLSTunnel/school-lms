import React from 'react';
import { Container, Grid, Card, CardContent, Typography, Box, Button } from '@mui/material';
import { styled } from '@mui/material/styles';
import {
  School as SchoolIcon,
  Assignment as AssignmentIcon,
  Assessment as AssessmentIcon,
  Notifications as NotificationsIcon,
  Event as EventIcon
} from '@mui/icons-material';

const StyledCard = styled(Card)(({ theme }) => ({
  height: '100%',
  display: 'flex',
  flexDirection: 'column',
  transition: 'transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out',
  '&:hover': {
    transform: 'translateY(-5px)',
    boxShadow: theme.shadows[8],
  },
}));

const DashboardPage: React.FC = () => {
  const stats = [
    { 
      title: 'Active Courses', 
      value: '12', 
      icon: <SchoolIcon color="primary" fontSize="large" />,
      color: 'primary.main',
      change: { value: '+2', isPositive: true }
    },
    { 
      title: 'Pending Assignments', 
      value: '5', 
      icon: <AssignmentIcon color="warning" fontSize="large" />,
      color: 'warning.main',
      change: { value: '2 overdue', isPositive: false }
    },
    { 
      title: 'Average Grade', 
      value: '87%', 
      icon: <AssessmentIcon color="success" fontSize="large" />,
      color: 'success.main',
      change: { value: '+5%', isPositive: true }
    },
    { 
      title: 'Upcoming Events', 
      value: '3', 
      icon: <EventIcon color="info" fontSize="large" />,
      color: 'info.main',
      change: { value: 'This week', isPositive: null }
    },
  ];

  return (
    <Container maxWidth="xl" sx={{ mt: 4, mb: 4 }}>
      <Box display="flex" justifyContent="space-between" alignItems="center" mb={4}>
        <Typography variant="h4" component="h1">
          Welcome back, John!
        </Typography>
        <Button variant="contained" color="primary" startIcon={<NotificationsIcon />}>
          View Notifications
        </Button>
      </Box>

      {/* Stats Grid */}
      <Grid container spacing={3} mb={4}>
        {stats.map((stat, index) => (
          <Grid item xs={12} sm={6} md={3} key={index}>
            <StyledCard>
              <CardContent>
                <Box display="flex" justifyContent="space-between" alignItems="center" mb={2}>
                  <Box
                    sx={{
                      width: 56,
                      height: 56,
                      borderRadius: 1,
                      bgcolor: `${stat.color}20`,
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                    }}
                  >
                    {stat.icon}
                  </Box>
                  <Box textAlign="right">
                    <Typography variant="h5" component="div">
                      {stat.value}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {stat.title}
                    </Typography>
                  </Box>
                </Box>
                <Typography 
                  variant="caption" 
                  color={stat.change.isPositive === null ? 'text.secondary' : stat.change.isPositive ? 'success.main' : 'error.main'}
                >
                  {stat.change.isPositive === true ? '↑' : stat.change.isPositive === false ? '⚠' : ''} {stat.change.value}
                </Typography>
              </CardContent>
            </StyledCard>
          </Grid>
        ))}
      </Grid>

      {/* Recent Activity & Upcoming Deadlines */}
      <Grid container spacing={3}>
        <Grid item xs={12} md={8}>
          <StyledCard>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Recent Activity
              </Typography>
              {/* Activity list would go here */}
              <Box textAlign="center" py={4}>
                <Typography color="text.secondary">
                  Recent activity will appear here
                </Typography>
              </Box>
            </CardContent>
          </StyledCard>
        </Grid>
        <Grid item xs={12} md={4}>
          <StyledCard>
            <CardContent>
              <Typography variant="h6" gutterBottom>
                Upcoming Deadlines
              </Typography>
              {/* Deadlines list would go here */}
              <Box textAlign="center" py={4}>
                <Typography color="text.secondary">
                  Upcoming deadlines will appear here
                </Typography>
              </Box>
            </CardContent>
          </StyledCard>
        </Grid>
      </Grid>
    </Container>
  );
};

export default DashboardPage;
