import React, { useState } from 'react';
import {
  Container,
  Typography,
  Box,
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TableSortLabel,
  TablePagination,
  Chip,
  Avatar,
  TextField,
  InputAdornment,
  Menu,
  MenuItem,
  IconButton,
  Button,
  Divider,
  Tabs,
  Tab,
  LinearProgress,
  Tooltip,
  useTheme,
} from '@mui/material';
import {
  Search as SearchIcon,
  FilterList as FilterListIcon,
  MoreVert as MoreVertIcon,
  Download as DownloadIcon,
  Print as PrintIcon,
  Assessment as AssessmentIcon,
  School as SchoolIcon,
  Star as StarIcon,
  StarBorder as StarBorderIcon,
  CheckCircle as CheckCircleIcon,
  Warning as WarningIcon,
  Info as InfoIcon,
  ArrowUpward as ArrowUpwardIcon,
  ArrowDownward as ArrowDownwardIcon,
  Remove as RemoveIcon,
} from '@mui/icons-material';
import { styled } from '@mui/material/styles';

// Types
type Grade = {
  id: string;
  assignment: {
    id: string;
    title: string;
    type: 'assignment' | 'quiz' | 'exam' | 'project' | 'participation';
    maxPoints: number;
    weight: number;
    dueDate: string;
  };
  course: {
    id: string;
    name: string;
    code: string;
    instructor: string;
  };
  score: number | null;
  letterGrade: string | null;
  status: 'graded' | 'submitted' | 'missing' | 'excused' | 'incomplete';
  feedback?: string;
  classAverage?: number;
  percentile?: number;
  submissionDate?: string;
  gradedDate?: string;
};

// Mock data
const grades: Grade[] = [
  {
    id: 'g1',
    assignment: {
      id: 'a1',
      title: 'Problem Set 1: Limits',
      type: 'assignment',
      maxPoints: 100,
      weight: 15,
      dueDate: '2023-09-15T23:59:00',
    },
    course: {
      id: 'math101',
      name: 'Calculus I',
      code: 'MATH-101',
      instructor: 'Dr. Sarah Johnson',
    },
    score: 92,
    letterGrade: 'A-',
    status: 'graded',
    feedback: 'Excellent work! Your solutions were clear and well-reasoned.',
    classAverage: 84.5,
    percentile: 85,
    submissionDate: '2023-09-14T18:30:00',
    gradedDate: '2023-09-16T14:20:00',
  },
  {
    id: 'g2',
    assignment: {
      id: 'q1',
      title: 'Chapter 1 Quiz',
      type: 'quiz',
      maxPoints: 50,
      weight: 10,
      dueDate: '2023-09-20T23:59:00',
    },
    course: {
      id: 'math101',
      name: 'Calculus I',
      code: 'MATH-101',
      instructor: 'Dr. Sarah Johnson',
    },
    score: 48,
    letterGrade: 'A',
    status: 'graded',
    classAverage: 42.3,
    percentile: 92,
    submissionDate: '2023-09-20T15:30:00',
    gradedDate: '2023-09-21T10:15:00',
  },
  {
    id: 'g3',
    assignment: {
      id: 'a2',
      title: 'Problem Set 2: Derivatives',
      type: 'assignment',
      maxPoints: 100,
      weight: 15,
      dueDate: '2023-10-01T23:59:00',
    },
    course: {
      id: 'math101',
      name: 'Calculus I',
      code: 'MATH-101',
      instructor: 'Dr. Sarah Johnson',
    },
    score: null,
    letterGrade: null,
    status: 'submitted',
    submissionDate: '2023-09-30T22:15:00',
  },
  {
    id: 'g4',
    assignment: {
      id: 'mid1',
      title: 'Midterm Exam',
      type: 'exam',
      maxPoints: 200,
      weight: 25,
      dueDate: '2023-10-15T09:00:00',
    },
    course: {
      id: 'math101',
      name: 'Calculus I',
      code: 'MATH-101',
      instructor: 'Dr. Sarah Johnson',
    },
    score: null,
    letterGrade: null,
    status: 'upcoming',
  },
  {
    id: 'g5',
    assignment: {
      id: 'p1',
      title: 'Research Paper',
      type: 'project',
      maxPoints: 150,
      weight: 20,
      dueDate: '2023-10-05T23:59:00',
    },
    course: {
      id: 'eng201',
      name: 'Academic Writing',
      code: 'ENG-201',
      instructor: 'Prof. Michael Chen',
    },
    score: 135,
    letterGrade: 'A',
    status: 'graded',
    feedback: 'Well-researched and clearly written. Excellent analysis!',
    classAverage: 118.7,
    percentile: 88,
    submissionDate: '2023-10-04T21:30:00',
    gradedDate: '2023-10-08T16:45:00',
  },
  {
    id: 'g6',
    assignment: {
      id: 'p2',
      title: 'Group Presentation',
      type: 'project',
      maxPoints: 100,
      weight: 15,
      dueDate: '2023-10-10T14:30:00',
    },
    course: {
      id: 'eng201',
      name: 'Academic Writing',
      code: 'ENG-201',
      instructor: 'Prof. Michael Chen',
    },
    score: 92,
    letterGrade: 'A-',
    status: 'graded',
    feedback: 'Great teamwork and presentation skills. Well done!',
    classAverage: 87.2,
    percentile: 75,
    submissionDate: '2023-10-10T14:15:00',
    gradedDate: '2023-10-12T11:20:00',
  },
  {
    id: 'g7',
    assignment: {
      id: 'a3',
      title: 'Weekly Reflection',
      type: 'assignment',
      maxPoints: 30,
      weight: 5,
      dueDate: '2023-10-12T23:59:00',
    },
    course: {
      id: 'eng201',
      name: 'Academic Writing',
      code: 'ENG-201',
      instructor: 'Prof. Michael Chen',
    },
    score: null,
    letterGrade: null,
    status: 'missing',
  },
  {
    id: 'g8',
    assignment: {
      id: 'q1',
      title: 'Module 1 Quiz',
      type: 'quiz',
      maxPoints: 50,
      weight: 10,
      dueDate: '2023-09-25T23:59:00',
    },
    course: {
      id: 'cs101',
      name: 'Introduction to Computer Science',
      code: 'CS-101',
      instructor: 'Dr. Emily Wilson',
    },
    score: 45,
    letterGrade: 'A-',
    status: 'graded',
    classAverage: 39.8,
    percentile: 82,
    submissionDate: '2023-09-25T20:15:00',
    gradedDate: '2023-09-26T14:30:00',
  },
  {
    id: 'g9',
    assignment: {
      id: 'p1',
      title: 'Programming Project 1',
      type: 'project',
      maxPoints: 100,
      weight: 20,
      dueDate: '2023-10-08T23:59:00',
    },
    course: {
      id: 'cs101',
      name: 'Introduction to Computer Science',
      code: 'CS-101',
      instructor: 'Dr. Emily Wilson',
    },
    score: 98,
    letterGrade: 'A+',
    status: 'graded',
    feedback: 'Excellent implementation and documentation!',
    classAverage: 85.6,
    percentile: 95,
    submissionDate: '2023-10-07T18:45:00',
    gradedDate: '2023-10-10T10:15:00',
  },
  {
    id: 'g10',
    assignment: {
      id: 'p2',
      title: 'Group Project: Web Application',
      type: 'project',
      maxPoints: 150,
      weight: 25,
      dueDate: '2023-11-15T23:59:00',
    },
    course: {
      id: 'cs101',
      name: 'Introduction to Computer Science',
      code: 'CS-101',
      instructor: 'Dr. Emily Wilson',
    },
    score: null,
    letterGrade: null,
    status: 'upcoming',
  },
];

// Course summary type
type CourseSummary = {
  id: string;
  name: string;
  code: string;
  instructor: string;
  credits: number;
  currentGrade: string | null;
  currentPercentage: number | null;
  assignments: number;
  assignmentsGraded: number;
  assignmentsMissing: number;
  assignmentsUpcoming: number;
  lastUpdated: string;
};

// Mock course summaries
const courseSummaries: CourseSummary[] = [
  {
    id: 'math101',
    name: 'Calculus I',
    code: 'MATH-101',
    instructor: 'Dr. Sarah Johnson',
    credits: 4,
    currentGrade: 'A-',
    currentPercentage: 92.5,
    assignments: 4,
    assignmentsGraded: 2,
    assignmentsMissing: 0,
    assignmentsUpcoming: 2,
    lastUpdated: '2023-09-21T10:15:00',
  },
  {
    id: 'eng201',
    name: 'Academic Writing',
    code: 'ENG-201',
    instructor: 'Prof. Michael Chen',
    credits: 3,
    currentGrade: 'A-',
    currentPercentage: 90.2,
    assignments: 3,
    assignmentsGraded: 2,
    assignmentsMissing: 1,
    assignmentsUpcoming: 0,
    lastUpdated: '2023-10-12T11:20:00',
  },
  {
    id: 'cs101',
    name: 'Introduction to Computer Science',
    code: 'CS-101',
    instructor: 'Dr. Emily Wilson',
    credits: 4,
    currentGrade: 'A',
    currentPercentage: 95.7,
    assignments: 3,
    assignmentsGraded: 2,
    assignmentsMissing: 0,
    assignmentsUpcoming: 1,
    lastUpdated: '2023-10-10T10:15:00',
  },
];

// Styled components
const StyledTableRow = styled(TableRow)(({ theme }) => ({
  '&:nth-of-type(odd)': {
    backgroundColor: theme.palette.action.hover,
  },
  '&:hover': {
    backgroundColor: theme.palette.action.selected,
    cursor: 'pointer',
  },
}));

const GradeChip = styled(Chip)(({ theme, score, maxScore }) => {
  if (score === null) return {};
  
  const percentage = (score / maxScore) * 100;
  
  if (percentage >= 90) {
    return {
      backgroundColor: theme.palette.success.light,
      color: theme.palette.success.dark,
      fontWeight: 'bold',
    };
  } else if (percentage >= 80) {
    return {
      backgroundColor: theme.palette.info.light,
      color: theme.palette.info.dark,
      fontWeight: 'bold',
    };
  } else if (percentage >= 70) {
    return {
      backgroundColor: theme.palette.warning.light,
      color: theme.palette.warning.dark,
      fontWeight: 'bold',
    };
  } else {
    return {
      backgroundColor: theme.palette.error.light,
      color: theme.palette.error.dark,
      fontWeight: 'bold',
    };
  }
});

const GradeTrend = ({ current, previous }) => {
  if (current === null || previous === null) return <RemoveIcon color="action" />;
  
  if (current > previous) {
    return <ArrowUpwardIcon color="success" />;
  } else if (current < previous) {
    return <ArrowDownwardIcon color="error" />;
  } else {
    return <RemoveIcon color="action" />;
  }
};

const GradesPage: React.FC = () => {
  const theme = useTheme();
  const [searchTerm, setSearchTerm] = useState('');
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [orderBy, setOrderBy] = useState('dueDate');
  const [order, setOrder] = useState<'asc' | 'desc'>('desc');
  const [selectedCourse, setSelectedCourse] = useState<string | null>(null);
  const [selectedType, setSelectedType] = useState<string>('all');
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);
  const [selectedGrade, setSelectedGrade] = useState<Grade | null>(null);
  const [activeTab, setActiveTab] = useState(0);

  const handleRequestSort = (property: string) => {
    const isAsc = orderBy === property && order === 'asc';
    setOrder(isAsc ? 'desc' : 'asc');
    setOrderBy(property);
  };

  const handleChangePage = (event: unknown, newPage: number) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event: React.ChangeEvent<HTMLInputElement>) => {
    setRowsPerPage(parseInt(event.target.value, 10));
    setPage(0);
  };

  const handleMenuClick = (event: React.MouseEvent<HTMLElement>, grade: Grade) => {
    setAnchorEl(event.currentTarget);
    setSelectedGrade(grade);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setActiveTab(newValue);
    setPage(0);
  };

  const handleCourseFilter = (courseId: string | null) => {
    setSelectedCourse(courseId);
    setPage(0);
  };

  const handleTypeFilter = (type: string) => {
    setSelectedType(type);
    setPage(0);
  };

  // Filter and sort grades
  const filteredGrades = grades.filter(grade => {
    const matchesSearch = grade.assignment.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         grade.course.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         grade.course.code.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesCourse = !selectedCourse || grade.course.id === selectedCourse;
    const matchesType = selectedType === 'all' || grade.assignment.type === selectedType;
    const matchesTab = 
      (activeTab === 0) || // All
      (activeTab === 1 && grade.status === 'graded') || // Graded
      (activeTab === 2 && grade.status === 'submitted') || // Submitted
      (activeTab === 3 && grade.status === 'missing') || // Missing
      (activeTab === 4 && grade.status === 'upcoming'); // Upcoming
    
    return matchesSearch && matchesCourse && matchesType && matchesTab;
  });

  const sortedGrades = [...filteredGrades].sort((a, b) => {
    let comparison = 0;
    
    switch (orderBy) {
      case 'title':
        comparison = a.assignment.title.localeCompare(b.assignment.title);
        break;
      case 'course':
        comparison = a.course.name.localeCompare(b.course.name);
        break;
      case 'dueDate':
        comparison = new Date(a.assignment.dueDate).getTime() - new Date(b.assignment.dueDate).getTime();
        break;
      case 'score':
        comparison = (a.score || 0) - (b.score || 0);
        break;
      case 'status':
        comparison = a.status.localeCompare(b.status);
        break;
      default:
        comparison = 0;
    }
    
    return order === 'asc' ? comparison : -comparison;
  });

  const paginatedGrades = sortedGrades.slice(
    page * rowsPerPage,
    page * rowsPerPage + rowsPerPage
  );

  // Calculate overall statistics
  const totalAssignments = grades.length;
  const gradedAssignments = grades.filter(g => g.status === 'graded').length;
  const averageGrade = grades.length > 0 
    ? grades.reduce((sum, g) => sum + (g.score || 0), 0) / 
      grades.reduce((sum, g) => sum + (g.score !== null ? 1 : 0), 0)
    : 0;
  const currentGPA = 3.8; // Mock GPA
  const previousGPA = 3.7; // Mock previous GPA

  // Calculate course statistics
  const getCourseStats = (courseId: string) => {
    const courseGrades = grades.filter(g => g.course.id === courseId && g.status === 'graded');
    const total = courseGrades.length;
    if (total === 0) return { average: 0, trend: 0 };
    
    const sum = courseGrades.reduce((s, g) => s + (g.score || 0), 0);
    const average = sum / total;
    
    // Mock trend calculation (in a real app, this would compare with previous term)
    const trend = Math.random() * 20 - 10; // Random number between -10 and 10
    
    return { average, trend };
  };

  // Get assignment type icon
  const getAssignmentTypeIcon = (type: string) => {
    switch (type) {
      case 'assignment':
        return <AssignmentIcon fontSize="small" color="primary" />;
      case 'quiz':
        return <AssessmentIcon fontSize="small" color="secondary" />;
      case 'exam':
        return <SchoolIcon fontSize="small" color="error" />;
      case 'project':
        return <StarIcon fontSize="small" style={{ color: theme.palette.warning.main }} />;
      case 'participation':
        return <CheckCircleIcon fontSize="small" color="info" />;
      default:
        return <InfoIcon fontSize="small" color="action" />;
    }
  };

  // Get status chip
  const getStatusChip = (status: string) => {
    switch (status) {
      case 'graded':
        return <Chip label="Graded" color="success" size="small" variant="outlined" />;
      case 'submitted':
        return <Chip label="Submitted" color="info" size="small" variant="outlined" />;
      case 'missing':
        return <Chip label="Missing" color="error" size="small" variant="outlined" />;
      case 'upcoming':
        return <Chip label="Upcoming" color="warning" size="small" variant="outlined" />;
      case 'excused':
        return <Chip label="Excused" color="default" size="small" variant="outlined" />;
      case 'incomplete':
        return <Chip label="Incomplete" color="default" size="small" variant="outlined" />;
      default:
        return <Chip label={status} size="small" variant="outlined" />;
    }
  };

  // Format date
  const formatDate = (dateString: string) => {
    if (!dateString) return '';
    const date = new Date(dateString);
    return date.toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    });
  };

  return (
    <Container maxWidth="xl" sx={{ mt: 4, mb: 6 }}>
      <Box display="flex" justifyContent="space-between" alignItems="center" flexWrap="wrap" gap={2} mb={3}>
        <Typography variant="h4" component="h1">
          My Grades
        </Typography>
        <Box display="flex" gap={1}>
          <Button
            variant="outlined"
            startIcon={<DownloadIcon />}
            size="small"
          >
            Export
          </Button>
          <Button
            variant="outlined"
            startIcon={<PrintIcon />}
            size="small"
          >
            Print
          </Button>
        </Box>
      </Box>

      {/* Stats Cards */}
      <Box display="grid" gridTemplateColumns={{ xs: '1fr', sm: 'repeat(2, 1fr)', md: 'repeat(4, 1fr)' }} gap={2} mb={3}>
        <Paper sx={{ p: 2, display: 'flex', flexDirection: 'column' }}>
          <Box display="flex" justifyContent="space-between" alignItems="center" mb={1}>
            <Typography variant="body2" color="text.secondary">Current GPA</Typography>
            <SchoolIcon color="primary" />
          </Box>
          <Box display="flex" alignItems="baseline">
            <Typography variant="h4" component="div" sx={{ fontWeight: 'bold', mr: 1 }}>
              {currentGPA.toFixed(2)}
            </Typography>
            <GradeTrend current={currentGPA} previous={previousGPA} />
            <Typography variant="body2" color={currentGPA > previousGPA ? 'success.main' : currentGPA < previousGPA ? 'error.main' : 'text.secondary'} sx={{ ml: 0.5 }}>
              {currentGPA > previousGPA ? '↑' : currentGPA < previousGPA ? '↓' : '→'} {Math.abs(currentGPA - previousGPA).toFixed(2)}
            </Typography>
          </Box>
          <Typography variant="caption" color="text.secondary">
            {currentGPA > previousGPA ? 'Up' : currentGPA < previousGPA ? 'Down' : 'No change'} from last term
          </Typography>
        </Paper>

        <Paper sx={{ p: 2, display: 'flex', flexDirection: 'column' }}>
          <Box display="flex" justifyContent="space-between" alignItems="center" mb={1}>
            <Typography variant="body2" color="text.secondary">Average Grade</Typography>
            <AssessmentIcon color="secondary" />
          </Box>
          <Typography variant="h4" component="div" sx={{ fontWeight: 'bold' }}>
            {isNaN(averageGrade) ? 'N/A' : `${averageGrade.toFixed(1)}%`}
          </Typography>
          <Typography variant="caption" color="text.secondary">
            Across {gradedAssignments} graded assignments
          </Typography>
        </Paper>

        <Paper sx={{ p: 2, display: 'flex', flexDirection: 'column' }}>
          <Box display="flex" justifyContent="space-between" alignItems="center" mb={1}>
            <Typography variant="body2" color="text.secondary">Assignments</Typography>
            <AssignmentIcon color="warning" />
          </Box>
          <Box display="flex" alignItems="baseline">
            <Typography variant="h4" component="div" sx={{ fontWeight: 'bold', mr: 1 }}>
              {gradedAssignments}
            </Typography>
            <Typography variant="body1" color="text.secondary">
              / {totalAssignments} graded
            </Typography>
          </Box>
          <Typography variant="caption" color="text.secondary">
            {totalAssignments - gradedAssignments} pending grading
          </Typography>
        </Paper>

        <Paper sx={{ p: 2, display: 'flex', flexDirection: 'column' }}>
          <Box display="flex" justifyContent="space-between" alignItems="center" mb={1}>
            <Typography variant="body2" color="text.secondary">Current Courses</Typography>
            <SchoolIcon color="success" />
          </Box>
          <Typography variant="h4" component="div" sx={{ fontWeight: 'bold' }}>
            {courseSummaries.length}
          </Typography>
          <Typography variant="caption" color="text.secondary">
            {courseSummaries.filter(c => c.currentGrade).length} with grades available
          </Typography>
        </Paper>
      </Box>

      {/* Tabs */}
      <Paper sx={{ mb: 3, borderRadius: 1, overflow: 'hidden' }}>
        <Tabs 
          value={activeTab}
          onChange={handleTabChange}
          variant="scrollable"
          scrollButtons="auto"
          allowScrollButtonsMobile
          sx={{
            borderBottom: 1,
            borderColor: 'divider',
            '& .MuiTab-root': {
              minHeight: 56,
            },
          }}
        >
          <Tab label="All Grades" />
          <Tab 
            label={
              <Box display="flex" alignItems="center">
                <span>Graded</span>
                <Chip 
                  label={grades.filter(g => g.status === 'graded').length} 
                  size="small" 
                  color="success" 
                  sx={{ ml: 1, height: 20, fontSize: '0.7rem' }} 
                />
              </Box>
            } 
          />
          <Tab 
            label={
              <Box display="flex" alignItems="center">
                <span>Submitted</span>
                <Chip 
                  label={grades.filter(g => g.status === 'submitted').length} 
                  size="small" 
                  color="info" 
                  sx={{ ml: 1, height: 20, fontSize: '0.7rem' }} 
                />
              </Box>
            } 
          />
          <Tab 
            label={
              <Box display="flex" alignItems="center">
                <span>Missing</span>
                <Chip 
                  label={grades.filter(g => g.status === 'missing').length} 
                  size="small" 
                  color="error" 
                  sx={{ ml: 1, height: 20, fontSize: '0.7rem' }} 
                />
              </Box>
            } 
          />
          <Tab 
            label={
              <Box display="flex" alignItems="center">
                <span>Upcoming</span>
                <Chip 
                  label={grades.filter(g => g.status === 'upcoming').length} 
                  size="small" 
                  color="warning" 
                  sx={{ ml: 1, height: 20, fontSize: '0.7rem' }} 
                />
              </Box>
            } 
          />
        </Tabs>
      </Paper>

      {/* Course Summary Cards */}
      <Box mb={4}>
        <Typography variant="h6" gutterBottom>
          Course Overview
        </Typography>
        <Box display="grid" gridTemplateColumns={{ xs: '1fr', sm: 'repeat(2, 1fr)', lg: 'repeat(3, 1fr)' }} gap={2}>
          {courseSummaries.map((course) => {
            const progress = Math.round((course.assignmentsGraded / course.assignments) * 100);
            const { average, trend } = getCourseStats(course.id);
            
            return (
              <Paper key={course.id} sx={{ p: 2, position: 'relative', overflow: 'hidden' }}>
                <Box display="flex" justifyContent="space-between" alignItems="flex-start" mb={1}>
                  <Box>
                    <Typography variant="subtitle1" component="div" sx={{ fontWeight: 'bold' }}>
                      {course.code}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {course.name}
                    </Typography>
                  </Box>
                  <Box>
                    {course.currentGrade && (
                      <Chip 
                        label={course.currentGrade} 
                        color="primary" 
                        variant="outlined"
                        size="small"
                        sx={{ fontWeight: 'bold' }}
                      />
                    )}
                  </Box>
                </Box>
                
                <Box mb={1}>
                  <Box display="flex" justifyContent="space-between" mb={0.5}>
                    <Typography variant="body2" color="text.secondary">
                      Progress
                    </Typography>
                    <Typography variant="body2" fontWeight="medium">
                      {course.assignmentsGraded} / {course.assignments} graded
                    </Typography>
                  </Box>
                  <LinearProgress 
                    variant="determinate" 
                    value={progress} 
                    color={progress >= 75 ? 'success' : progress >= 50 ? 'info' : 'warning'}
                    sx={{ height: 8, borderRadius: 4 }}
                  />
                </Box>
                
                <Box display="flex" justifyContent="space-between" alignItems="center" mt={2}>
                  <Box>
                    <Typography variant="caption" color="text.secondary" display="block">
                      Average Grade
                    </Typography>
                    <Box display="flex" alignItems="center">
                      <Typography variant="h6" component="div" sx={{ fontWeight: 'bold' }}>
                        {isNaN(average) ? 'N/A' : `${average.toFixed(1)}%`}
                      </Typography>
                      {!isNaN(average) && trend !== 0 && (
                        <Typography 
                          variant="caption" 
                          color={trend > 0 ? 'success.main' : 'error.main'}
                          sx={{ ml: 0.5, display: 'flex', alignItems: 'center' }}
                        >
                          {trend > 0 ? '↑' : '↓'} {Math.abs(trend).toFixed(1)}%
                        </Typography>
                      )}
                    </Box>
                  </Box>
                  
                  <Button 
                    variant="outlined" 
                    size="small" 
                    onClick={() => handleCourseFilter(course.id)}
                    sx={{ textTransform: 'none' }}
                  >
                    View Details
                  </Button>
                </Box>
                
                <Box 
                  sx={{
                    position: 'absolute',
                    top: 0,
                    right: 0,
                    width: 4,
                    height: '100%',
                    bgcolor: 'primary.main',
                  }}
                />
              </Paper>
            );
          })}
        </Box>
      </Box>

      {/* Filters */}
      <Box display="flex" flexWrap="wrap" gap={2} mb={3}>
        <TextField
          placeholder="Search assignments..."
          variant="outlined"
          size="small"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon color="action" />
              </InputAdornment>
            ),
          }}
          sx={{ minWidth: 250 }}
        />
        
        <TextField
          select
          label="Course"
          variant="outlined"
          size="small"
          value={selectedCourse || 'all'}
          onChange={(e) => handleCourseFilter(e.target.value === 'all' ? null : e.target.value)}
          sx={{ minWidth: 200 }}
        >
          <MenuItem value="all">All Courses</MenuItem>
          {courseSummaries.map((course) => (
            <MenuItem key={course.id} value={course.id}>
              {course.code} - {course.name}
            </MenuItem>
          ))}
        </TextField>
        
        <TextField
          select
          label="Type"
          variant="outlined"
          size="small"
          value={selectedType}
          onChange={(e) => handleTypeFilter(e.target.value)}
          sx={{ minWidth: 150 }}
        >
          <MenuItem value="all">All Types</MenuItem>
          <MenuItem value="assignment">Assignments</MenuItem>
          <MenuItem value="quiz">Quizzes</MenuItem>
          <MenuItem value="exam">Exams</MenuItem>
          <MenuItem value="project">Projects</MenuItem>
          <MenuItem value="participation">Participation</MenuItem>
        </TextField>
        
        <Box flexGrow={1} />
        
        <Button
          variant="outlined"
          startIcon={<FilterListIcon />}
          size="small"
          onClick={() => {
            // Reset all filters
            setSearchTerm('');
            setSelectedCourse(null);
            setSelectedType('all');
            setActiveTab(0);
          }}
        >
          Clear Filters
        </Button>
      </Box>

      {/* Grades Table */}
      <Paper sx={{ width: '100%', overflow: 'hidden', mb: 3 }}>
        <TableContainer sx={{ maxHeight: 600 }}>
          <Table stickyHeader size="small">
            <TableHead>
              <TableRow>
                <TableCell>
                  <TableSortLabel
                    active={orderBy === 'title'}
                    direction={orderBy === 'title' ? order : 'asc'}
                    onClick={() => handleRequestSort('title')}
                  >
                    Assignment
                  </TableSortLabel>
                </TableCell>
                <TableCell>
                  <TableSortLabel
                    active={orderBy === 'course'}
                    direction={orderBy === 'course' ? order : 'asc'}
                    onClick={() => handleRequestSort('course')}
                  >
                    Course
                  </TableSortLabel>
                </TableCell>
                <TableCell>Type</TableCell>
                <TableCell align="right">
                  <TableSortLabel
                    active={orderBy === 'dueDate'}
                    direction={orderBy === 'dueDate' ? order : 'desc'}
                    onClick={() => handleRequestSort('dueDate')}
                  >
                    Due Date
                  </TableSortLabel>
                </TableCell>
                <TableCell align="right">
                  <TableSortLabel
                    active={orderBy === 'score'}
                    direction={orderBy === 'score' ? order : 'desc'}
                    onClick={() => handleRequestSort('score')}
                  >
                    Score
                  </TableSortLabel>
                </TableCell>
                <TableCell align="center">Status</TableCell>
                <TableCell align="right">Actions</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {paginatedGrades.length > 0 ? (
                paginatedGrades.map((grade) => (
                  <StyledTableRow hover key={grade.id}>
                    <TableCell>
                      <Box display="flex" alignItems="center">
                        <Box sx={{ mr: 1 }}>
                          {getAssignmentTypeIcon(grade.assignment.type)}
                        </Box>
                        <Box>
                          <Typography variant="body2" fontWeight="medium">
                            {grade.assignment.title}
                          </Typography>
                          <Typography variant="caption" color="text.secondary">
                            {grade.course.code} • {grade.assignment.weight}%
                          </Typography>
                        </Box>
                      </Box>
                    </TableCell>
                    <TableCell>
                      <Typography variant="body2">{grade.course.name}</Typography>
                      <Typography variant="caption" color="text.secondary">
                        {grade.course.instructor}
                      </Typography>
                    </TableCell>
                    <TableCell>
                      <Chip 
                        label={grade.assignment.type.charAt(0).toUpperCase() + grade.assignment.type.slice(1)}
                        size="small"
                        variant="outlined"
                      />
                    </TableCell>
                    <TableCell align="right">
                      <Typography variant="body2">
                        {formatDate(grade.assignment.dueDate)}
                      </Typography>
                      <Typography 
                        variant="caption" 
                        color={new Date(grade.assignment.dueDate) < new Date() && grade.status !== 'graded' && grade.status !== 'submitted' 
                          ? 'error.main' 
                          : 'text.secondary'
                        }
                      >
                        {grade.status === 'graded' && grade.gradedDate 
                          ? `Graded on ${formatDate(grade.gradedDate)}`
                          : grade.status === 'submitted' && grade.submissionDate
                          ? `Submitted on ${formatDate(grade.submissionDate)}`
                          : new Date(grade.assignment.dueDate) < new Date()
                          ? 'Overdue'
                          : `Due in ${Math.ceil((new Date(grade.assignment.dueDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24))} days`
                        }
                      </Typography>
                    </TableCell>
                    <TableCell align="right">
                      {grade.status === 'graded' && grade.score !== null ? (
                        <Box display="flex" flexDirection="column" alignItems="flex-end">
                          <GradeChip 
                            label={`${grade.score} / ${grade.assignment.maxPoints}`}
                            score={grade.score}
                            maxScore={grade.assignment.maxPoints}
                            size="small"
                          />
                          <Typography variant="caption" color="text.secondary">
                            {grade.letterGrade} • {grade.percentile}%
                          </Typography>
                        </Box>
                      ) : (
                        <Typography variant="body2" color="text.secondary">
                          {grade.status === 'submitted' ? 'Grading in progress' : '—'}
                        </Typography>
                      )}
                    </TableCell>
                    <TableCell align="center">
                      {getStatusChip(grade.status)}
                    </TableCell>
                    <TableCell align="right">
                      <IconButton 
                        size="small" 
                        onClick={(e) => {
                          e.stopPropagation();
                          handleMenuClick(e, grade);
                        }}
                      >
                        <MoreVertIcon fontSize="small" />
                      </IconButton>
                    </TableCell>
                  </StyledTableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={7} align="center" sx={{ py: 4 }}>
                    <Box 
                      display="flex" 
                      flexDirection="column" 
                      alignItems="center" 
                      justifyContent="center"
                    >
                      <AssessmentIcon fontSize="large" color="disabled" sx={{ mb: 1, opacity: 0.5 }} />
                      <Typography variant="subtitle1" color="text.secondary">
                        No grades found
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        {searchTerm || selectedCourse || selectedType !== 'all' || activeTab !== 0
                          ? 'Try adjusting your search or filters.'
                          : 'Your grades will appear here once available.'}
                      </Typography>
                      {(searchTerm || selectedCourse || selectedType !== 'all' || activeTab !== 0) && (
                        <Button 
                          variant="outlined" 
                          size="small" 
                          sx={{ mt: 2 }}
                          onClick={() => {
                            setSearchTerm('');
                            setSelectedCourse(null);
                            setSelectedType('all');
                            setActiveTab(0);
                          }}
                        >
                          Clear Filters
                        </Button>
                      )}
                    </Box>
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </TableContainer>
        
        <TablePagination
          rowsPerPageOptions={[5, 10, 25, 50]}
          component="div"
          count={filteredGrades.length}
          rowsPerPage={rowsPerPage}
          page={page}
          onPageChange={handleChangePage}
          onRowsPerPageChange={handleChangeRowsPerPage}
          sx={{
            borderTop: 1,
            borderColor: 'divider',
            '& .MuiTablePagination-selectLabel, & .MuiTablePagination-displayedRows': {
              mt: 1.5,
              mb: 0.5,
            },
          }}
        />
      </Paper>

      {/* Grade Distribution Chart (Placeholder) */}
      <Paper sx={{ p: 3, mb: 3 }}>
        <Typography variant="h6" gutterBottom>
          Grade Distribution
        </Typography>
        <Box 
          sx={{ 
            height: 200, 
            display: 'flex', 
            alignItems: 'flex-end',
            justifyContent: 'center',
            gap: 2,
            mt: 4,
            '& > div': {
              width: 40,
              borderRadius: 1,
              position: 'relative',
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              '&:hover': {
                opacity: 0.8,
              },
            },
            '& .MuiTypography-caption': {
              position: 'absolute',
              bottom: -24,
              textAlign: 'center',
              width: '100%',
            },
          }}
        >
          {['A+', 'A', 'A-', 'B+', 'B', 'B-', 'C+', 'C', 'D', 'F'].map((grade, index) => (
            <Box 
              key={grade} 
              sx={{
                height: `${Math.max(10, 100 - index * 8)}%`,
                bgcolor: index <= 2 ? 'success.light' : index <= 5 ? 'info.light' : index <= 8 ? 'warning.light' : 'error.light',
              }}
            >
              <Typography variant="body2" sx={{ mt: -2.5, color: 'white', fontWeight: 'bold' }}>
                {Math.floor(Math.random() * 10) + 1}
              </Typography>
              <Typography variant="caption" color="text.secondary">
                {grade}
              </Typography>
            </Box>
          ))}
        </Box>
      </Paper>

      {/* Action Menu */}
      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleMenuClose}
        onClick={(e) => e.stopPropagation()}
      >
        <MenuItem onClick={() => {
          console.log('View details:', selectedGrade?.id);
          handleMenuClose();
        }}>
          <ListItemIcon>
            <InfoIcon fontSize="small" />
          </ListItemIcon>
          <ListItemText>View Details</ListItemText>
        </MenuItem>
        
        <MenuItem onClick={() => {
          console.log('Download:', selectedGrade?.id);
          handleMenuClose();
        }}>
          <ListItemIcon>
            <DownloadIcon fontSize="small" />
          </ListItemIcon>
          <ListItemText>Download</ListItemText>
        </MenuItem>
        
        {selectedGrade?.status === 'missing' && (
          <MenuItem 
            onClick={() => {
              console.log('Submit assignment:', selectedGrade.id);
              handleMenuClose();
            }}
            sx={{ color: 'primary.main' }}
          >
            <ListItemIcon>
              <AssignmentTurnedInIcon color="primary" fontSize="small" />
            </ListItemIcon>
            <ListItemText primary="Submit Assignment" />
          </MenuItem>
        )}
        
        <Divider />
        
        <MenuItem onClick={handleMenuClose}>
          <ListItemIcon>
            <ShareIcon fontSize="small" />
          </ListItemIcon>
          <ListItemText>Share</ListItemText>
        </MenuItem>
        
        <MenuItem onClick={handleMenuClose}>
          <ListItemIcon>
            <PrintIcon fontSize="small" />
          </ListItemIcon>
          <ListItemText>Print</ListItemText>
        </MenuItem>
      </Menu>
    </Container>
  );
};

export default GradesPage;
