import React, { useState } from 'react';
import { useNavigate, Link as RouterLink } from 'react-router-dom';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import {
  Box,
  Button,
  TextField,
  Typography,
  Link,
  CircularProgress,
  Alert,
  useTheme,
  Container,
  Paper,
} from '@mui/material';
import ArrowBackIcon from '@mui/icons-material/ArrowBack';
import MailOutlineIcon from '@mui/icons-material/MailOutline';

const ForgotPasswordPage: React.FC = () => {
  const theme = useTheme();
  const navigate = useNavigate();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState('');
  const [isSubmitted, setIsSubmitted] = useState(false);

  const validationSchema = Yup.object({
    email: Yup.string()
      .email('Enter a valid email')
      .required('Email is required'),
  });

  const formik = useFormik({
    initialValues: {
      email: '',
    },
    validationSchema,
    onSubmit: async (values) => {
      try {
        setError('');
        setIsLoading(true);
        
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // In a real app, you would call your API to send a password reset email
        console.log('Password reset requested for:', values.email);
        
        // Show success message
        setIsSubmitted(true);
      } catch (err: any) {
        setError(err.message || 'Failed to send reset email. Please try again.');
      } finally {
        setIsLoading(false);
      }
    },
  });

  const handleBackToLogin = () => {
    navigate('/login');
  };

  return (
    <Container component="main" maxWidth="sm" sx={{ py: 8 }}>
      <Paper
        elevation={2}
        sx={{
          p: { xs: 3, sm: 4 },
          borderRadius: 2,
          display: 'flex',
          flexDirection: 'column',
          alignItems: 'center',
        }}
      >
        <Box
          sx={{
            display: 'flex',
            alignItems: 'center',
            mb: 4,
            alignSelf: 'flex-start',
          }}
        >
          <IconButton
            onClick={handleBackToLogin}
            sx={{ mr: 1, color: 'primary.main' }}
          >
            <ArrowBackIcon />
          </IconButton>
          <Typography variant="h6" component="h1" fontWeight="bold">
            Forgot Password
          </Typography>
        </Box>

        {isSubmitted ? (
          <Box
            sx={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'center',
              textAlign: 'center',
              py: 4,
            }}
          >
            <Box
              sx={{
                width: 64,
                height: 64,
                borderRadius: '50%',
                backgroundColor: 'success.light',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                mb: 3,
              }}
            >
              <MailOutlineIcon sx={{ fontSize: 32, color: 'success.contrastText' }} />
            </Box>
            <Typography variant="h5" component="h2" gutterBottom fontWeight="bold">
              Check Your Email
            </Typography>
            <Typography variant="body1" color="text.secondary" mb={4}>
              We've sent a password reset link to <strong>{formik.values.email}</strong>.
              Please check your email and follow the instructions to reset your password.
            </Typography>
            <Typography variant="body2" color="text.secondary" mb={4}>
              Didn't receive the email?{' '}
              <Link
                component="button"
                type="button"
                onClick={() => {
                  setIsSubmitted(false);
                  formik.resetForm();
                }}
                sx={{ fontWeight: 500 }}
              >
                Resend email
              </Link>
            </Typography>
            <Button
              variant="contained"
              fullWidth
              onClick={handleBackToLogin}
              sx={{ mt: 2, py: 1.5, borderRadius: 2, textTransform: 'none' }}
            >
              Back to Login
            </Button>
          </Box>
        ) : (
          <>
            <Typography
              variant="body1"
              color="text.secondary"
              textAlign="center"
              mb={4}
              sx={{ maxWidth: 400 }}
            >
              Enter the email address associated with your account and we'll send you a link to
              reset your password.
            </Typography>

            {error && (
              <Alert severity="error" sx={{ width: '100%', mb: 3 }}>
                {error}
              </Alert>
            )}

            <Box
              component="form"
              onSubmit={formik.handleSubmit}
              sx={{ width: '100%', maxWidth: 400 }}
            >
              <TextField
                fullWidth
                id="email"
                name="email"
                label="Email Address"
                value={formik.values.email}
                onChange={formik.handleChange}
                onBlur={formik.handleBlur}
                error={formik.touched.email && Boolean(formik.errors.email)}
                helperText={formik.touched.email && formik.errors.email}
                margin="normal"
                autoComplete="email"
                autoFocus
                InputProps={{
                  startAdornment: (
                    <MailOutlineIcon
                      sx={{ color: 'action.active', mr: 1, fontSize: 20 }}
                    />
                  ),
                }}
              />

              <Button
                type="submit"
                fullWidth
                variant="contained"
                disabled={isLoading}
                sx={{
                  mt: 3,
                  mb: 2,
                  py: 1.5,
                  borderRadius: 2,
                  textTransform: 'none',
                  fontSize: '1rem',
                  fontWeight: 600,
                }}
              >
                {isLoading ? (
                  <CircularProgress size={24} color="inherit" />
                ) : (
                  'Send Reset Link'
                )}
              </Button>

              <Box sx={{ textAlign: 'center', mt: 3 }}>
                <Typography variant="body2" color="text.secondary">
                  Remember your password?{' '}
                  <Link
                    component={RouterLink}
                    to="/login"
                    underline="hover"
                    fontWeight={600}
                  >
                    Back to Login
                  </Link>
                </Typography>
              </Box>
            </Box>
          </>
        )}
      </Paper>
    </Container>
  );
};

export default ForgotPasswordPage;
