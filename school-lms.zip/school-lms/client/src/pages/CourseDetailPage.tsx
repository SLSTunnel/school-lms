import React, { useState } from 'react';
import { useParams } from 'react-router-dom';
import {
  Container,
  Grid,
  Box,
  Typography,
  Button,
  Tabs,
  Tab,
  Paper,
  Divider,
  Chip,
  IconButton,
  LinearProgress,
  List,
  ListItem,
  ListItemIcon,
  ListItemText,
  Avatar,
  Card,
  CardContent,
  CardMedia,
  TextField,
  InputAdornment,
  Menu,
  MenuItem as MuiMenuItem,
} from '@mui/material';
import { styled } from '@mui/material/styles';
import {
  Book as BookIcon,
  Person as PersonIcon,
  AccessTime as TimeIcon,
  Star as StarIcon,
  PlayCircle as PlayIcon,
  CheckCircle as CheckCircleIcon,
  Description as DescriptionIcon,
  Quiz as QuizIcon,
  Chat as ChatIcon,
  MoreVert as MoreVertIcon,
  Search as SearchIcon,
  FilterList as FilterListIcon,
  ArrowBack as ArrowBackIcon,
  Bookmark as BookmarkIcon,
  Share as ShareIcon,
  Download as DownloadIcon,
  Info as InfoIcon,
} from '@mui/icons-material';

// Styled Components
const StyledCard = styled(Card)(({ theme }) => ({
  height: '100%',
  display: 'flex',
  flexDirection: 'column',
  transition: 'transform 0.3s ease-in-out, box-shadow 0.3s ease-in-out',
  '&:hover': {
    transform: 'translateY(-5px)',
    boxShadow: theme.shadows[8],
  },
}));

const ModuleCard = styled(Paper)(({ theme }) => ({
  marginBottom: theme.spacing(2),
  overflow: 'hidden',
  '&:last-child': {
    marginBottom: 0,
  },
}));

const ModuleHeader = styled(Box)(({ theme }) => ({
  padding: theme.spacing(2),
  backgroundColor: theme.palette.grey[100],
  display: 'flex',
  alignItems: 'center',
  cursor: 'pointer',
  '&:hover': {
    backgroundColor: theme.palette.grey[200],
  },
}));

const LessonItem = styled(ListItem)(({ theme }) => ({
  paddingLeft: theme.spacing(4),
  borderBottom: `1px solid ${theme.palette.divider}`,
  '&:last-child': {
    borderBottom: 'none',
  },
  '&:hover': {
    backgroundColor: theme.palette.action.hover,
  },
}));

// Mock data for the course
const courseData = {
  id: 'math-101',
  title: 'Calculus I: Differential Calculus',
  code: 'MATH-101',
  instructor: {
    name: 'Dr. Sarah Johnson',
    title: 'Professor of Mathematics',
    avatar: 'SJ',
    rating: 4.8,
    reviews: 247,
  },
  description: 'This course provides an introduction to differential calculus, covering fundamental concepts such as limits, derivatives, and their applications. Students will develop a deep understanding of the principles of calculus and how they can be applied to solve real-world problems in science, engineering, and beyond.',
  startDate: 'September 5, 2023',
  duration: '12 weeks',
  enrolledStudents: 124,
  rating: 4.7,
  progress: 65,
  modules: [
    {
      id: 'module-1',
      title: 'Introduction to Calculus',
      duration: '1h 45min',
      lessons: [
        { id: 'lesson-1', title: 'What is Calculus?', duration: '12:45', type: 'video', completed: true },
        { id: 'lesson-2', title: 'The Concept of Limits', duration: '18:30', type: 'video', completed: true },
        { id: 'lesson-3', title: 'Continuity and Discontinuity', duration: '15:20', type: 'video', completed: false },
        { id: 'quiz-1', title: 'Practice Quiz', duration: '15 min', type: 'quiz', completed: false },
      ],
    },
    {
      id: 'module-2',
      title: 'The Derivative',
      duration: '2h 15min',
      lessons: [
        { id: 'lesson-4', title: 'Understanding the Derivative', duration: '20:15', type: 'video', completed: false },
        { id: 'lesson-5', title: 'Differentiation Rules', duration: '25:30', type: 'video', completed: false },
        { id: 'lesson-6', title: 'Chain Rule', duration: '18:45', type: 'video', completed: false },
      ],
    },
    {
      id: 'module-3',
      title: 'Applications of Derivatives',
      duration: '2h 30min',
      lessons: [
        { id: 'lesson-7', title: 'Related Rates', duration: '22:10', type: 'video', completed: false },
        { id: 'lesson-8', title: 'Optimization Problems', duration: '28:20', type: 'video', completed: false },
        { id: 'lesson-9', title: 'Curve Sketching', duration: '25:15', type: 'video', completed: false },
      ],
    },
  ],
  resources: [
    { id: 'res-1', title: 'Course Syllabus', type: 'pdf', size: '2.4 MB' },
    { id: 'res-2', title: 'Textbook: Calculus Made Easy', type: 'pdf', size: '15.7 MB' },
    { id: 'res-3', title: 'Formula Sheet', type: 'pdf', size: '1.2 MB' },
    { id: 'res-4', title: 'Practice Problems Set 1', type: 'doc', size: '850 KB' },
  ],
  assignments: [
    { id: 'assign-1', title: 'Problem Set 1: Limits', dueDate: 'Sep 12, 2023', status: 'submitted', grade: 'A-' },
    { id: 'assign-2', title: 'Problem Set 2: Derivatives', dueDate: 'Sep 26, 2023', status: 'submitted', grade: 'B+' },
    { id: 'assign-3', title: 'Midterm Exam', dueDate: 'Oct 10, 2023', status: 'upcoming', grade: null },
  ],
};

const CourseDetailPage: React.FC = () => {
  const { courseId } = useParams<{ courseId: string }>();
  const [activeTab, setActiveTab] = useState(0);
  const [expandedModule, setExpandedModule] = useState<string | null>('module-1');
  const [searchTerm, setSearchTerm] = useState('');
  const [anchorEl, setAnchorEl] = useState<null | HTMLElement>(null);

  const handleTabChange = (event: React.SyntheticEvent, newValue: number) => {
    setActiveTab(newValue);
  };

  const toggleModule = (moduleId: string) => {
    setExpandedModule(expandedModule === moduleId ? null : moduleId);
  };

  const handleMenuClick = (event: React.MouseEvent<HTMLElement>) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  const handleDownloadResource = (resourceId: string) => {
    console.log(`Downloading resource ${resourceId}`);
    // Implement download functionality
  };

  const handleStartLesson = (lessonId: string) => {
    console.log(`Starting lesson ${lessonId}`);
    // Implement lesson start functionality
  };

  return (
    <Container maxWidth="xl" sx={{ mt: 4, mb: 6 }}>
      {/* Course Header */}
      <Box display="flex" flexDirection={{ xs: 'column', md: 'row' }} gap={3} mb={4}>
        <Box flex={1}>
          <Button startIcon={<ArrowBackIcon />} sx={{ mb: 2 }}>
            Back to Courses
          </Button>
          <Box display="flex" alignItems="center" mb={1}>
            <Chip 
              label={courseData.code} 
              size="small" 
              color="primary" 
              variant="outlined"
              sx={{ mr: 1 }}
            />
            <Typography variant="body2" color="text.secondary">
              {courseData.duration} • {courseData.enrolledStudents} students enrolled
            </Typography>
          </Box>
          <Typography variant="h3" component="h1" gutterBottom>
            {courseData.title}
          </Typography>
          <Typography variant="body1" color="text.secondary" paragraph>
            {courseData.description}
          </Typography>
          
          <Box display="flex" flexWrap="wrap" gap={2} mt={3}>
            <Button 
              variant="contained" 
              color="primary" 
              startIcon={<PlayIcon />}
              size="large"
            >
              Continue Learning
            </Button>
            <Button 
              variant="outlined" 
              startIcon={<BookmarkIcon />}
              size="large"
            >
              Save for Later
            </Button>
            <IconButton size="large">
              <ShareIcon />
            </IconButton>
            <IconButton size="large" onClick={handleMenuClick}>
              <MoreVertIcon />
            </IconButton>
            <Menu
              anchorEl={anchorEl}
              open={Boolean(anchorEl)}
              onClose={handleMenuClose}
            >
              <MuiMenuItem onClick={handleMenuClose}>
                <DownloadIcon sx={{ mr: 1 }} /> Download All Resources
              </MuiMenuItem>
              <MuiMenuItem onClick={handleMenuClose}>
                <InfoIcon sx={{ mr: 1 }} /> Course Info
              </MuiMenuItem>
            </Menu>
          </Box>
        </Box>
        
        <Box width={{ xs: '100%', md: 350 }}>
          <Card>
            <CardMedia
              component="div"
              sx={{
                height: 140,
                backgroundColor: 'primary.main',
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                color: 'white',
              }}
            >
              <BookIcon sx={{ fontSize: 60, opacity: 0.7 }} />
            </CardMedia>
            <CardContent>
              <Box display="flex" alignItems="center" mb={2}>
                <Box sx={{ flexGrow: 1 }}>
                  <Typography variant="subtitle1" gutterBottom>
                    Course Progress
                  </Typography>
                  <Box display="flex" alignItems="center">
                    <Box width="100%" mr={1}>
                      <LinearProgress 
                        variant="determinate" 
                        value={courseData.progress} 
                        sx={{ height: 8, borderRadius: 4 }}
                      />
                    </Box>
                    <Typography variant="body2" color="text.secondary">
                      {courseData.progress}%
                    </Typography>
                  </Box>
                </Box>
              </Box>
              
              <Divider sx={{ my: 2 }} />
              
              <Box mb={2}>
                <Typography variant="subtitle2" gutterBottom>
                  Instructor
                </Typography>
                <Box display="flex" alignItems="center">
                  <Avatar sx={{ bgcolor: 'primary.main', mr: 1 }}>
                    {courseData.instructor.avatar}
                  </Avatar>
                  <Box>
                    <Typography variant="body2" fontWeight="medium">
                      {courseData.instructor.name}
                    </Typography>
                    <Typography variant="caption" color="text.secondary">
                      {courseData.instructor.title}
                    </Typography>
                  </Box>
                </Box>
              </Box>
              
              <Box display="flex" alignItems="center" mb={2}>
                <StarIcon color="warning" fontSize="small" />
                <Typography variant="body2" ml={0.5}>
                  {courseData.rating} ({courseData.instructor.reviews} reviews)
                </Typography>
              </Box>
              
              <Button 
                variant="outlined" 
                fullWidth 
                startIcon={<ChatIcon />}
                sx={{ mt: 1 }}
              >
                Message Instructor
              </Button>
            </CardContent>
          </Card>
        </Box>
      </Box>
      
      {/* Course Tabs */}
      <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 3 }}>
        <Tabs 
          value={activeTab} 
          onChange={handleTabChange}
          variant="scrollable"
          scrollButtons="auto"
          allowScrollButtonsMobile
        >
          <Tab label="Overview" />
          <Tab label="Course Content" />
          <Tab label="Resources" />
          <Tab label="Assignments" />
          <Tab label="Discussion" />
          <Tab label="Announcements" />
        </Tabs>
      </Box>
      
      {/* Tab Content */}
      <Box>
        {/* Overview Tab */}
        {activeTab === 0 && (
          <Grid container spacing={3}>
            <Grid item xs={12} md={8}>
              <Card sx={{ mb: 3 }}>
                <CardContent>
                  <Typography variant="h6" gutterBottom>
                    What You'll Learn
                  </Typography>
                  <Grid container spacing={2}>
                    {[
                      'Understand the concept of limits and continuity',
                      'Master the rules of differentiation',
                      'Apply derivatives to solve optimization problems',
                      'Understand the relationship between position, velocity, and acceleration',
                      'Use calculus to analyze and graph functions',
                      'Solve related rates problems',
                    ].map((item, index) => (
                      <Grid item xs={12} sm={6} key={index}>
                        <Box display="flex" alignItems="flex-start">
                          <CheckCircleIcon color="primary" fontSize="small" sx={{ mt: 0.5, mr: 1 }} />
                          <Typography variant="body2">{item}</Typography>
                        </Box>
                      </Grid>
                    ))}
                  </Grid>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent>
                  <Typography variant="h6" gutterBottom>
                    Course Description
                  </Typography>
                  <Typography variant="body1" paragraph>
                    {courseData.description}
                  </Typography>
                  <Typography variant="body1" paragraph>
                    This course is designed for students who have completed a standard high school mathematics curriculum, 
                    including algebra and trigonometry. Through a combination of lectures, problem-solving sessions, and 
                    practical examples, you'll gain the skills needed to analyze functions, understand rates of change, 
                    and solve optimization problems.
                  </Typography>
                  <Typography variant="h6" gutterBottom>
                    Prerequisites
                  </Typography>
                  <ul>
                    <li>Algebra I & II</li>
                    <li>Trigonometry</li>
                    <li>Basic understanding of functions and their graphs</li>
                  </ul>
                </CardContent>
              </Card>
            </Grid>
            
            <Grid item xs={12} md={4}>
              <Card sx={{ mb: 3 }}>
                <CardContent>
                  <Typography variant="h6" gutterBottom>
                    Course Details
                  </Typography>
                  <List disablePadding>
                    <ListItem disableGutters>
                      <ListItemIcon sx={{ minWidth: 36 }}>
                        <TimeIcon color="action" fontSize="small" />
                      </ListItemIcon>
                      <ListItemText 
                        primary="Start Date" 
                        secondary={courseData.startDate} 
                      />
                    </ListItem>
                    <ListItem disableGutters>
                      <ListItemIcon sx={{ minWidth: 36 }}>
                        <TimeIcon color="action" fontSize="small" />
                      </ListItemIcon>
                      <ListItemText 
                        primary="Duration" 
                        secondary={courseData.duration} 
                      />
                    </ListItem>
                    <ListItem disableGutters>
                      <ListItemIcon sx={{ minWidth: 36 }}>
                        <PersonIcon color="action" fontSize="small" />
                      </ListItemIcon>
                      <ListItemText 
                        primary="Instructor" 
                        secondary={courseData.instructor.name} 
                      />
                    </ListItem>
                    <ListItem disableGutters>
                      <ListItemIcon sx={{ minWidth: 36 }}>
                        <StarIcon color="action" fontSize="small" />
                      </ListItemIcon>
                      <ListItemText 
                        primary="Rating" 
                        secondary={`${courseData.rating} (${courseData.instructor.reviews} reviews)`} 
                      />
                    </ListItem>
                  </List>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent>
                  <Typography variant="h6" gutterBottom>
                    Course Progress
                  </Typography>
                  <Box textAlign="center" mb={2}>
                    <Box
                      sx={{
                        width: 120,
                        height: 120,
                        mx: 'auto',
                        position: 'relative',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        mb: 2,
                      }}
                    >
                      <Box
                        sx={{
                          position: 'absolute',
                          top: 0,
                          left: 0,
                          right: 0,
                          bottom: 0,
                          borderRadius: '50%',
                          border: '8px solid',
                          borderColor: 'primary.light',
                        }}
                      />
                      <Box
                        sx={{
                          position: 'absolute',
                          top: 0,
                          left: 0,
                          right: 0,
                          bottom: 0,
                          borderRadius: '50%',
                          border: '8px solid',
                          borderColor: 'primary.main',
                          clipPath: `circle(50% at 50% 50%)`,
                          transform: 'rotate(90deg)',
                          '&::before': {
                            content: '""',
                            position: 'absolute',
                            top: 0,
                            left: 0,
                            right: 0,
                            bottom: 0,
                            borderRadius: '50%',
                            border: '8px solid',
                            borderColor: 'primary.main',
                            clipPath: `polygon(0 0, 50% 0, 50% 100%, 0 100%)`,
                            transform: `rotate(${courseData.progress * 3.6}deg)`,
                            transformOrigin: 'center',
                          },
                        }}
                      />
                      <Typography variant="h4">
                        {courseData.progress}%
                      </Typography>
                    </Box>
                    <Typography variant="body2" color="text.secondary">
                      {courseData.progress}% Complete
                    </Typography>
                  </Box>
                  
                  <Box>
                    <Box display="flex" justifyContent="space-between" mb={1}>
                      <Typography variant="body2">
                        <strong>Modules:</strong> 3/8
                      </Typography>
                      <Typography variant="body2">
                        <strong>Lessons:</strong> 5/24
                      </Typography>
                    </Box>
                    <Box display="flex" justifyContent="space-between">
                      <Typography variant="body2">
                        <strong>Quizzes:</strong> 1/5
                      </Typography>
                      <Typography variant="body2">
                        <strong>Assignments:</strong> 2/6
                      </Typography>
                    </Box>
                  </Box>
                </CardContent>
              </Card>
            </Grid>
          </Grid>
        )}
        
        {/* Course Content Tab */}
        {activeTab === 1 && (
          <Box>
            <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
              <Typography variant="h6">
                Course Content
              </Typography>
              <Box display="flex" gap={1}>
                <TextField
                  placeholder="Search lessons..."
                  variant="outlined"
                  size="small"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <SearchIcon color="action" />
                      </InputAdornment>
                    ),
                  }}
                  sx={{ minWidth: 250 }}
                />
                <Button
                  variant="outlined"
                  startIcon={<FilterListIcon />}
                  size="small"
                >
                  Filter
                </Button>
              </Box>
            </Box>
            
            {courseData.modules.map((module) => (
              <ModuleCard key={module.id} elevation={2}>
                <ModuleHeader onClick={() => toggleModule(module.id)}>
                  <Box flex={1} display="flex" alignItems="center">
                    <Box
                      sx={{
                        width: 40,
                        height: 40,
                        borderRadius: '50%',
                        bgcolor: 'primary.light',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        mr: 2,
                        flexShrink: 0,
                      }}
                    >
                      <BookIcon color="primary" fontSize="small" />
                    </Box>
                    <Box>
                      <Typography variant="subtitle1">{module.title}</Typography>
                      <Typography variant="body2" color="text.secondary">
                        {module.lessons.length} lessons • {module.duration}
                      </Typography>
                    </Box>
                  </Box>
                  <Box
                    sx={{
                      transform: expandedModule === module.id ? 'rotate(90deg)' : 'rotate(0deg)',
                      transition: 'transform 0.3s',
                    }}
                  >
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                      <path d="M9 18L15 12L9 6" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                    </svg>
                  </Box>
                </ModuleHeader>
                
                {expandedModule === module.id && (
                  <List disablePadding>
                    {module.lessons.map((lesson, index) => (
                      <LessonItem 
                        key={lesson.id}
                        button
                        onClick={() => handleStartLesson(lesson.id)}
                      >
                        <ListItemIcon sx={{ minWidth: 40 }}>
                          {lesson.type === 'quiz' ? (
                            <QuizIcon color="secondary" />
                          ) : (
                            <PlayIcon color={lesson.completed ? 'success' : 'action'} />
                          )}
                        </ListItemIcon>
                        <ListItemText 
                          primary={lesson.title}
                          secondary={lesson.duration}
                          primaryTypographyProps={{
                            color: lesson.completed ? 'text.secondary' : 'text.primary',
                            sx: {
                              textDecoration: lesson.completed ? 'line-through' : 'none',
                            },
                          }}
                        />
                        {lesson.completed && (
                          <CheckCircleIcon color="success" fontSize="small" />
                        )}
                      </LessonItem>
                    ))}
                  </List>
                )}
              </ModuleCard>
            ))}
          </Box>
        )}
        
        {/* Resources Tab */}
        {activeTab === 2 && (
          <Box>
            <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
              <Typography variant="h6">
                Course Resources
              </Typography>
              <Box display="flex" gap={1}>
                <TextField
                  placeholder="Search resources..."
                  variant="outlined"
                  size="small"
                  InputProps={{
                    startAdornment: (
                      <InputAdornment position="start">
                        <SearchIcon color="action" />
                      </InputAdornment>
                    ),
                  }}
                  sx={{ minWidth: 250 }}
                />
                <Button
                  variant="outlined"
                  startIcon={<FilterListIcon />}
                  size="small"
                >
                  Filter
                </Button>
              </Box>
            </Box>
            
            <Grid container spacing={2}>
              {courseData.resources.map((resource) => (
                <Grid item xs={12} sm={6} md={4} key={resource.id}>
                  <Card>
                    <CardContent>
                      <Box display="flex" justifyContent="space-between" alignItems="flex-start">
                        <Box>
                          <Typography variant="subtitle1" gutterBottom>
                            {resource.title}
                          </Typography>
                          <Typography variant="body2" color="text.secondary">
                            {resource.type.toUpperCase()} • {resource.size}
                          </Typography>
                        </Box>
                        <IconButton 
                          size="small" 
                          onClick={() => handleDownloadResource(resource.id)}
                        >
                          <DownloadIcon fontSize="small" />
                        </IconButton>
                      </Box>
                    </CardContent>
                  </Card>
                </Grid>
              ))}
            </Grid>
          </Box>
        )}
        
        {/* Assignments Tab */}
        {activeTab === 3 && (
          <Box>
            <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
              <Typography variant="h6">
                Assignments
              </Typography>
              <Button variant="contained" color="primary">
                Submit Assignment
              </Button>
            </Box>
            
            <List disablePadding>
              {courseData.assignments.map((assignment, index) => (
                <React.Fragment key={assignment.id}>
                  <ListItem 
                    button 
                    sx={{
                      py: 2,
                      '&:hover': {
                        backgroundColor: 'action.hover',
                      },
                    }}
                  >
                    <ListItemIcon>
                      <DescriptionIcon color={assignment.status === 'submitted' ? 'success' : 'action'} />
                    </ListItemIcon>
                    <ListItemText 
                      primary={assignment.title}
                      secondary={`Due: ${assignment.dueDate}`}
                      primaryTypographyProps={{
                        fontWeight: 500,
                      }}
                    />
                    <Box display="flex" alignItems="center">
                      {assignment.status === 'submitted' ? (
                        <Chip 
                          label={`Grade: ${assignment.grade}`}
                          color="success"
                          variant="outlined"
                          size="small"
                          sx={{ ml: 1 }}
                        />
                      ) : (
                        <Chip 
                          label="Upcoming"
                          color="warning"
                          variant="outlined"
                          size="small"
                          sx={{ ml: 1 }}
                        />
                      )}
                    </Box>
                  </ListItem>
                  {index < courseData.assignments.length - 1 && <Divider />}
                </React.Fragment>
              ))}
            </List>
          </Box>
        )}
        
        {/* Discussion Tab */}
        {activeTab === 4 && (
          <Box>
            <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
              <Typography variant="h6">
                Discussion Forum
              </Typography>
              <Button variant="contained" color="primary">
                New Post
              </Button>
            </Box>
            
            <Box textAlign="center" py={6}>
              <ChatIcon sx={{ fontSize: 60, color: 'text.disabled', mb: 2, opacity: 0.5 }} />
              <Typography variant="h6" color="text.secondary" gutterBottom>
                No discussions yet
              </Typography>
              <Typography variant="body1" color="text.secondary" paragraph>
                Be the first to start a discussion in this course.
              </Typography>
              <Button variant="outlined" color="primary">
                Start a Discussion
              </Button>
            </Box>
          </Box>
        )}
        
        {/* Announcements Tab */}
        {activeTab === 5 && (
          <Box>
            <Box display="flex" justifyContent="space-between" alignItems="center" mb={3}>
              <Typography variant="h6">
                Announcements
              </Typography>
              <Button variant="outlined" color="primary">
                View All
              </Button>
            </Box>
            
            <Box textAlign="center" py={6}>
              <InfoIcon sx={{ fontSize: 60, color: 'text.disabled', mb: 2, opacity: 0.5 }} />
              <Typography variant="h6" color="text.secondary" gutterBottom>
                No announcements yet
              </Typography>
              <Typography variant="body1" color="text.secondary">
                Check back later for updates from your instructor.
              </Typography>
            </Box>
          </Box>
        )}
      </Box>
    </Container>
  );
};

export default CourseDetailPage;
