import React from 'react';
import { Avatar, Box, Typography, Paper, useTheme } from '@mui/material';
import { Message } from './types';
import { formatDistanceToNow } from 'date-fns';
import { useAuth } from '../../../contexts/AuthContext';

interface MessageItemProps {
  message: Message;
  isSender: boolean;
  showAvatar: boolean;
  showHeader: boolean;
}

export const MessageItem: React.FC<MessageItemProps> = ({
  message,
  isSender,
  showAvatar,
  showHeader,
}) => {
  const theme = useTheme();
  const { user } = useAuth();

  const renderMessageContent = () => {
    if (message.type === 'file' && message.file) {
      return (
        <a 
          href={message.file.url} 
          target="_blank" 
          rel="noopener noreferrer"
          style={{ 
            display: 'inline-flex', 
            alignItems: 'center',
            textDecoration: 'none',
            color: theme.palette.primary.main,
          }}
        >
          <Box
            sx={{
              p: 1.5,
              borderRadius: 1,
              backgroundColor: theme.palette.action.hover,
              display: 'flex',
              alignItems: 'center',
              gap: 1,
            }}
          >
            <Box>
              <Typography variant="body2" fontWeight="medium">
                {message.file.name}
              </Typography>
              <Typography variant="caption" color="text.secondary">
                {(message.file.size / 1024).toFixed(1)} KB
              </Typography>
            </Box>
          </Box>
        </a>
      );
    }
    
    return (
      <Typography variant="body1" sx={{ whiteSpace: 'pre-wrap', wordBreak: 'break-word' }}>
        {message.content}
      </Typography>
    );
  };

  return (
    <Box
      sx={{
        display: 'flex',
        flexDirection: isSender ? 'row-reverse' : 'row',
        mb: 1,
        gap: 1,
      }}
    >
      {showAvatar && !isSender && (
        <Avatar 
          sx={{ 
            width: 32, 
            height: 32, 
            mt: showHeader ? 'auto' : 0.5,
            alignSelf: showHeader ? 'flex-start' : 'flex-end',
          }}
        >
          {message.sender.charAt(0).toUpperCase()}
        </Avatar>
      )}
      
      <Box
        sx={{
          maxWidth: '70%',
          minWidth: '120px',
          display: 'flex',
          flexDirection: 'column',
          alignItems: isSender ? 'flex-end' : 'flex-start',
        }}
      >
        {showHeader && !isSender && (
          <Box sx={{ display: 'flex', alignItems: 'center', mb: 0.5 }}>
            <Typography variant="caption" fontWeight="bold" sx={{ mr: 1 }}>
              {message.sender === user?.id ? 'You' : message.sender}
            </Typography>
            <Typography variant="caption" color="text.secondary">
              {formatDistanceToNow(new Date(message.timestamp), { addSuffix: true })}
            </Typography>
          </Box>
        )}
        
        <Paper
          elevation={0}
          sx={{
            p: 1.5,
            borderRadius: 2,
            backgroundColor: isSender 
              ? theme.palette.primary.main 
              : theme.palette.mode === 'light' 
                ? theme.palette.grey[100] 
                : theme.palette.grey[800],
            color: isSender ? theme.palette.primary.contrastText : 'inherit',
            borderTopLeftRadius: isSender ? 12 : 4,
            borderTopRightRadius: isSender ? 4 : 12,
            borderBottomLeftRadius: isSender ? 12 : 4,
            borderBottomRightRadius: isSender ? 4 : 12,
          }}
        >
          {renderMessageContent()}
          <Box 
            sx={{ 
              display: 'flex', 
              justifyContent: 'flex-end',
              mt: 0.5,
            }}
          >
            <Typography 
              variant="caption" 
              sx={{ 
                fontSize: '0.7rem',
                color: isSender ? 'rgba(255, 255, 255, 0.7)' : 'text.secondary',
              }}
            >
              {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              {isSender && (
                <span style={{ marginLeft: 4 }}>
                  {message.read ? '✓✓' : '✓'}
                </span>
              )}
            </Typography>
          </Box>
        </Paper>
      </Box>
      
      {showAvatar && isSender && (
        <Avatar 
          sx={{ 
            width: 32, 
            height: 32, 
            bgcolor: 'transparent',
            mt: showHeader ? 'auto' : 0.5,
          }}
        />
      )}
    </Box>
  );
};
