import React, { createContext, useContext, useReducer, useEffect } from 'react';
import { useAuth } from '../../../contexts/AuthContext';
import { ChatState, Conversation, Message, ChatEventTypes } from './types';

// Mock WebSocket service - replace with your actual WebSocket implementation
const mockWebSocketService = {
  connect: () => {
    console.log('Connecting to WebSocket...');
    return {
      on: (event: string, callback: (data: any) => void) => {
        console.log(`Listening to ${event}`);
      },
      emit: (event: string, data: any) => {
        console.log(`Emitting ${event}:`, data);
      },
      disconnect: () => {
        console.log('Disconnecting WebSocket...');
      },
    };
  },
};

type ChatAction =
  | { type: 'SET_CONVERSATIONS'; payload: Conversation[] }
  | { type: 'SET_CURRENT_CONVERSATION'; payload: string | null }
  | { type: 'ADD_MESSAGE'; payload: { conversationId: string; message: Message } }
  | { type: 'SET_MESSAGES'; payload: { conversationId: string; messages: Message[] } }
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'SET_ERROR'; payload: string | null }
  | { type: 'SET_ONLINE_USERS'; payload: string[] };

const initialState: ChatState = {
  conversations: [],
  currentConversation: null,
  messages: {},
  loading: false,
  error: null,
  onlineUsers: [],
};

const chatReducer = (state: ChatState, action: ChatAction): ChatState => {
  switch (action.type) {
    case 'SET_CONVERSATIONS':
      return { ...state, conversations: action.payload };
    case 'SET_CURRENT_CONVERSATION':
      return { ...state, currentConversation: action.payload };
    case 'ADD_MESSAGE':
      return {
        ...state,
        messages: {
          ...state.messages,
          [action.payload.conversationId]: [
            ...(state.messages[action.payload.conversationId] || []),
            action.payload.message,
          ],
        },
      };
    case 'SET_MESSAGES':
      return {
        ...state,
        messages: {
          ...state.messages,
          [action.payload.conversationId]: action.payload.messages,
        },
      };
    case 'SET_LOADING':
      return { ...state, loading: action.payload };
    case 'SET_ERROR':
      return { ...state, error: action.payload };
    case 'SET_ONLINE_USERS':
      return { ...state, onlineUsers: action.payload };
    default:
      return state;
  }
};

interface ChatContextType extends ChatState {
  startConversation: (participants: string[], type: 'direct' | 'group' | 'course', name?: string, courseId?: string) => Promise<Conversation>;
  sendMessage: (conversationId: string, content: string, file?: File) => Promise<void>;
  markAsRead: (conversationId: string, messageIds: string[]) => Promise<void>;
  setCurrentConversation: (conversationId: string | null) => void;
  loadMoreMessages: (conversationId: string, before: Date) => Promise<void>;
  getUnreadCount: () => number;
}

const ChatContext = createContext<ChatContextType | undefined>(undefined);

export const ChatProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(chatReducer, initialState);
  const { user } = useAuth();
  const [socket, setSocket] = React.useState<any>(null);

  // Initialize WebSocket connection
  useEffect(() => {
    if (!user) return;

    const ws = mockWebSocketService.connect();
    setSocket(ws);

    // Set up event listeners
    ws.on(ChatEventTypes.MESSAGE, (data: { conversationId: string; message: Message }) => {
      dispatch({
        type: 'ADD_MESSAGE',
        payload: { conversationId: data.conversationId, message: data.message },
      });
    });

    ws.on(ChatEventTypes.USER_ONLINE, (userId: string) => {
      if (!state.onlineUsers.includes(userId)) {
        dispatch({
          type: 'SET_ONLINE_USERS',
          payload: [...state.onlineUsers, userId],
        });
      }
    });

    ws.on(ChatEventTypes.USER_OFFLINE, (userId: string) => {
      dispatch({
        type: 'SET_ONLINE_USERS',
        payload: state.onlineUsers.filter((id) => id !== userId),
      });
    });

    // Clean up on unmount
    return () => {
      ws.disconnect();
    };
  }, [user]);

  const startConversation = async (
    participants: string[],
    type: 'direct' | 'group' | 'course',
    name?: string,
    courseId?: string
  ): Promise<Conversation> => {
    try {
      dispatch({ type: 'SET_LOADING', payload: true });
      
      // In a real app, this would be an API call to create a new conversation
      const newConversation: Conversation = {
        id: `conv_${Date.now()}`,
        participants: [...participants, user?.id || ''],
        type,
        name,
        courseId,
        unreadCount: 0,
        createdAt: new Date(),
        updatedAt: new Date(),
      };

      // Update local state
      dispatch({
        type: 'SET_CONVERSATIONS',
        payload: [...state.conversations, newConversation],
      });

      // Notify other participants via WebSocket
      if (socket) {
        socket.emit(ChatEventTypes.CONVERSATION_CREATED, newConversation);
      }

      return newConversation;
    } catch (error) {
      dispatch({
        type: 'SET_ERROR',
        payload: error instanceof Error ? error.message : 'Failed to start conversation',
      });
      throw error;
    } finally {
      dispatch({ type: 'SET_LOADING', payload: false });
    }
  };

  const sendMessage = async (conversationId: string, content: string, file?: File): Promise<void> => {
    if (!user) return;

    try {
      // In a real app, this would be an API call to send the message
      const newMessage: Message = {
        id: `msg_${Date.now()}`,
        sender: user.id,
        content,
        timestamp: new Date(),
        read: false,
        type: file ? 'file' : 'text',
        file: file
          ? {
              name: file.name,
              url: URL.createObjectURL(file),
              type: file.type,
              size: file.size,
            }
          : undefined,
      };

      // Update local state
      dispatch({
        type: 'ADD_MESSAGE',
        payload: { conversationId, message: newMessage },
      });

      // Notify other participants via WebSocket
      if (socket) {
        socket.emit(ChatEventTypes.MESSAGE, {
          conversationId,
          message: newMessage,
        });
      }
    } catch (error) {
      dispatch({
        type: 'SET_ERROR',
        payload: error instanceof Error ? error.message : 'Failed to send message',
      });
      throw error;
    }
  };

  const markAsRead = async (conversationId: string, messageIds: string[]): Promise<void> => {
    // In a real app, this would be an API call to mark messages as read
    console.log(`Marking messages as read:`, { conversationId, messageIds });
    
    if (socket) {
      socket.emit(ChatEventTypes.MESSAGE_READ, {
        conversationId,
        messageIds,
        userId: user?.id,
      });
    }
  };

  const setCurrentConversation = (conversationId: string | null) => {
    dispatch({ type: 'SET_CURRENT_CONVERSATION', payload: conversationId });
  };

  const loadMoreMessages = async (conversationId: string, before: Date): Promise<void> => {
    try {
      dispatch({ type: 'SET_LOADING', payload: true });
      
      // In a real app, this would be an API call to fetch older messages
      const olderMessages: Message[] = []; // Replace with actual API call
      
      dispatch({
        type: 'SET_MESSAGES',
        payload: {
          conversationId,
          messages: [...olderMessages, ...(state.messages[conversationId] || [])],
        },
      });
    } catch (error) {
      dispatch({
        type: 'SET_ERROR',
        payload: error instanceof Error ? error.message : 'Failed to load messages',
      });
      throw error;
    } finally {
      dispatch({ type: 'SET_LOADING', payload: false });
    }
  };

  const getUnreadCount = (): number => {
    return state.conversations.reduce(
      (count, conv) => count + conv.unreadCount,
      0
    );
  };

  return (
    <ChatContext.Provider
      value={{
        ...state,
        startConversation,
        sendMessage,
        markAsRead,
        setCurrentConversation,
        loadMoreMessages,
        getUnreadCount,
      }}
    >
      {children}
    </ChatContext.Provider>
  );
};

export const useChat = (): ChatContextType => {
  const context = useContext(ChatContext);
  if (context === undefined) {
    throw new Error('useChat must be used within a ChatProvider');
  }
  return context;
};
