import React, { useEffect, useRef, useState } from 'react';
import { 
  Box, 
  Typography, 
  Paper, 
  IconButton, 
  Avatar, 
  Divider, 
  List, 
  ListItem, 
  ListItemAvatar, 
  ListItemText, 
  ListItemSecondaryAction, 
  Badge,
  TextField,
  InputAdornment,
  Tooltip,
  CircularProgress
} from '@mui/material';
import { 
  Search as SearchIcon, 
  MoreVert as MoreVertIcon, 
  Videocam as VideocamIcon,
  Info as InfoIcon,
  Group as GroupIcon,
  Person as PersonIcon,
  School as SchoolIcon,
  ArrowBack as ArrowBackIcon
} from '@mui/icons-material';
import { useChat } from './ChatContext';
import { MessageItem } from './MessageItem';
import { ChatInput } from './ChatInput';
import { formatDistanceToNow } from 'date-fns';
import { useAuth } from '../../../contexts/AuthContext';

interface ChatInterfaceProps {
  conversationId: string;
  onBack?: () => void;
  isMobile?: boolean;
}

export const ChatInterface: React.FC<ChatInterfaceProps> = ({ 
  conversationId, 
  onBack,
  isMobile = false
}) => {
  const { 
    conversations, 
    messages, 
    sendMessage, 
    currentConversation: currentConvId,
    setCurrentConversation,
    onlineUsers,
    loading
  } = useChat();
  const { user } = useAuth();
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [isScrolled, setIsScrolled] = useState(false);
  
  const conversation = conversations.find(c => c.id === conversationId);
  const conversationMessages = messages[conversationId] || [];
  const otherParticipants = conversation?.participants.filter(p => p !== user?.id) || [];
  const isGroup = conversation?.type === 'group' || conversation?.type === 'course';
  
  // Scroll to bottom when new messages arrive or conversation changes
  useEffect(() => {
    if (!isScrolled) {
      scrollToBottom();
    }
  }, [conversationMessages.length, conversationId, isScrolled]);
  
  // Set current conversation in context
  useEffect(() => {
    if (conversationId && conversationId !== currentConvId) {
      setCurrentConversation(conversationId);
    }
    
    return () => {
      setCurrentConversation(null);
    };
  }, [conversationId, currentConvId, setCurrentConversation]);
  
  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };
  
  const handleScroll = (e: React.UIEvent<HTMLDivElement>) => {
    const { scrollTop } = e.currentTarget;
    setIsScrolled(scrollTop < -10);
  };
  
  const handleSendMessage = async (content: string) => {
    if (!content.trim()) return;
    
    try {
      await sendMessage(conversationId, content);
      scrollToBottom();
    } catch (error) {
      console.error('Failed to send message:', error);
    }
  };
  
  const renderHeader = () => (
    <Paper 
      elevation={0} 
      sx={{ 
        p: 2, 
        display: 'flex', 
        alignItems: 'center',
        borderBottom: '1px solid',
        borderColor: 'divider',
        borderRadius: 0,
        bgcolor: 'background.paper',
      }}
    >
      {isMobile && onBack && (
        <IconButton onClick={onBack} sx={{ mr: 1 }}>
          <ArrowBackIcon />
        </IconButton>
      )}
      
      <Box display="flex" alignItems="center" flex={1}>
        <Badge
          overlap="circular"
          anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
          variant="dot"
          color="success"
          invisible={!onlineUsers.some(id => otherParticipants.includes(id))}
        >
          <Avatar 
            src={conversation?.avatar} 
            sx={{ width: 40, height: 40, mr: 2 }}
          >
            {conversation?.name?.charAt(0) || 'G'}
          </Avatar>
        </Badge>
        
        <Box>
          <Typography variant="subtitle1" fontWeight="medium">
            {conversation?.name || otherParticipants.join(', ')}
          </Typography>
          <Typography variant="caption" color="text.secondary">
            {isGroup 
              ? `${otherParticipants.length} participants`
              : onlineUsers.some(id => otherParticipants.includes(id)) 
                ? 'Online' 
                : 'Offline'}
          </Typography>
        </Box>
      </Box>
      
      <Box>
        <Tooltip title="Start video call">
          <IconButton 
            color="primary" 
            onClick={() => console.log('Start video call')}
            sx={{ mr: 1 }}
          >
            <VideocamIcon />
          </IconButton>
        </Tooltip>
        
        <Tooltip title="Conversation info">
          <IconButton onClick={() => console.log('Show conversation info')}>
            <InfoIcon />
          </IconButton>
        </Tooltip>
      </Box>
    </Paper>
  );
  
  const renderMessageList = () => (
    <Box 
      sx={{ 
        flex: 1, 
        overflowY: 'auto', 
        p: 2,
        display: 'flex',
        flexDirection: 'column',
      }}
      onScroll={handleScroll}
    >
      {loading && conversationMessages.length === 0 ? (
        <Box display="flex" justifyContent="center" alignItems="center" height="100%">
          <CircularProgress />
        </Box>
      ) : (
        <>
          {conversationMessages.length === 0 ? (
            <Box 
              display="flex" 
              flexDirection="column" 
              alignItems="center" 
              justifyContent="center" 
              height="100%"
              textAlign="center"
              p={3}
            >
              <Avatar sx={{ width: 64, height: 64, mb: 2, bgcolor: 'primary.main' }}>
                <SchoolIcon sx={{ fontSize: 32 }} />
              </Avatar>
              <Typography variant="h6" gutterBottom>
                No messages yet
              </Typography>
              <Typography variant="body2" color="text.secondary" paragraph>
                Send a message to start the conversation
              </Typography>
            </Box>
          ) : (
            <>
              {conversationMessages.map((message, index) => {
                const prevMessage = index > 0 ? conversationMessages[index - 1] : null;
                const nextMessage = index < conversationMessages.length - 1 ? conversationMessages[index + 1] : null;
                const isSameSender = prevMessage && prevMessage.sender === message.sender;
                const isSameDay = prevMessage && 
                  new Date(message.timestamp).toDateString() === new Date(prevMessage.timestamp).toDateString();
                const showHeader = !isSameSender || !isSameDay;
                
                return (
                  <React.Fragment key={message.id}>
                    {showHeader && (
                      <Box textAlign="center" my={2}>
                        <Typography variant="caption" color="text.secondary">
                          {new Date(message.timestamp).toLocaleDateString(undefined, {
                            weekday: 'long',
                            year: 'numeric',
                            month: 'long',
                            day: 'numeric',
                          })}
                        </Typography>
                      </Box>
                    )}
                    
                    <MessageItem
                      message={message}
                      isSender={message.sender === user?.id}
                      showAvatar={!isSameSender || !isSameDay}
                      showHeader={showHeader}
                    />
                    
                    {nextMessage && nextMessage.sender !== message.sender && (
                      <Box mb={2} />
                    )}
                  </React.Fragment>
                );
              })}
              <div ref={messagesEndRef} />
            </>
          )}
        </>
      )}
    </Box>
  );
  
  return (
    <Box 
      sx={{ 
        display: 'flex', 
        flexDirection: 'column', 
        height: '100%',
        bgcolor: 'background.default',
      }}
    >
      {renderHeader()}
      {renderMessageList()}
      <Divider />
      <ChatInput 
        conversationId={conversationId} 
        disabled={!conversation}
        onSendMessage={scrollToBottom}
      />
    </Box>
  );
};
