import React, { useRef, useState, useCallback } from 'react';
import { Box, TextField, IconButton, Tooltip, Paper, InputAdornment } from '@mui/material';
import { Send as SendIcon, AttachFile as AttachFileIcon, Mood as MoodIcon } from '@mui/icons-material';
import { useChat } from './ChatContext';

interface ChatInputProps {
  conversationId: string;
  onSendMessage?: () => void;
  disabled?: boolean;
}

export const ChatInput: React.FC<ChatInputProps> = ({ conversationId, onSendMessage, disabled = false }) => {
  const [message, setMessage] = useState('');
  const [isComposing, setIsComposing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { sendMessage, loading } = useChat();

  const handleSendMessage = useCallback(async () => {
    if ((!message.trim() && !fileInputRef.current?.files?.length) || loading) return;

    try {
      await sendMessage(conversationId, message.trim());
      setMessage('');
      
      // Handle file upload if any
      if (fileInputRef.current?.files?.length) {
        const file = fileInputRef.current.files[0];
        await sendMessage(conversationId, file.name, file);
        fileInputRef.current.value = ''; // Reset file input
      }
      
      onSendMessage?.();
    } catch (error) {
      console.error('Failed to send message:', error);
    }
  }, [message, conversationId, sendMessage, onSendMessage, loading]);

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey && !isComposing) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.length) {
      // Auto-send the file if there's no text, otherwise append to message
      if (!message.trim()) {
        const file = e.target.files[0];
        sendMessage(conversationId, file.name, file);
        e.target.value = ''; // Reset file input
      }
    }
  };

  return (
    <Paper 
      elevation={0}
      sx={{
        p: 1,
        borderTop: '1px solid',
        borderColor: 'divider',
        borderRadius: 0,
        bgcolor: 'background.paper',
      }}
    >
      <Box display="flex" alignItems="center" gap={1}>
        <Tooltip title="Attach file">
          <IconButton 
            component="label" 
            disabled={disabled || loading}
            size="small"
          >
            <AttachFileIcon fontSize="small" />
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileSelect}
              style={{ display: 'none' }}
              disabled={disabled || loading}
            />
          </IconButton>
        </Tooltip>
        
        <TextField
          fullWidth
          variant="outlined"
          placeholder="Type a message..."
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          onKeyDown={handleKeyDown}
          onCompositionStart={() => setIsComposing(true)}
          onCompositionEnd={() => setIsComposing(false)}
          disabled={disabled || loading}
          multiline
          maxRows={4}
          size="small"
          InputProps={{
            sx: { borderRadius: 4, bgcolor: 'background.paper' },
            endAdornment: (
              <InputAdornment position="end">
                <IconButton 
                  size="small" 
                  disabled={disabled || loading || (!message.trim() && !fileInputRef.current?.files?.length)}
                  onClick={handleSendMessage}
                >
                  <SendIcon 
                    color={!message.trim() && !fileInputRef.current?.files?.length ? 'disabled' : 'primary'} 
                    fontSize="small" 
                  />
                </IconButton>
              </InputAdornment>
            ),
          }}
        />
        
        <Tooltip title="Emoji">
          <span>
            <IconButton disabled={disabled || loading} size="small">
              <MoodIcon fontSize="small" />
            </IconButton>
          </span>
        </Tooltip>
      </Box>
      
      {fileInputRef.current?.files?.length > 0 && (
        <Box mt={1} display="flex" alignItems="center" gap={1}>
          <Typography variant="caption" color="text.secondary">
            {fileInputRef.current.files[0].name}
          </Typography>
          <IconButton 
            size="small" 
            onClick={() => {
              if (fileInputRef.current) fileInputRef.current.value = '';
            }}
          >
            <Typography variant="caption" color="error">
              ×
            </Typography>
          </IconButton>
        </Box>
      )}
    </Paper>
  );
};
