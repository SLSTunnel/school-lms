export interface User {
  id: string;
  name: string;
  avatar?: string;
  role: 'student' | 'teacher' | 'admin' | 'principal';
  online?: boolean;
}

export interface Message {
  id: string;
  sender: string; // User ID
  content: string;
  timestamp: Date;
  read: boolean;
  type: 'text' | 'file' | 'system';
  file?: {
    name: string;
    url: string;
    type: string;
    size: number;
  };
}

export interface Conversation {
  id: string;
  participants: string[]; // User IDs
  type: 'direct' | 'group' | 'course';
  name?: string; // For group chats
  courseId?: string; // For course-related chats
  lastMessage?: Message;
  unreadCount: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface ChatState {
  conversations: Conversation[];
  currentConversation: string | null;
  messages: Record<string, Message[]>;
  loading: boolean;
  error: string | null;
  onlineUsers: string[]; // User IDs of online users
}

export const ChatEventTypes = {
  MESSAGE: 'message',
  MESSAGE_READ: 'message_read',
  TYPING: 'typing',
  USER_ONLINE: 'user_online',
  USER_OFFLINE: 'user_offline',
  CONVERSATION_CREATED: 'conversation_created',
  CONVERSATION_UPDATED: 'conversation_updated',
} as const;
