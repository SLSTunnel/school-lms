import React, { useEffect, useRef, useState, useCallback } from 'react';
import {
  Box,
  Button,
  IconButton,
  Paper,
  Typography,
  Avatar,
  Tooltip,
  Divider,
  Badge,
  useTheme,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  LinearProgress,
  Tabs,
  Tab,
  TextField,
  List,
  ListItem,
  ListItemAvatar,
  ListItemText,
  ListItemSecondaryAction,
  Chip,
} from '@mui/material';
import {
  Mic as MicIcon,
  MicOff as MicOffIcon,
  Videocam as VideocamIcon,
  VideocamOff as VideocamOffIcon,
  ScreenShare as ScreenShareIcon,
  StopScreenShare as StopScreenShareIcon,
  CallEnd as CallEndIcon,
  Chat as ChatIcon,
  People as PeopleIcon,
  Close as CloseIcon,
  Send as SendIcon,
  PanTool as HandRaiseIcon,
  FiberManualRecord as RecordIcon,
  Stop as StopIcon,
  MoreVert as MoreVertIcon,
  Check as CheckIcon,
  Clear as ClearIcon,
  Person as PersonIcon,
  School as SchoolIcon,
  AdminPanelSettings as AdminIcon,
} from '@mui/icons-material';
import { useWebRTC, Participant, ConferenceMessage } from './WebRTCContext';
import { useAuth } from '../../../contexts/AuthContext';
import { formatDistanceToNow } from 'date-fns';

interface ConferenceInterfaceProps {
  roomId: string;
  onLeave?: () => void;
}

const ConferenceInterface: React.FC<ConferenceInterfaceProps> = ({ roomId, onLeave }) => {
  const theme = useTheme();
  const { user } = useAuth();
  const {
    room,
    participants,
    streams,
    messages,
    localStream,
    isMuted,
    isVideoOn,
    isScreenSharing,
    isLoading,
    error,
    joinRoom,
    leaveRoom,
    toggleMute,
    toggleVideo,
    toggleScreenShare,
    sendMessage,
    raiseHand,
    startRecording,
    stopRecording,
    endMeeting,
  } = useWebRTC();
  
  const [activeTab, setActiveTab] = useState('chat');
  const [messageInput, setMessageInput] = useState('');
  const [showLeaveDialog, setShowLeaveDialog] = useState(false);
  const [showEndMeetingDialog, setShowEndMeetingDialog] = useState(false);
  const [showParticipants, setShowParticipants] = useState(false);
  const [showChat, setShowChat] = useState(true);
  const [isHandRaised, setIsHandRaised] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const videoGridRef = useRef<HTMLDivElement>(null);
  const localVideoRef = useRef<HTMLVideoElement>(null);
  const remoteVideosRef = useRef<{[key: string]: HTMLVideoElement | null}>({});

  // Join the room when the component mounts
  useEffect(() => {
    const join = async () => {
      try {
        await joinRoom(roomId, { audio: true, video: false });
      } catch (error) {
        console.error('Failed to join room:', error);
      }
    };

    join();

    // Clean up on unmount
    return () => {
      leaveRoom();
    };
  }, [joinRoom, leaveRoom, roomId]);

  // Update video elements when streams change
  useEffect(() => {
    // Update local video
    if (localVideoRef.current && localStream) {
      localVideoRef.current.srcObject = localStream;
    }

    // Update remote videos
    Object.entries(remoteVideosRef.current).forEach(([id, videoEl]) => {
      if (videoEl) {
        const stream = streams.find(s => s.id === id)?.stream;
        if (stream && videoEl.srcObject !== stream) {
          videoEl.srcObject = stream;
        }
      }
    });
  }, [streams, localStream]);

  // Scroll to bottom of messages when new messages arrive
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // Handle leaving the conference
  const handleLeave = useCallback(async () => {
    try {
      await leaveRoom();
      onLeave?.();
    } catch (error) {
      console.error('Error leaving conference:', error);
    }
  }, [leaveRoom, onLeave]);

  // Handle sending a message
  const handleSendMessage = useCallback(async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!messageInput.trim()) return;
    
    try {
      await sendMessage(messageInput);
      setMessageInput('');
    } catch (error) {
      console.error('Failed to send message:', error);
    }
  }, [messageInput, sendMessage]);

  // Toggle hand raise
  const handleToggleHandRaise = useCallback(async () => {
    try {
      await raiseHand();
      setIsHandRaised(prev => !prev);
    } catch (error) {
      console.error('Failed to raise hand:', error);
    }
  }, [raiseHand]);

  // Toggle recording
  const handleToggleRecording = useCallback(async () => {
    try {
      if (room?.settings.recordSession) {
        await stopRecording();
      } else {
        await startRecording();
      }
    } catch (error) {
      console.error('Failed to toggle recording:', error);
    }
  }, [room?.settings.recordSession, startRecording, stopRecording]);

  // Render participant video
  const renderParticipantVideo = (participant: Participant) => {
    const stream = streams.find(s => s.userId === participant.userId && s.type === 'camera');
    const screenShare = streams.find(s => s.userId === participant.userId && s.type === 'screen');
    const isCurrentUser = participant.userId === user?.id;

    return (
      <Box
        key={participant.id}
        sx={{
          position: 'relative',
          borderRadius: 2,
          overflow: 'hidden',
          bgcolor: 'background.paper',
          boxShadow: 1,
          aspectRatio: '16/9',
          display: 'flex',
          flexDirection: 'column',
        }}
      >
        {/* Video element */}
        <Box flex={1} position="relative">
          <video
            ref={el => {
              if (el) {
                remoteVideosRef.current[`video-${participant.id}`] = el;
              } else {
                delete remoteVideosRef.current[`video-${participant.id}`];
              }
            }}
            autoPlay
            playsInline
            muted={isCurrentUser}
            style={{
              width: '100%',
              height: '100%',
              objectFit: 'cover',
              transform: 'rotateY(180deg)',
              display: stream || screenShare ? 'block' : 'none',
            }}
          />
          
          {/* Video off state */}
          {!stream && !screenShare && (
            <Box
              sx={{
                position: 'absolute',
                top: 0,
                left: 0,
                right: 0,
                bottom: 0,
                display: 'flex',
                flexDirection: 'column',
                alignItems: 'center',
                justifyContent: 'center',
                bgcolor: 'background.default',
              }}
            >
              <Avatar 
                sx={{ 
                  width: 80, 
                  height: 80, 
                  mb: 2,
                  bgcolor: theme.palette.primary.main,
                }}
              >
                {participant.name.charAt(0).toUpperCase()}
              </Avatar>
              <Typography variant="subtitle1">
                {isCurrentUser ? 'You' : participant.name}
              </Typography>
              <Typography variant="caption" color="text.secondary">
                {participant.role.charAt(0).toUpperCase() + participant.role.slice(1)}
              </Typography>
            </Box>
          )}
          
          {/* Participant info overlay */}
          <Box
            sx={{
              position: 'absolute',
              bottom: 0,
              left: 0,
              right: 0,
              p: 1,
              background: 'linear-gradient(transparent, rgba(0,0,0,0.7))',
              color: 'white',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'space-between',
            }}
          >
            <Box display="flex" alignItems="center">
              {participant.isMuted ? (
                <MicOffIcon fontSize="small" sx={{ mr: 0.5 }} />
              ) : (
                <MicIcon fontSize="small" sx={{ mr: 0.5 }} />
              )}
              <Typography variant="caption" noWrap>
                {isCurrentUser ? 'You' : participant.name}
              </Typography>
            </Box>
            
            <Box display="flex" alignItems="center">
              {participant.role === 'teacher' && (
                <SchoolIcon fontSize="small" sx={{ mr: 0.5 }} />
              )}
              {participant.role === 'admin' && (
                <AdminIcon fontSize="small" sx={{ mr: 0.5 }} />
              )}
              {isHandRaised && isCurrentUser && (
                <HandRaiseIcon fontSize="small" sx={{ mr: 0.5 }} />
              )}
            </Box>
          </Box>
        </Box>
        
        {/* Screen share indicator */}
        {screenShare && (
          <Box
            sx={{
              position: 'absolute',
              top: 8,
              left: 8,
              bgcolor: 'rgba(0,0,0,0.6)',
              color: 'white',
              px: 1,
              py: 0.5,
              borderRadius: 1,
              display: 'flex',
              alignItems: 'center',
            }}
          >
            <ScreenShareIcon fontSize="small" sx={{ mr: 0.5 }} />
            <Typography variant="caption">
              {isCurrentUser ? 'You are sharing your screen' : `${participant.name} is sharing their screen`}
            </Typography>
          </Box>
        )}
      </Box>
    );
  };

  // Render chat message
  const renderMessage = (message: ConferenceMessage) => {
    const isCurrentUser = message.senderId === user?.id;
    const isSystem = message.type === 'system' || message.type === 'hand_raised';
    
    if (isSystem) {
      return (
        <Box key={message.id} textAlign="center" my={1} px={1}>
          <Chip
            size="small"
            label={
              <Box display="flex" alignItems="center">
                {message.type === 'hand_raised' && (
                  <HandRaiseIcon fontSize="small" sx={{ mr: 0.5 }} />
                )}
                <Typography variant="caption">
                  <strong>{message.senderName}</strong> {message.content}
                </Typography>
              </Box>
            }
            sx={{ 
              bgcolor: 'action.hover',
              color: 'text.primary',
              borderRadius: 1,
            }}
          />
        </Box>
      );
    }
    
    return (
      <Box
        key={message.id}
        sx={{
          display: 'flex',
          justifyContent: isCurrentUser ? 'flex-end' : 'flex-start',
          mb: 1,
          px: 1,
        }}
      >
        <Box
          sx={{
            maxWidth: '80%',
            p: 1.5,
            borderRadius: 2,
            bgcolor: isCurrentUser ? 'primary.main' : 'background.paper',
            color: isCurrentUser ? 'primary.contrastText' : 'text.primary',
            boxShadow: 1,
          }}
        >
          {!isCurrentUser && (
            <Typography variant="caption" fontWeight="bold" display="block" mb={0.5}>
              {message.senderName}
            </Typography>
          )}
          <Typography variant="body2">{message.content}</Typography>
          <Typography 
            variant="caption" 
            display="block" 
            textAlign="right"
            sx={{ 
              opacity: 0.8,
              mt: 0.5,
              color: isCurrentUser ? 'rgba(255,255,255,0.8)' : 'text.secondary',
            }}
          >
            {new Date(message.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
          </Typography>
        </Box>
      </Box>
    );
  };

  // Show loading state
  if (isLoading || !room) {
    return (
      <Box
        display="flex"
        flexDirection="column"
        alignItems="center"
        justifyContent="center"
        height="100%"
        p={3}
      >
        <CircularProgress />
        <Typography variant="h6" sx={{ mt: 2 }}>
          Joining conference...
        </Typography>
      </Box>
    );
  }

  // Show error state
  if (error) {
    return (
      <Box
        display="flex"
        flexDirection="column"
        alignItems="center"
        justifyContent="center"
        height="100%"
        p={3}
        textAlign="center"
      >
        <Typography color="error" variant="h6" gutterBottom>
          Error joining conference
        </Typography>
        <Typography color="text.secondary" paragraph>
          {error}
        </Typography>
        <Button 
          variant="contained" 
          color="primary" 
          onClick={handleLeave}
          startIcon={<CallEndIcon />}
        >
          Leave
        </Button>
      </Box>
    );
  }

  // Calculate grid layout based on number of participants
  const participantCount = participants.length;
  const gridTemplateColumns = participantCount <= 2 ? '1fr' : 'repeat(2, 1fr)';
  const gridGap = theme.spacing(2);

  return (
    <Box display="flex" height="100vh" bgcolor="background.default">
      {/* Main content area */}
      <Box 
        flex={1} 
        display="flex" 
        flexDirection="column"
        overflow="hidden"
      >
        {/* Header */}
        <Box
          sx={{
            p: 2,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'space-between',
            borderBottom: '1px solid',
            borderColor: 'divider',
            bgcolor: 'background.paper',
          }}
        >
          <Box>
            <Typography variant="h6" noWrap>
              {room.title}
            </Typography>
            <Typography variant="caption" color="text.secondary">
              {participants.length} participant{participants.length !== 1 ? 's' : ''}
            </Typography>
          </Box>
          
          <Box display="flex" alignItems="center">
            {room.settings.recordSession && (
              <Chip
                icon={<FiberManualRecordIcon color="error" />}
                label="REC"
                size="small"
                sx={{ mr: 1, color: 'error.main', bgcolor: 'error.light' }}
              />
            )}
            
            <Tooltip title="Participants">
              <IconButton 
                onClick={() => setShowParticipants(!showParticipants)}
                color={showParticipants ? 'primary' : 'default'}
                sx={{ mr: 1 }}
              >
                <Badge badgeContent={participants.length} color="primary">
                  <PeopleIcon />
                </Badge>
              </IconButton>
            </Tooltip>
            
            <Tooltip title="Chat">
              <IconButton 
                onClick={() => setShowChat(!showChat)}
                color={showChat ? 'primary' : 'default'}
                sx={{ mr: 1 }}
              >
                <Badge 
                  badgeContent={messages.filter(m => 
                    m.type === 'chat' && 
                    m.senderId !== user?.id && 
                    !m.isRead
                  ).length} 
                  color="primary"
                >
                  <ChatIcon />
                </Badge>
              </IconButton>
            </Tooltip>
            
            <Button
              variant="contained"
              color="error"
              startIcon={<CallEndIcon />}
              onClick={() => setShowLeaveDialog(true)}
            >
              Leave
            </Button>
          </Box>
        </Box>
        
        {/* Video grid */}
        <Box
          ref={videoGridRef}
          sx={{
            flex: 1,
            p: 2,
            overflow: 'auto',
            display: 'grid',
            gridTemplateColumns,
            gap: gridGap,
            alignContent: 'flex-start',
            [theme.breakpoints.down('sm')]: {
              gridTemplateColumns: '1fr',
            },
          }}
        >
          {participants.map(participant => (
            <Box key={participant.id}>
              {renderParticipantVideo(participant)}
            </Box>
          ))}
        </Box>
        
        {/* Controls */}
        <Box
          sx={{
            p: 2,
            display: 'flex',
            justifyContent: 'center',
            borderTop: '1px solid',
            borderColor: 'divider',
            bgcolor: 'background.paper',
          }}
        >
          <Box display="flex" alignItems="center" gap={2}>
            <Tooltip title={isMuted ? 'Unmute' : 'Mute'}>
              <IconButton
                color={isMuted ? 'error' : 'default'}
                onClick={toggleMute}
                sx={{
                  bgcolor: isMuted ? 'error.light' : 'action.hover',
                  '&:hover': {
                    bgcolor: isMuted ? 'error.light' : 'action.hover',
                  },
                }}
              >
                {isMuted ? <MicOffIcon /> : <MicIcon />}
              </IconButton>
            </Tooltip>
            
            <Tooltip title={isVideoOn ? 'Turn off camera' : 'Turn on camera'}>
              <IconButton
                color={isVideoOn ? 'default' : 'error'}
                onClick={toggleVideo}
                sx={{
                  bgcolor: isVideoOn ? 'action.hover' : 'error.light',
                  '&:hover': {
                    bgcolor: isVideoOn ? 'action.hover' : 'error.light',
                  },
                }}
              >
                {isVideoOn ? <VideocamIcon /> : <VideocamOffIcon />}
              </IconButton>
            </Tooltip>
            
            <Tooltip title={isScreenSharing ? 'Stop sharing' : 'Share screen'}>
              <span>
                <IconButton
                  color={isScreenSharing ? 'primary' : 'default'}
                  onClick={toggleScreenShare}
                  disabled={!room.settings.allowScreenSharing}
                >
                  {isScreenSharing ? <StopScreenShareIcon /> : <ScreenShareIcon />}
                </IconButton>
              </span>
            </Tooltip>
            
            <Tooltip title={isHandRaised ? 'Lower hand' : 'Raise hand'}>
              <IconButton
                color={isHandRaised ? 'primary' : 'default'}
                onClick={handleToggleHandRaise}
              >
                <HandRaiseIcon />
              </IconButton>
            </Tooltip>
            
            {user?.role === 'teacher' || user?.role === 'admin' ? (
              <>
                <Divider orientation="vertical" flexItem />
                
                <Tooltip title={room.settings.recordSession ? 'Stop recording' : 'Start recording'}>
                  <IconButton
                    color={room.settings.recordSession ? 'error' : 'default'}
                    onClick={handleToggleRecording}
                  >
                    {room.settings.recordSession ? <StopIcon /> : <RecordIcon />}
                  </IconButton>
                </Tooltip>
                
                <Button
                  variant="contained"
                  color="error"
                  startIcon={<CallEndIcon />}
                  onClick={() => setShowEndMeetingDialog(true)}
                >
                  End meeting for all
                </Button>
              </>
            ) : null}
          </Box>
        </Box>
      </Box>
      
      {/* Sidebar */}
      <Box
        sx={{
          width: 320,
          borderLeft: '1px solid',
          borderColor: 'divider',
          display: 'flex',
          flexDirection: 'column',
          bgcolor: 'background.paper',
          [theme.breakpoints.down('md')]: {
            position: 'fixed',
            top: 0,
            right: 0,
            bottom: 0,
            width: '100%',
            maxWidth: 400,
            boxShadow: 3,
            zIndex: theme.zIndex.drawer,
            transform: showChat || showParticipants ? 'translateX(0)' : 'translateX(100%)',
            transition: theme.transitions.create('transform', {
              easing: theme.transitions.easing.sharp,
              duration: theme.transitions.duration.enteringScreen,
            }),
          },
        }}
      >
        {/* Tabs */}
        <Box borderBottom={1} borderColor="divider">
          <Tabs
            value={activeTab}
            onChange={(_, newValue) => setActiveTab(newValue)}
            variant="fullWidth"
            sx={{
              '& .MuiTabs-indicator': {
                height: 3,
              },
            }}
          >
            <Tab 
              label={
                <Box display="flex" alignItems="center">
                  <ChatIcon fontSize="small" sx={{ mr: 1 }} />
                  <span>Chat</span>
                </Box>
              } 
              value="chat" 
              sx={{ minHeight: 48 }}
            />
            <Tab 
              label={
                <Box display="flex" alignItems="center">
                  <PeopleIcon fontSize="small" sx={{ mr: 1 }} />
                  <span>People ({participants.length})</span>
                </Box>
              } 
              value="people" 
              sx={{ minHeight: 48 }}
            />
          </Tabs>
        </Box>
        
        {/* Close button for mobile */}
        <IconButton
          onClick={() => {
            setShowChat(false);
            setShowParticipants(false);
          }}
          sx={{
            position: 'absolute',
            right: 8,
            top: 8,
            display: { xs: 'flex', md: 'none' },
          }}
        >
          <CloseIcon />
        </IconButton>
        
        {/* Tab content */}
        <Box flex={1} display="flex" flexDirection="column" overflow="hidden">
          {/* Chat tab */}
          {activeTab === 'chat' && (
            <>
              <Box flex={1} overflow="auto" p={2}>
                {messages.length === 0 ? (
                  <Box
                    display="flex"
                    flexDirection="column"
                    alignItems="center"
                    justifyContent="center"
                    height="100%"
                    textAlign="center"
                    p={3}
                  >
                    <ChatIcon fontSize="large" color="disabled" sx={{ mb: 2 }} />
                    <Typography variant="subtitle1" color="text.secondary">
                      No messages yet
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Send a message to start the conversation
                    </Typography>
                  </Box>
                ) : (
                  <>
                    {messages.map(renderMessage)}
                    <div ref={messagesEndRef} />
                  </>
                )}
              </Box>
              
              <Box p={1} borderTop={1} borderColor="divider">
                <form onSubmit={handleSendMessage}>
                  <TextField
                    fullWidth
                    variant="outlined"
                    placeholder="Type a message..."
                    value={messageInput}
                    onChange={(e) => setMessageInput(e.target.value)}
                    size="small"
                    InputProps={{
                      sx: { borderRadius: 4 },
                      endAdornment: (
                        <InputAdornment position="end">
                          <IconButton 
                            type="submit" 
                            disabled={!messageInput.trim()}
                            color="primary"
                          >
                            <SendIcon />
                          </IconButton>
                        </InputAdornment>
                      ),
                    }}
                  />
                </form>
              </Box>
            </>
          )}
          
          {/* People tab */}
          {activeTab === 'people' && (
            <Box overflow="auto" p={2}>
              <List dense>
                {participants.map((participant) => (
                  <ListItem key={participant.id}>
                    <ListItemAvatar>
                      <Badge
                        overlap="circular"
                        anchorOrigin={{ vertical: 'bottom', horizontal: 'right' }}
                        variant="dot"
                        color="success"
                        invisible={!participant.isConnected}
                      >
                        <Avatar>
                          {participant.name.charAt(0).toUpperCase()}
                        </Avatar>
                      </Badge>
                    </ListItemAvatar>
                    <ListItemText
                      primary={
                        <Box display="flex" alignItems="center">
                          <Typography noWrap>
                            {participant.name}
                            {participant.userId === room.hostId && (
                              <Chip 
                                label="Host" 
                                size="small" 
                                sx={{ ml: 1, height: 18 }} 
                              />
                            )}
                          </Typography>
                        </Box>
                      }
                      secondary={
                        <Box display="flex" alignItems="center">
                          {participant.role === 'teacher' ? (
                            <SchoolIcon fontSize="small" sx={{ mr: 0.5, fontSize: 14 }} />
                          ) : (
                            <PersonIcon fontSize="small" sx={{ mr: 0.5, fontSize: 14 }} />
                          )}
                          <Typography variant="caption" color="text.secondary">
                            {participant.role.charAt(0).toUpperCase() + participant.role.slice(1)}
                          </Typography>
                        </Box>
                      }
                    />
                    <ListItemSecondaryAction>
                      <IconButton edge="end" size="small">
                        <MoreVertIcon fontSize="small" />
                      </IconButton>
                    </ListItemSecondaryAction>
                  </ListItem>
                ))}
              </List>
            </Box>
          )}
        </Box>
      </Box>
      
      {/* Leave dialog */}
      <Dialog
        open={showLeaveDialog}
        onClose={() => setShowLeaveDialog(false)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>Leave the meeting?</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Are you sure you want to leave the meeting? You can rejoin later if the meeting is still in progress.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setShowLeaveDialog(false)}>Cancel</Button>
          <Button 
            onClick={handleLeave} 
            color="primary" 
            variant="contained"
            autoFocus
          >
            Leave
          </Button>
        </DialogActions>
      </Dialog>
      
      {/* End meeting dialog (host only) */}
      <Dialog
        open={showEndMeetingDialog}
        onClose={() => setShowEndMeetingDialog(false)}
        maxWidth="sm"
        fullWidth
      >
        <DialogTitle>End meeting for all participants?</DialogTitle>
        <DialogContent>
          <DialogContentText>
            This will end the meeting for all participants. This action cannot be undone.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => setShowEndMeetingDialog(false)}>Cancel</Button>
          <Button 
            onClick={async () => {
              await endMeeting();
              setShowEndMeetingDialog(false);
              onLeave?.();
            }} 
            color="error" 
            variant="contained"
            autoFocus
          >
            End meeting for all
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
};

export default ConferenceInterface;
