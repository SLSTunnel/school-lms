export interface Participant {
  id: string;
  userId: string;
  name: string;
  avatar?: string;
  role: 'student' | 'teacher' | 'admin' | 'principal';
  isHost: boolean;
  isMuted: boolean;
  isVideoOn: boolean;
  isScreenSharing: boolean;
  connectionState: 'new' | 'connecting' | 'connected' | 'disconnected' | 'failed';
}

export interface ConferenceRoom {
  id: string;
  courseId: string;
  title: string;
  description?: string;
  startTime: Date;
  endTime?: Date;
  hostId: string;
  participants: string[]; // User IDs
  isActive: boolean;
  settings: {
    allowVideo: boolean;
    allowAudio: boolean;
    allowScreenSharing: boolean;
    allowChat: boolean;
    recordSession: boolean;
    waitingRoom: boolean;
    muteOnEntry: boolean;
  };
}

export interface Stream {
  id: string;
  userId: string;
  stream: MediaStream;
  type: 'camera' | 'screen';
  isActive: boolean;
}

export const ConferenceEventTypes = {
  ROOM_CREATED: 'room_created',
  ROOM_UPDATED: 'room_updated',
  ROOM_ENDED: 'room_ended',
  PARTICIPANT_JOINED: 'participant_joined',
  PARTICIPANT_LEFT: 'participant_left',
  PARTICIPANT_UPDATED: 'participant_updated',
  MESSAGE: 'message',
  RAISE_HAND: 'raise_hand',
  SCREEN_SHARE_STARTED: 'screen_share_started',
  SCREEN_SHARE_ENDED: 'screen_share_ended',
  RECORDING_STARTED: 'recording_started',
  RECORDING_STOPPED: 'recording_stopped',
} as const;

export interface ConferenceMessage {
  id: string;
  senderId: string;
  senderName: string;
  content: string;
  timestamp: Date;
  type: 'chat' | 'system' | 'hand_raised' | 'reaction';
  metadata?: Record<string, any>;
}
