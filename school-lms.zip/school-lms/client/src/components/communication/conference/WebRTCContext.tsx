import React, { createContext, useContext, useReducer, useEffect, useCallback } from 'react';
import { useAuth } from '../../../contexts/AuthContext';
import { 
  Participant, 
  ConferenceRoom, 
  Stream, 
  ConferenceMessage,
  ConferenceEventTypes 
} from './types';

// Mock WebSocket service - replace with your actual WebRTC/WebSocket implementation
const mockWebSocketService = {
  connect: (roomId: string, userId: string) => {
    console.log(`Connecting to conference room ${roomId} as ${userId}`);
    return {
      on: (event: string, callback: (data: any) => void) => {
        console.log(`Listening to ${event}`);
      },
      emit: (event: string, data: any) => {
        console.log(`Emitting ${event}:`, data);
      },
      disconnect: () => {
        console.log('Disconnecting from conference room');
      },
    };
  },
};

type WebRTCAction =
  | { type: 'SET_LOADING'; payload: boolean }
  | { type: 'SET_ERROR'; payload: string | null }
  | { type: 'SET_ROOM'; payload: ConferenceRoom | null }
  | { type: 'SET_PARTICIPANTS'; payload: Participant[] }
  | { type: 'ADD_PARTICIPANT'; payload: Participant }
  | { type: 'UPDATE_PARTICIPANT'; payload: { id: string; updates: Partial<Participant> } }
  | { type: 'REMOVE_PARTICIPANT'; payload: string }
  | { type: 'ADD_STREAM'; payload: Stream }
  | { type: 'REMOVE_STREAM'; payload: string }
  | { type: 'ADD_MESSAGE'; payload: ConferenceMessage }
  | { type: 'SET_IS_MUTED'; payload: boolean }
  | { type: 'SET_IS_VIDEO_ON'; payload: boolean }
  | { type: 'SET_IS_SCREEN_SHARING'; payload: boolean };

interface WebRTCState {
  room: ConferenceRoom | null;
  participants: Participant[];
  streams: Stream[];
  messages: ConferenceMessage[];
  localStream: MediaStream | null;
  screenStream: MediaStream | null;
  isMuted: boolean;
  isVideoOn: boolean;
  isScreenSharing: boolean;
  isLoading: boolean;
  error: string | null;
}

const initialState: WebRTCState = {
  room: null,
  participants: [],
  streams: [],
  messages: [],
  localStream: null,
  screenStream: null,
  isMuted: true,
  isVideoOn: false,
  isScreenSharing: false,
  isLoading: false,
  error: null,
};

const webRTCReducer = (state: WebRTCState, action: WebRTCAction): WebRTCState => {
  switch (action.type) {
    case 'SET_LOADING':
      return { ...state, isLoading: action.payload };
    case 'SET_ERROR':
      return { ...state, error: action.payload };
    case 'SET_ROOM':
      return { ...state, room: action.payload };
    case 'SET_PARTICIPANTS':
      return { ...state, participants: action.payload };
    case 'ADD_PARTICIPANT':
      return {
        ...state,
        participants: [...state.participants, action.payload],
      };
    case 'UPDATE_PARTICIPANT':
      return {
        ...state,
        participants: state.participants.map(participant =>
          participant.id === action.payload.id
            ? { ...participant, ...action.payload.updates }
            : participant
        ),
      };
    case 'REMOVE_PARTICIPANT':
      return {
        ...state,
        participants: state.participants.filter(p => p.id !== action.payload),
      };
    case 'ADD_STREAM':
      return {
        ...state,
        streams: [...state.streams.filter(s => s.id !== action.payload.id), action.payload],
      };
    case 'REMOVE_STREAM':
      return {
        ...state,
        streams: state.streams.filter(stream => stream.id !== action.payload),
      };
    case 'ADD_MESSAGE':
      return {
        ...state,
        messages: [...state.messages, action.payload],
      };
    case 'SET_IS_MUTED':
      return { ...state, isMuted: action.payload };
    case 'SET_IS_VIDEO_ON':
      return { ...state, isVideoOn: action.payload };
    case 'SET_IS_SCREEN_SHARING':
      return { ...state, isScreenSharing: action.payload };
    default:
      return state;
  }
};

interface WebRTCContextType extends WebRTCState {
  joinRoom: (roomId: string, options?: { audio?: boolean; video?: boolean }) => Promise<void>;
  leaveRoom: () => Promise<void>;
  toggleMute: () => Promise<void>;
  toggleVideo: () => Promise<void>;
  toggleScreenShare: () => Promise<void>;
  sendMessage: (content: string) => Promise<void>;
  raiseHand: () => Promise<void>;
  startRecording: () => Promise<void>;
  stopRecording: () => Promise<void>;
  endMeeting: () => Promise<void>;
}

const WebRTCContext = createContext<WebRTCContextType | undefined>(undefined);

export const WebRTCProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, dispatch] = useReducer(webRTCReducer, initialState);
  const { user } = useAuth();
  const [socket, setSocket] = React.useState<any>(null);
  const peerConnections = React.useRef<Record<string, RTCPeerConnection>>({});
  const localStreamRef = React.useRef<MediaStream | null>(null);
  const screenStreamRef = React.useRef<MediaStream | null>(null);

  // Initialize local media stream
  const initLocalStream = useCallback(async (constraints: MediaStreamConstraints = { audio: true, video: false }) => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      localStreamRef.current = stream;
      dispatch({ type: 'SET_IS_VIDEO_ON', payload: !!constraints.video });
      return stream;
    } catch (error) {
      console.error('Error accessing media devices:', error);
      dispatch({ type: 'SET_ERROR', payload: 'Could not access camera or microphone' });
      throw error;
    }
  }, []);

  // Clean up local streams
  const cleanupLocalStreams = useCallback(() => {
    if (localStreamRef.current) {
      localStreamRef.current.getTracks().forEach(track => track.stop());
      localStreamRef.current = null;
    }
    if (screenStreamRef.current) {
      screenStreamRef.current.getTracks().forEach(track => track.stop());
      screenStreamRef.current = null;
    }
  }, []);

  // Join a conference room
  const joinRoom = useCallback(async (roomId: string, options = { audio: true, video: false }) => {
    if (!user) return;

    try {
      dispatch({ type: 'SET_LOADING', payload: true });
      dispatch({ type: 'SET_ERROR', payload: null });

      // Initialize local media
      const stream = await initLocalStream(options);
      dispatch({ type: 'SET_IS_MUTED', payload: !options.audio });

      // In a real app, this would connect to your signaling server
      const ws = mockWebSocketService.connect(roomId, user.id);
      setSocket(ws);

      // Set up event listeners
      ws.on(ConferenceEventTypes.PARTICIPANT_JOINED, (participant: Participant) => {
        dispatch({ type: 'ADD_PARTICIPANT', payload: participant });
      });

      ws.on(ConferenceEventTypes.PARTICIPANT_LEFT, (participantId: string) => {
        dispatch({ type: 'REMOVE_PARTICIPANT', payload: participantId });
      });

      ws.on(ConferenceEventTypes.MESSAGE, (message: ConferenceMessage) => {
        dispatch({ type: 'ADD_MESSAGE', payload: message });
      });

      // In a real app, you would set up WebRTC peer connections here
      // and handle ICE candidates, offers, answers, etc.

      // For demo purposes, we'll just set a mock room
      const mockRoom: ConferenceRoom = {
        id: roomId,
        courseId: 'course-123',
        title: 'Introduction to Web Development',
        startTime: new Date(),
        hostId: user.id,
        participants: [user.id],
        isActive: true,
        settings: {
          allowVideo: true,
          allowAudio: true,
          allowScreenSharing: true,
          allowChat: true,
          recordSession: false,
          waitingRoom: false,
          muteOnEntry: false,
        },
      };

      const currentUser: Participant = {
        id: user.id,
        userId: user.id,
        name: user.name || 'User',
        role: user.role || 'student',
        isHost: true, // For demo, the current user is always the host
        isMuted: !options.audio,
        isVideoOn: !!options.video,
        isScreenSharing: false,
        connectionState: 'connected',
      };

      dispatch({ type: 'SET_ROOM', payload: mockRoom });
      dispatch({ type: 'SET_PARTICIPANTS', payload: [currentUser] });
      dispatch({ type: 'ADD_STREAM', payload: { 
        id: `local-${user.id}`, 
        userId: user.id, 
        stream, 
        type: 'camera',
        isActive: true,
      }});

    } catch (error) {
      console.error('Error joining room:', error);
      dispatch({ 
        type: 'SET_ERROR', 
        payload: error instanceof Error ? error.message : 'Failed to join room' 
      });
      throw error;
    } finally {
      dispatch({ type: 'SET_LOADING', payload: false });
    }
  }, [user, initLocalStream]);

  // Leave the current room
  const leaveRoom = useCallback(async () => {
    try {
      if (socket) {
        socket.emit('leave_room');
        socket.disconnect();
      }

      // Close all peer connections
      Object.values(peerConnections.current).forEach(pc => pc.close());
      peerConnections.current = {};

      // Clean up local streams
      cleanupLocalStreams();

      // Reset state
      dispatch({ type: 'SET_ROOM', payload: null });
      dispatch({ type: 'SET_PARTICIPANTS', payload: [] });
      dispatch({ type: 'SET_STREAMS', payload: [] });
      dispatch({ type: 'SET_MESSAGES', payload: [] });
      dispatch({ type: 'SET_IS_MUTED', payload: true });
      dispatch({ type: 'SET_IS_VIDEO_ON', payload: false });
      dispatch({ type: 'SET_IS_SCREEN_SHARING', payload: false });

    } catch (error) {
      console.error('Error leaving room:', error);
      dispatch({ 
        type: 'SET_ERROR', 
        payload: error instanceof Error ? error.message : 'Failed to leave room' 
      });
      throw error;
    }
  }, [socket, cleanupLocalStreams]);

  // Toggle mute state
  const toggleMute = useCallback(async () => {
    if (!localStreamRef.current) return;

    const audioTracks = localStreamRef.current.getAudioTracks();
    const newMutedState = !state.isMuted;
    
    audioTracks.forEach(track => {
      track.enabled = !newMutedState;
    });

    dispatch({ type: 'SET_IS_MUTED', payload: newMutedState });
    
    // In a real app, notify other participants about the mute state change
    if (socket) {
      socket.emit('toggle_mute', { isMuted: newMutedState });
    }
  }, [state.isMuted, socket]);

  // Toggle video state
  const toggleVideo = useCallback(async () => {
    if (!localStreamRef.current) return;

    const videoTracks = localStreamRef.current.getVideoTracks();
    const newVideoState = !state.isVideoOn;
    
    if (videoTracks.length > 0) {
      videoTracks.forEach(track => {
        track.enabled = newVideoState;
      });
    } else if (newVideoState) {
      // If enabling video but no video tracks exist, request camera access
      try {
        const stream = await initLocalStream({ video: true, audio: state.isMuted });
        // In a real app, you would update the peer connections with the new stream
      } catch (error) {
        console.error('Error enabling video:', error);
        return;
      }
    }

    dispatch({ type: 'SET_IS_VIDEO_ON', payload: newVideoState });
    
    // In a real app, notify other participants about the video state change
    if (socket) {
      socket.emit('toggle_video', { isVideoOn: newVideoState });
    }
  }, [state.isVideoOn, state.isMuted, initLocalStream, socket]);

  // Toggle screen sharing
  const toggleScreenShare = useCallback(async () => {
    if (state.isScreenSharing) {
      // Stop screen sharing
      if (screenStreamRef.current) {
        screenStreamRef.current.getTracks().forEach(track => track.stop());
        screenStreamRef.current = null;
      }
      dispatch({ type: 'SET_IS_SCREEN_SHARING', payload: false });
      
      // In a real app, you would update the peer connections
      if (socket) {
        socket.emit('screen_share_ended');
      }
    } else {
      try {
        // Start screen sharing
        const stream = await navigator.mediaDevices.getDisplayMedia({ 
          video: true,
          audio: true,
        });
        
        screenStreamRef.current = stream;
        dispatch({ type: 'SET_IS_SCREEN_SHARING', payload: true });
        
        // In a real app, you would add this stream to peer connections
        if (socket) {
          socket.emit('screen_share_started');
        }
        
        // Handle when the user stops screen sharing using the browser's stop button
        stream.getVideoTracks()[0].onended = () => {
          dispatch({ type: 'SET_IS_SCREEN_SHARING', payload: false });
          if (socket) {
            socket.emit('screen_share_ended');
          }
        };
        
      } catch (error) {
        console.error('Error sharing screen:', error);
        dispatch({ 
          type: 'SET_ERROR', 
          payload: 'Failed to share screen. Please check your permissions.' 
        });
      }
    }
  }, [state.isScreenSharing, socket]);

  // Send a chat message
  const sendMessage = useCallback(async (content: string) => {
    if (!user || !state.room) return;

    const message: ConferenceMessage = {
      id: `msg-${Date.now()}`,
      senderId: user.id,
      senderName: user.name || 'User',
      content,
      timestamp: new Date(),
      type: 'chat',
    };

    // In a real app, send the message through the signaling server
    if (socket) {
      socket.emit(ConferenceEventTypes.MESSAGE, message);
    }
    
    // Add the message to local state
    dispatch({ type: 'ADD_MESSAGE', payload: message });
  }, [user, state.room, socket]);

  // Raise hand
  const raiseHand = useCallback(async () => {
    if (!user || !state.room) return;

    const message: ConferenceMessage = {
      id: `hand-${Date.now()}`,
      senderId: user.id,
      senderName: user.name || 'User',
      content: 'raised their hand', // This would be a system message
      timestamp: new Date(),
      type: 'hand_raised',
    };

    if (socket) {
      socket.emit(ConferenceEventTypes.RAISE_HAND, message);
    }
    
    dispatch({ type: 'ADD_MESSAGE', payload: message });
  }, [user, state.room, socket]);

  // Start recording the meeting
  const startRecording = useCallback(async () => {
    if (!state.room) return;
    
    // In a real app, this would start recording on the server
    if (socket) {
      socket.emit(ConferenceEventTypes.RECORDING_STARTED, { roomId: state.room.id });
    }
    
    // Update room state
    if (state.room) {
      dispatch({ 
        type: 'SET_ROOM', 
        payload: { 
          ...state.room, 
          settings: { ...state.room.settings, recordSession: true } 
        } 
      });
    }
  }, [state.room, socket]);

  // Stop recording the meeting
  const stopRecording = useCallback(async () => {
    if (!state.room) return;
    
    // In a real app, this would stop recording on the server
    if (socket) {
      socket.emit(ConferenceEventTypes.RECORDING_STOPPED, { roomId: state.room.id });
    }
    
    // Update room state
    if (state.room) {
      dispatch({ 
        type: 'SET_ROOM', 
        payload: { 
          ...state.room, 
          settings: { ...state.room.settings, recordSession: false } 
        } 
      });
    }
  }, [state.room, socket]);

  // End the meeting (host only)
  const endMeeting = useCallback(async () => {
    if (!state.room) return;
    
    // In a real app, this would notify all participants and clean up resources
    if (socket) {
      socket.emit(ConferenceEventTypes.ROOM_ENDED, { roomId: state.room.id });
    }
    
    // Leave the room
    await leaveRoom();
  }, [state.room, socket, leaveRoom]);

  // Clean up on unmount
  useEffect(() => {
    return () => {
      if (socket) {
        socket.disconnect();
      }
      cleanupLocalStreams();
    };
  }, [socket, cleanupLocalStreams]);

  return (
    <WebRTCContext.Provider
      value={{
        ...state,
        joinRoom,
        leaveRoom,
        toggleMute,
        toggleVideo,
        toggleScreenShare,
        sendMessage,
        raiseHand,
        startRecording,
        stopRecording,
        endMeeting,
      }}
    >
      {children}
    </WebRTCContext.Provider>
  );
};

export const useWebRTC = (): WebRTCContextType => {
  const context = useContext(WebRTCContext);
  if (context === undefined) {
    throw new Error('useWebRTC must be used within a WebRTCProvider');
  }
  return context;
};
