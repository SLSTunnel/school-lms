import React from 'react';
import { Link as RouterLink } from 'react-router-dom';
import { Box, Container, Grid, Link, Typography, Divider, useTheme } from '@mui/material';
import {
  Facebook as FacebookIcon,
  Twitter as TwitterIcon,
  Instagram as InstagramIcon,
  LinkedIn as LinkedInIcon,
  School as SchoolIcon,
} from '@mui/icons-material';

const Footer: React.FC = () => {
  const theme = useTheme();
  const currentYear = new Date().getFullYear();

  const socialLinks = [
    { icon: <FacebookIcon />, url: 'https://facebook.com' },
    { icon: <TwitterIcon />, url: 'https://twitter.com' },
    { icon: <InstagramIcon />, url: 'https://instagram.com' },
    { icon: <LinkedInIcon />, url: 'https://linkedin.com' },
  ];

  const quickLinks = [
    { text: 'Home', to: '/' },
    { text: 'About Us', to: '/about' },
    { text: 'Courses', to: '/courses' },
    { text: 'Contact', to: '/contact' },
    { text: 'FAQ', to: '/faq' },
  ];

  const legalLinks = [
    { text: 'Privacy Policy', to: '/privacy-policy' },
    { text: 'Terms of Service', to: '/terms' },
    { text: 'Cookie Policy', to: '/cookie-policy' },
  ];

  const contactInfo = [
    { text: '123 Education St, Learning City, 10101' },
    { text: 'Email: info@schoollms.com' },
    { text: 'Phone: (123) 456-7890' },
  ];

  return (
    <Box
      component="footer"
      sx={{
        backgroundColor: theme.palette.mode === 'light' ? '#f5f5f5' : theme.palette.grey[800],
        py: 6,
        mt: 'auto',
      }}
    >
      <Container maxWidth="lg">
        <Grid container spacing={4}>
          {/* Logo and Description */}
          <Grid item xs={12} md={4}>
            <Box display="flex" alignItems="center" mb={2}>
              <SchoolIcon color="primary" fontSize="large" sx={{ mr: 1 }} />
              <Typography variant="h6" component="div" fontWeight="bold">
                School LMS
              </Typography>
            </Box>
            <Typography variant="body2" color="text.secondary" paragraph>
              Empowering educators and students with modern learning tools and resources to achieve academic excellence and 
              foster a lifelong love for learning.
            </Typography>
            <Box display="flex" mt={2}>
              {socialLinks.map((social, index) => (
                <Link
                  key={index}
                  href={social.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  color="inherit"
                  sx={{
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    width: 36,
                    height: 36,
                    borderRadius: '50%',
                    backgroundColor: 'action.hover',
                    mr: 1,
                    transition: 'all 0.3s ease',
                    '&:hover': {
                      backgroundColor: 'primary.main',
                      color: 'primary.contrastText',
                      transform: 'translateY(-2px)',
                    },
                  }}
                >
                  {social.icon}
                </Link>
              ))}
            </Box>
          </Grid>

          {/* Quick Links */}
          <Grid item xs={12} sm={6} md={2}>
            <Typography variant="h6" gutterBottom fontWeight="bold">
              Quick Links
            </Typography>
            <Box component="nav">
              {quickLinks.map((link, index) => (
                <Link
                  key={index}
                  component={RouterLink}
                  to={link.to}
                  color="text.secondary"
                  variant="body2"
                  display="block"
                  mb={1}
                  sx={{
                    textDecoration: 'none',
                    '&:hover': {
                      color: 'primary.main',
                      textDecoration: 'underline',
                    },
                  }}
                >
                  {link.text}
                </Link>
              ))}
            </Box>
          </Grid>

          {/* Legal */}
          <Grid item xs={12} sm={6} md={2}>
            <Typography variant="h6" gutterBottom fontWeight="bold">
              Legal
            </Typography>
            <Box component="nav">
              {legalLinks.map((link, index) => (
                <Link
                  key={index}
                  component={RouterLink}
                  to={link.to}
                  color="text.secondary"
                  variant="body2"
                  display="block"
                  mb={1}
                  sx={{
                    textDecoration: 'none',
                    '&:hover': {
                      color: 'primary.main',
                      textDecoration: 'underline',
                    },
                  }}
                >
                  {link.text}
                </Link>
              ))}
            </Box>
          </Grid>

          {/* Contact Info */}
          <Grid item xs={12} md={4}>
            <Typography variant="h6" gutterBottom fontWeight="bold">
              Contact Us
            </Typography>
            {contactInfo.map((info, index) => (
              <Box key={index} display="flex" alignItems="flex-start" mb={1.5}>
                <Typography variant="body2" color="text.secondary">
                  {info.text}
                </Typography>
              </Box>
            ))}
            <Box mt={2}>
              <Typography variant="body2" color="text.secondary" fontWeight="medium" mb={1}>
                Newsletter Subscription
              </Typography>
              <Box component="form" display="flex" maxWidth: 300}>
                <input
                  type="email"
                  placeholder="Your email address"
                  style={{
                    flexGrow: 1,
                    padding: '8px 12px',
                    border: `1px solid ${theme.palette.divider}`,
                    borderRadius: '4px 0 0 4px',
                    outline: 'none',
                    fontSize: '0.875rem',
                  }}
                />
                <button
                  type="submit"
                  style={{
                    backgroundColor: theme.palette.primary.main,
                    color: theme.palette.primary.contrastText,
                    border: 'none',
                    padding: '8px 16px',
                    borderRadius: '0 4px 4px 0',
                    cursor: 'pointer',
                    fontWeight: 500,
                    fontSize: '0.875rem',
                    transition: 'background-color 0.3s',
                  }}
                  onMouseOver={(e) => (e.currentTarget.style.backgroundColor = theme.palette.primary.dark)}
                  onMouseOut={(e) => (e.currentTarget.style.backgroundColor = theme.palette.primary.main)}
                >
                  Subscribe
                </button>
              </Box>
            </Box>
          </Grid>
        </Grid>

        <Divider sx={{ my: 4 }} />

        <Box display="flex" flexDirection={{ xs: 'column', sm: 'row' }} justifyContent="space-between" alignItems="center">
          <Typography variant="body2" color="text.secondary">
            © {currentYear} School LMS. All rights reserved.
          </Typography>
          <Box mt={{ xs: 2, sm: 0 }}>
            <Typography variant="body2" color="text.secondary" align={{ xs: 'center', sm: 'right' }}>
              Made with ❤️ for better education
            </Typography>
          </Box>
        </Box>
      </Container>
    </Box>
  );
};

export default Footer;
