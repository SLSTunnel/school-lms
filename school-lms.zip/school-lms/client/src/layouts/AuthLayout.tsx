import React from 'react';
import { Outlet } from 'react-router-dom';
import { Box, Container, CssBaseline, useTheme, useMediaQuery } from '@mui/material';
import { styled } from '@mui/material/styles';
import SchoolIcon from '@mui/icons-material/School';

const AuthLayout: React.FC = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));

  return (
    <Box
      sx={{
        display: 'flex',
        minHeight: '100vh',
        backgroundColor: theme.palette.background.default,
      }}
    >
      <CssBaseline />
      
      {/* Left side - Branding and Welcome */}
      {!isMobile && (
        <LeftSideContainer>
          <Box sx={{ maxWidth: 500, mx: 'auto', p: 4, color: 'white' }}>
            <Box display="flex" alignItems="center" mb={4}>
              <SchoolIcon sx={{ fontSize: 40, mr: 1 }} />
              <Typography variant="h4" component="h1" fontWeight="bold">
                School LMS
              </Typography>
            </Box>
            
            <Typography variant="h3" component="h2" fontWeight="bold" mb={3}>
              Welcome Back!
            </Typography>
            
            <Typography variant="h6" mb={4} sx={{ opacity: 0.9, lineHeight: 1.6 }}>
              Empowering educators and students with modern learning tools and resources to achieve academic excellence.
            </Typography>
            
            <Box mt={6}>
              <Box display="flex" alignItems="center" mb={3}>
                <CheckCircle sx={{ mr: 2, color: theme.palette.success.light }} />
                <Typography>Interactive Learning Environment</Typography>
              </Box>
              <Box display="flex" alignItems="center" mb={3}>
                <CheckCircle sx={{ mr: 2, color: theme.palette.success.light }} />
                <Typography>Expert-Led Courses</Typography>
              </Box>
              <Box display="flex" alignItems="center">
                <CheckCircle sx={{ mr: 2, color: theme.palette.success.light }} />
                <Typography>Track Your Progress</Typography>
              </Box>
            </Box>
          </Box>
          
          <Box sx={{ position: 'absolute', bottom: 0, left: 0, right: 0, p: 2, textAlign: 'center' }}>
            <Typography variant="body2" sx={{ opacity: 0.8 }}>
              © {new Date().getFullYear()} School LMS. All rights reserved.
            </Typography>
          </Box>
        </LeftSideContainer>
      )}
      
      {/* Right side - Auth Form */}
      <RightSideContainer>
        <Container maxWidth="sm" sx={{ py: 8 }}>
          <Box sx={{ maxWidth: 480, mx: 'auto' }}>
            {isMobile && (
              <Box textAlign="center" mb={4}>
                <Box display="flex" alignItems="center" justifyContent="center" mb={2}>
                  <SchoolIcon sx={{ fontSize: 40, mr: 1, color: theme.palette.primary.main }} />
                  <Typography variant="h4" component="h1" fontWeight="bold">
                    School LMS
                  </Typography>
                </Box>
                <Typography variant="subtitle1" color="text.secondary">
                  Empowering modern education
                </Typography>
              </Box>
            )}
            
            <Box
              sx={{
                p: { xs: 3, sm: 4 },
                backgroundColor: 'background.paper',
                borderRadius: 2,
                boxShadow: theme.shadows[2],
              }}
            >
              <Outlet />
            </Box>
            
            {isMobile && (
              <Box mt={3} textAlign="center">
                <Typography variant="body2" color="text.secondary">
                  © {new Date().getFullYear()} School LMS. All rights reserved.
                </Typography>
              </Box>
            )}
          </Box>
        </Container>
      </RightSideContainer>
    </Box>
  );
};

// Styled components
const LeftSideContainer = styled(Box)(({ theme }) => ({
  flex: 1,
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'center',
  position: 'relative',
  background: `linear-gradient(135deg, ${theme.palette.primary.main} 0%, ${theme.palette.primary.dark} 100%)`,
  color: 'white',
  padding: theme.spacing(4),
  [theme.breakpoints.down('md')]: {
    display: 'none',
  },
}));

const RightSideContainer = styled(Box)(({ theme }) => ({
  flex: 1,
  display: 'flex',
  flexDirection: 'column',
  justifyContent: 'center',
  [theme.breakpoints.up('md')]: {
    maxWidth: '50%',
  },
  [theme.breakpoints.down('md')]: {
    width: '100%',
  },
}));

const CheckCircle = (props: any) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    width="24"
    height="24"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
    {...props}
  >
    <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
    <polyline points="22 4 12 14.01 9 11.01" />
  </svg>
);

const Typography = (props: any) => (
  <Box component="p" sx={{ m: 0, fontSize: '1rem', lineHeight: 1.5 }} {...props} />
);

export default AuthLayout;
