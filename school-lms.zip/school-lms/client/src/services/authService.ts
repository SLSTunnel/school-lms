import axios from 'axios';
import { ILoginCredentials, IRegisterData, IForgotPasswordData, IResetPasswordData } from '../interfaces/user.interface';

const API_URL = process.env.REACT_APP_API_URL || 'http://localhost:5000/api';

// Create axios instance
const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Add a request interceptor to add the auth token to requests
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('accessToken');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Add a response interceptor to handle token refresh
api.interceptors.response.use(
  (response) => response,
  async (error) => {
    const originalRequest = error.config;
    
    // If the error status is 401 and there is no originalRequest._retry flag,
    // it means the token has expired and we need to refresh it
    if (error.response.status === 401 && !originalRequest._retry) {
      originalRequest._retry = true;
      
      try {
        const refreshToken = localStorage.getItem('refreshToken');
        if (!refreshToken) {
          // If there's no refresh token, log the user out
          await logout();
          return Promise.reject(error);
        }
        
        // Try to refresh the token
        const response = await axios.post(`${API_URL}/auth/refresh-token`, {
          refreshToken,
        });
        
        const { accessToken, refreshToken: newRefreshToken } = response.data;
        
        // Update the tokens in localStorage
        localStorage.setItem('accessToken', accessToken);
        if (newRefreshToken) {
          localStorage.setItem('refreshToken', newRefreshToken);
        }
        
        // Update the authorization header
        originalRequest.headers.Authorization = `Bearer ${accessToken}`;
        
        // Retry the original request
        return api(originalRequest);
      } catch (error) {
        // If refresh token is invalid, log the user out
        await logout();
        return Promise.reject(error);
      }
    }
    
    return Promise.reject(error);
  }
);

// Register user
const register = async (userData: IRegisterData) => {
  const response = await api.post('/auth/register', userData);
  
  if (response.data) {
    const { user, accessToken, refreshToken } = response.data;
    localStorage.setItem('user', JSON.stringify(user));
    localStorage.setItem('accessToken', accessToken);
    localStorage.setItem('refreshToken', refreshToken);
  }
  
  return response.data;
};

// Login user
const login = async (credentials: ILoginCredentials) => {
  const response = await api.post('/auth/login', credentials);
  
  if (response.data) {
    const { user, accessToken, refreshToken } = response.data;
    localStorage.setItem('user', JSON.stringify(user));
    localStorage.setItem('accessToken', accessToken);
    localStorage.setItem('refreshToken', refreshToken);
    
    // Set remember me
    if (credentials.rememberMe) {
      localStorage.setItem('rememberMe', 'true');
    } else {
      // Clear remember me flag if not set
      localStorage.removeItem('rememberMe');
    }
  }
  
  return response.data;
};

// Forgot password
const forgotPassword = async (data: IForgotPasswordData) => {
  const response = await api.post('/auth/forgot-password', data);
  return response.data;
};

// Reset password
const resetPassword = async (data: IResetPasswordData) => {
  const response = await api.post('/auth/reset-password', data);
  return response.data;
};

// Logout user
const logout = async () => {
  try {
    // Call the logout endpoint to invalidate the refresh token
    await api.post('/auth/logout');
  } catch (error) {
    console.error('Logout error:', error);
  } finally {
    // Clear all auth data from localStorage
    localStorage.removeItem('user');
    localStorage.removeItem('accessToken');
    localStorage.removeItem('refreshToken');
    localStorage.removeItem('rememberMe');
  }
};

// Get current user
const getCurrentUser = () => {
  const user = localStorage.getItem('user');
  return user ? JSON.parse(user) : null;
};

// Check if user is authenticated
const isAuthenticated = (): boolean => {
  return !!localStorage.getItem('accessToken');
};

const authService = {
  register,
  login,
  forgotPassword,
  resetPassword,
  logout,
  getCurrentUser,
  isAuthenticated,
};

export default authService;
