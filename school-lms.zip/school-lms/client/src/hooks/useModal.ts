import { useState, useCallback } from 'react';

interface ModalState<T> {
  isOpen: boolean;
  data: T | null;
}

interface UseModalReturn<T> extends ModalState<T> {
  openModal: (data?: T) => void;
  closeModal: () => void;
  toggleModal: (data?: T) => void;
}

/**
 * A custom hook for managing modal/dialog state
 * @param initialState Initial state of the modal (default: { isOpen: false, data: null })
 * @returns [modalState, openModal, closeModal, toggleModal]
 */
function useModal<T = any>(
  initialState: Partial<ModalState<T>> = { isOpen: false, data: null }
): UseModalReturn<T> {
  const [modalState, setModalState] = useState<ModalState<T>>({
    isOpen: false,
    data: null,
    ...initialState,
  });

  const openModal = useCallback((data: T | null = null) => {
    setModalState({
      isOpen: true,
      data,
    });
  }, []);

  const closeModal = useCallback(() => {
    setModalState((prev) => ({
      ...prev,
      isOpen: false,
    }));
    
    // Clear data after animation completes (if needed)
    setTimeout(() => {
      setModalState((prev) => ({
        ...prev,
        data: null,
      }));
    }, 300);
  }, []);

  const toggleModal = useCallback((data: T | null = null) => {
    setModalState((prev) => {
      const isOpening = !prev.isOpen;
      return {
        isOpen: isOpening,
        data: isOpening ? data : prev.data,
      };
    });
  }, []);

  return {
    ...modalState,
    openModal,
    closeModal,
    toggleModal,
  };
}

export default useModal;
