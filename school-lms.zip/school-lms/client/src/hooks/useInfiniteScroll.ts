import { useState, useEffect, useRef, useCallback } from 'react';

interface UseInfiniteScrollOptions {
  /**
   * Whether the infinite scroll is enabled
   * @default true
   */
  enabled?: boolean;
  /**
   * The distance in pixels from the bottom of the scroll container
   * when the onLoadMore callback should be triggered
   * @default 100
   */
  threshold?: number;
  /**
   * The debounce time in milliseconds for the scroll event
   * @default 200
   */
  debounce?: number;
  /**
   * The scroll container element (defaults to window)
   */
  scrollContainer?: HTMLElement | null;
}

/**
 * A custom hook that triggers a callback when the user scrolls near the bottom of a container
 * @param onLoadMore Callback function to load more items
 * @param options Configuration options
 * @returns Object containing ref to attach to the scroll container and loading state
 */
function useInfiniteScroll<T extends HTMLElement>(
  onLoadMore: () => Promise<void> | void,
  options: UseInfiniteScrollOptions = {}
) {
  const {
    enabled = true,
    threshold = 100,
    debounce = 200,
    scrollContainer: externalScrollContainer = null,
  } = options;

  const [isLoading, setIsLoading] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const containerRef = useRef<T>(null);
  const timeoutRef = useRef<number>();
  const isMounted = useRef(true);

  // Use external scroll container if provided, otherwise use the ref
  const scrollContainer = externalScrollContainer || (typeof window !== 'undefined' ? window : null);
  const scrollElement = scrollContainer === window ? document.documentElement : scrollContainer;

  const checkScroll = useCallback(async () => {
    if (!enabled || !hasMore || isLoading || !isMounted.current) return;

    const container = scrollElement || containerRef.current;
    if (!container) return;

    // Calculate scroll position
    const { scrollTop, scrollHeight, clientHeight } = container === document.documentElement
      ? {
          scrollTop: window.scrollY || document.documentElement.scrollTop,
          scrollHeight: document.documentElement.scrollHeight,
          clientHeight: window.innerHeight,
        }
      : {
          scrollTop: (container as HTMLElement).scrollTop,
          scrollHeight: (container as HTMLElement).scrollHeight,
          clientHeight: (container as HTMLElement).clientHeight,
        };

    // Check if we're near the bottom
    const isNearBottom = scrollHeight - (scrollTop + clientHeight) < threshold;

    if (isNearBottom) {
      try {
        setIsLoading(true);
        await onLoadMore();
      } catch (error) {
        console.error('Error loading more items:', error);
      } finally {
        if (isMounted.current) {
          setIsLoading(false);
        }
      }
    }
  }, [enabled, hasMore, isLoading, onLoadMore, scrollElement, threshold]);

  // Debounced scroll handler
  const handleScroll = useCallback(() => {
    if (timeoutRef.current) {
      window.clearTimeout(timeoutRef.current);
    }

    timeoutRef.current = window.setTimeout(() => {
      checkScroll();
    }, debounce);
  }, [checkScroll, debounce]);

  // Set up scroll event listener
  useEffect(() => {
    isMounted.current = true;
    const container = scrollElement || containerRef.current;

    if (!container) return;

    if (enabled) {
      container.addEventListener('scroll', handleScroll);
      // Initial check in case the container is already scrolled to the bottom
      handleScroll();
    }

    return () => {
      isMounted.current = false;
      container.removeEventListener('scroll', handleScroll);
      if (timeoutRef.current) {
        window.clearTimeout(timeoutRef.current);
      }
    };
  }, [enabled, handleScroll, scrollElement]);

  // Reset loading state when enabled changes
  useEffect(() => {
    if (!enabled) {
      setIsLoading(false);
    }
  }, [enabled]);

  return {
    /**
     * Ref to attach to the scrollable container
     * Only needed if not using an external scroll container
     */
    ref: containerRef,
    /**
     * Whether more items are currently being loaded
     */
    isLoading,
    /**
     * Set whether there are more items to load
     */
    setHasMore,
    /**
     * Manually trigger loading more items
     */
    loadMore: useCallback(async () => {
      if (!isLoading && hasMore) {
        await checkScroll();
      }
    }, [checkScroll, hasMore, isLoading]),
  };
}

export default useInfiniteScroll;
