import { useState, useEffect, useCallback, useRef } from 'react';

type WebSocketMessage = string | ArrayBuffer | Blob | ArrayBufferView;

type WebSocketCallbacks = {
  onOpen?: (event: Event) => void;
  onClose?: (event: CloseEvent) => void;
  onError?: (event: Event) => void;
  onMessage?: (event: MessageEvent) => void;
  onReconnect?: () => void;
};

interface UseWebSocketOptions extends WebSocketCallbacks {
  /**
   * Whether the WebSocket connection should be established immediately
   * @default true
   */
  autoConnect?: boolean;
  /**
   * Whether to attempt to reconnect if the connection is lost
   * @default true
   */
  shouldReconnect?: boolean;
  /**
   * Delay in milliseconds between reconnection attempts
   * @default 3000
   */
  reconnectInterval?: number;
  /**
   * Maximum number of reconnection attempts
   * @default 5
   */
  reconnectAttempts?: number;
  /**
   * Custom WebSocket implementation (for testing or custom protocols)
   */
  webSocketImpl?: typeof WebSocket;
}

interface UseWebSocketReturn {
  /**
   * The current WebSocket instance
   */
  webSocket: WebSocket | null;
  /**
   * Whether the WebSocket connection is currently open
   */
  isConnected: boolean;
  /**
   * The last message received from the WebSocket
   */
  lastMessage: MessageEvent | null;
  /**
   * The last error that occurred
   */
  error: Event | null;
  /**
   * Send a message through the WebSocket
   */
  sendMessage: (message: WebSocketMessage) => void;
  /**
   * Manually connect the WebSocket
   */
  connect: () => void;
  /**
   * Manually disconnect the WebSocket
   */
  disconnect: () => void;
  /**
   * Reconnect the WebSocket
   */
  reconnect: () => void;
}

/**
 * A custom hook for managing WebSocket connections
 * @param url The WebSocket server URL
 * @param options Configuration options and callbacks
 * @returns WebSocket connection state and methods
 */
function useWebSocket(
  url: string,
  {
    autoConnect = true,
    shouldReconnect = true,
    reconnectInterval = 3000,
    reconnectAttempts = 5,
    webSocketImpl,
    onOpen,
    onClose,
    onError,
    onMessage,
    onReconnect,
  }: UseWebSocketOptions = {}
): UseWebSocketReturn {
  const [webSocket, setWebSocket] = useState<WebSocket | null>(null);
  const [isConnected, setIsConnected] = useState(false);
  const [lastMessage, setLastMessage] = useState<MessageEvent | null>(null);
  const [error, setError] = useState<Event | null>(null);
  const reconnectCountRef = useRef(0);
  const reconnectTimeoutRef = useRef<number>();
  const isMounted = useRef(true);
  const optionsRef = useRef({
    shouldReconnect,
    reconnectInterval,
    reconnectAttempts,
  });

  // Update options ref when they change
  useEffect(() => {
    optionsRef.current = {
      shouldReconnect,
      reconnectInterval,
      reconnectAttempts,
    };
  }, [shouldReconnect, reconnectInterval, reconnectAttempts]);

  // Handle WebSocket connection
  const connect = useCallback(() => {
    if (isConnected) return;

    try {
      const ws = webSocketImpl ? new webSocketImpl(url) : new WebSocket(url);
      setWebSocket(ws);
      setError(null);

      ws.onopen = (event) => {
        if (!isMounted.current) return;
        setIsConnected(true);
        reconnectCountRef.current = 0;
        onOpen?.(event);
      };

      ws.onmessage = (event) => {
        if (!isMounted.current) return;
        setLastMessage(event);
        onMessage?.(event);
      };

      ws.onerror = (event) => {
        if (!isMounted.current) return;
        setError(event);
        onError?.(event);
      };

      ws.onclose = (event) => {
        if (!isMounted.current) return;
        setIsConnected(false);
        onClose?.(event);

        // Attempt to reconnect if needed
        const { shouldReconnect, reconnectInterval, reconnectAttempts } = optionsRef.current;
        if (shouldReconnect && reconnectCountRef.current < reconnectAttempts) {
          reconnectCountRef.current += 1;
          reconnectTimeoutRef.current = window.setTimeout(() => {
            onReconnect?.();
            connect();
          }, reconnectInterval);
        }
      };
    } catch (err) {
      const errorEvent = new Event('error');
      setError(errorEvent);
      onError?.(errorEvent);
    }
  }, [url, onOpen, onMessage, onError, onClose, onReconnect, webSocketImpl, isConnected]);

  // Disconnect WebSocket
  const disconnect = useCallback(() => {
    if (webSocket) {
      webSocket.close();
      setWebSocket(null);
      setIsConnected(false);
      
      if (reconnectTimeoutRef.current) {
        window.clearTimeout(reconnectTimeoutRef.current);
        reconnectTimeoutRef.current = undefined;
      }
    }
  }, [webSocket]);

  // Reconnect WebSocket
  const reconnect = useCallback(() => {
    disconnect();
    reconnectCountRef.current = 0;
    connect();
  }, [connect, disconnect]);

  // Send message through WebSocket
  const sendMessage = useCallback(
    (message: WebSocketMessage) => {
      if (webSocket && isConnected) {
        webSocket.send(message);
      } else {
        console.warn('WebSocket is not connected. Message not sent:', message);
      }
    },
    [webSocket, isConnected]
  );

  // Auto-connect on mount if enabled
  useEffect(() => {
    isMounted.current = true;

    if (autoConnect) {
      connect();
    }

    // Cleanup on unmount
    return () => {
      isMounted.current = false;
      disconnect();
    };
  }, [autoConnect, connect, disconnect]);

  return {
    webSocket,
    isConnected,
    lastMessage,
    error,
    sendMessage,
    connect,
    disconnect,
    reconnect,
  };
}

export default useWebSocket;
