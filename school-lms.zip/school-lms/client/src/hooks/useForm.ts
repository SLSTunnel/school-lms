import { useState, useCallback, ChangeEvent, FormEvent } from 'react';

type ValidationRule<T> = {
  validator: (value: any, values?: T) => boolean;
  message: string;
};

type ValidationRules<T> = {
  [K in keyof T]?: ValidationRule<T>[];
};

interface UseFormProps<T> {
  initialValues: T;
  onSubmit: (values: T) => void | Promise<void>;
  validationRules?: ValidationRules<T>;
  validateOnChange?: boolean;
  validateOnBlur?: boolean;
}

interface FormErrors<T> {
  [key: string]: string[];
}

interface UseFormReturn<T> {
  values: T;
  errors: FormErrors<T>;
  isSubmitting: boolean;
  handleChange: (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => void;
  handleBlur: (e: React.FocusEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => void;
  handleSubmit: (e: FormEvent<HTMLFormElement>) => void;
  setFieldValue: <K extends keyof T>(field: K, value: T[K]) => void;
  setValues: React.Dispatch<React.SetStateAction<T>>;
  resetForm: () => void;
  validate: () => boolean;
}

function useForm<T extends Record<string, any>>({
  initialValues,
  onSubmit,
  validationRules = {},
  validateOnChange = false,
  validateOnBlur = true,
}: UseFormProps<T>): UseFormReturn<T> {
  const [values, setValues] = useState<T>(initialValues);
  const [errors, setErrors] = useState<FormErrors<T>>({});
  const [touched, setTouched] = useState<Record<string, boolean>>({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const validateField = useCallback(
    (field: keyof T, value: any): string[] => {
      const fieldRules = validationRules[field] || [];
      const fieldErrors: string[] = [];

      for (const rule of fieldRules) {
        if (!rule.validator(value, values)) {
          fieldErrors.push(rule.message);
        }
      }

      return fieldErrors;
    },
    [validationRules, values]
  );

  const validateForm = useCallback((): boolean => {
    const newErrors: FormErrors<T> = {};
    let isValid = true;

    (Object.keys(validationRules) as Array<keyof T>).forEach((field) => {
      const fieldErrors = validateField(field, values[field]);
      if (fieldErrors.length > 0) {
        newErrors[field as string] = fieldErrors;
        isValid = false;
      }
    });

    setErrors(newErrors);
    return isValid;
  }, [validateField, validationRules, values]);

  const handleChange = useCallback(
    (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
      const { name, value, type } = e.target;
      
      // Handle different input types
      let finalValue: any = value;
      if (type === 'number') {
        finalValue = parseFloat(value) || 0;
      } else if (type === 'checkbox') {
        const target = e.target as HTMLInputElement;
        finalValue = target.checked;
      } else if (type === 'file') {
        const target = e.target as HTMLInputElement;
        finalValue = target.files?.[0] || null;
      }

      setValues((prev) => ({
        ...prev,
        [name]: finalValue,
      }));

      // Validate on change if enabled
      if (validateOnChange) {
        const fieldErrors = validateField(name as keyof T, finalValue);
        setErrors((prev) => ({
          ...prev,
          [name]: fieldErrors.length > 0 ? fieldErrors : undefined,
        }));
      }
    },
    [validateField, validateOnChange]
  );

  const handleBlur = useCallback(
    (e: React.FocusEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
      const { name } = e.target;
      setTouched((prev) => ({
        ...prev,
        [name]: true,
      }));

      // Validate on blur if enabled
      if (validateOnBlur) {
        const fieldErrors = validateField(name as keyof T, values[name as keyof T]);
        setErrors((prev) => ({
          ...prev,
          [name]: fieldErrors.length > 0 ? fieldErrors : undefined,
        }));
      }
    },
    [validateField, validateOnBlur, values]
  );

  const handleSubmit = useCallback(
    async (e: FormEvent<HTMLFormElement>) => {
      e.preventDefault();
      
      // Validate all fields on submit
      const isValid = validateForm();
      
      if (isValid) {
        setIsSubmitting(true);
        try {
          await onSubmit(values);
        } finally {
          setIsSubmitting(false);
        }
      }
    },
    [onSubmit, validateForm, values]
  );

  const setFieldValue = useCallback(<K extends keyof T>(field: K, value: T[K]) => {
    setValues((prev) => ({
      ...prev,
      [field]: value,
    }));
  }, []);

  const resetForm = useCallback(() => {
    setValues(initialValues);
    setErrors({});
    setTouched({});
  }, [initialValues]);

  return {
    values,
    errors,
    isSubmitting,
    handleChange,
    handleBlur,
    handleSubmit,
    setFieldValue,
    setValues,
    resetForm,
    validate: validateForm,
  };
}

export default useForm;
