import { useState, useCallback, useRef, useEffect } from 'react';

type NotificationType = 'info' | 'success' | 'warning' | 'error';

interface Notification {
  id: string;
  message: string;
  type: NotificationType;
  duration?: number;
  createdAt: number;
}

interface UseNotificationOptions {
  /**
   * Default duration in milliseconds before the notification auto-dismisses
   * Set to 0 to disable auto-dismiss
   * @default 5000
   */
  defaultDuration?: number;
  /**
   * Maximum number of notifications to show at once
   * @default 5
   */
  maxNotifications?: number;
  /**
   * Whether to allow duplicate notifications
   * @default false
   */
  allowDuplicates?: boolean;
  /**
   * Callback when a notification is added
   */
  onAdd?: (notification: Notification) => void;
  /**
   * Callback when a notification is removed
   */
  onRemove?: (notification: Notification) => void;
}

interface UseNotificationReturn {
  /**
   * Current notifications
   */
  notifications: Notification[];
  /**
   * Add a new notification
   */
  notify: (message: string, options?: Omit<Notification, 'id' | 'message' | 'createdAt'>) => string;
  /**
   * Remove a notification by ID
   */
  removeNotification: (id: string) => void;
  /**
   * Clear all notifications
   */
  clearAll: () => void;
  /**
   * Add an info notification
   */
  info: (message: string, duration?: number) => string;
  /**
   * Add a success notification
   */
  success: (message: string, duration?: number) => string;
  /**
   * Add a warning notification
   */
  warning: (message: string, duration?: number) => string;
  /**
   * Add an error notification
   */
  error: (message: string, duration?: number) => string;
}

/**
 * A custom hook for managing notifications
 * @param options Configuration options
 * @returns Notification state and methods
 */
function useNotification(
  options: UseNotificationOptions = {}
): UseNotificationReturn {
  const {
    defaultDuration = 5000,
    maxNotifications = 5,
    allowDuplicates = false,
    onAdd,
    onRemove,
  } = options;

  const [notifications, setNotifications] = useState<Notification[]>([]);
  const timeouts = useRef<Record<string, number>>({});

  // Clean up timeouts on unmount
  useEffect(() => {
    return () => {
      // Clear all timeouts when the component unmounts
      Object.values(timeouts.current).forEach(clearTimeout);
    };
  }, []);

  // Remove a notification by ID
  const removeNotification = useCallback(
    (id: string) => {
      setNotifications((prev) => {
        const notification = prev.find((n) => n.id === id);
        if (notification) {
          onRemove?.(notification);
          // Clear the timeout if it exists
          if (timeouts.current[id]) {
            clearTimeout(timeouts.current[id]);
            delete timeouts.current[id];
          }
          return prev.filter((n) => n.id !== id);
        }
        return prev;
      });
    },
    [onRemove]
  );

  // Add a new notification
  const notify = useCallback(
    (message: string, options: Omit<Notification, 'id' | 'message' | 'createdAt'> = {}) => {
      const id = Math.random().toString(36).substr(2, 9);
      const duration = options.duration ?? defaultDuration;
      const type = options.type ?? 'info';
      const createdAt = Date.now();

      // Check for duplicate messages if not allowed
      if (!allowDuplicates) {
        const isDuplicate = notifications.some(
          (n) => n.message === message && n.type === type
        );
        if (isDuplicate) {
          return ''; // Return empty string for duplicate
        }
      }

      const newNotification: Notification = {
        id,
        message,
        type,
        duration,
        createdAt,
      };

      setNotifications((prev) => {
        // Limit the number of notifications
        const updated = [newNotification, ...prev].slice(0, maxNotifications);
        return updated;
      });

      // Auto-remove the notification after the specified duration
      if (duration > 0) {
        timeouts.current[id] = window.setTimeout(() => {
          removeNotification(id);
        }, duration);
      }

      onAdd?.(newNotification);
      return id;
    },
    [defaultDuration, maxNotifications, allowDuplicates, notifications, onAdd, removeNotification]
  );

  // Clear all notifications
  const clearAll = useCallback(() => {
    // Clear all timeouts
    Object.values(timeouts.current).forEach(clearTimeout);
    timeouts.current = {};
    
    // Notify about each removed notification
    notifications.forEach((notification) => {
      onRemove?.(notification);
    });
    
    setNotifications([]);
  }, [notifications, onRemove]);

  // Helper methods for different notification types
  const info = useCallback(
    (message: string, duration?: number) => {
      return notify(message, { type: 'info', duration });
    },
    [notify]
  );

  const success = useCallback(
    (message: string, duration?: number) => {
      return notify(message, { type: 'success', duration });
    },
    [notify]
  );

  const warning = useCallback(
    (message: string, duration?: number) => {
      return notify(message, { type: 'warning', duration });
    },
    [notify]
  );

  const error = useCallback(
    (message: string, duration?: number) => {
      return notify(message, { type: 'error', duration });
    },
    [notify]
  );

  return {
    notifications,
    notify,
    removeNotification,
    clearAll,
    info,
    success,
    warning,
    error,
  };
}

export default useNotification;
