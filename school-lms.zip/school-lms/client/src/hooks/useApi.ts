import { useState, useCallback } from 'react';
import { AxiosRequestConfig, AxiosResponse, AxiosError } from 'axios';
import api from '../services/api';

interface ApiState<T> {
  data: T | null;
  loading: boolean;
  error: string | null;
}

interface UseApiReturn<T> extends ApiState<T> {
  fetch: (config: AxiosRequestConfig) => Promise<AxiosResponse<T> | undefined>;
  clearError: () => void;
  setData: React.Dispatch<React.SetStateAction<T | null>>;
}

function useApi<T = any>(): UseApiReturn<T> {
  const [state, setState] = useState<ApiState<T>>({
    data: null,
    loading: false,
    error: null,
  });

  const fetch = useCallback(async (config: AxiosRequestConfig) => {
    setState(prev => ({ ...prev, loading: true, error: null }));
    
    try {
      const response = await api.request<T>(config);
      setState(prev => ({
        ...prev,
        data: response.data,
        loading: false,
      }));
      return response;
    } catch (error) {
      const axiosError = error as AxiosError;
      const errorMessage = 
        axiosError.response?.data?.message || 
        axiosError.message || 
        'An error occurred';
      
      setState(prev => ({
        ...prev,
        error: errorMessage,
        loading: false,
      }));
      
      throw error;
    }
  }, []);

  const clearError = useCallback(() => {
    setState(prev => ({ ...prev, error: null }));
  }, []);

  const setData = useCallback((data: React.SetStateAction<T | null>) => {
    setState(prev => ({
      ...prev,
      data: typeof data === 'function' ? (data as (prevState: T | null) => T | null)(prev.data) : data,
    }));
  }, []);

  return {
    ...state,
    fetch,
    clearError,
    setData,
  };
}

export default useApi;
