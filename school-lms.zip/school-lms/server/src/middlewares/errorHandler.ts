import { Request, Response, NextFunction } from 'express';
import { Error as MongooseError } from 'mongoose';
import { JsonWebTokenError, TokenExpiredError } from 'jsonwebtoken';
import { CustomError } from '../utils/error';
import logger from '../utils/logger';

interface ErrorResponse {
  status: string;
  message: string;
  error?: any;
  stack?: string;
}

const errorHandler = (
  err: any,
  req: Request,
  res: Response,
  next: NextFunction
) => {
  let error = { ...err };
  error.message = err.message;
  error.statusCode = err.statusCode || 500;
  error.status = error.status || 'error';

  // Log the error for debugging
  logger.error(`Error: ${err.message}`, {
    url: req.originalUrl,
    method: req.method,
    body: req.body,
    params: req.params,
    query: req.query,
    stack: process.env.NODE_ENV === 'development' ? err.stack : {}
  });

  // Handle specific error types
  if (err.name === 'CastError') {
    // Handle invalid MongoDB ObjectId
    const message = `Resource not found with id of ${err.value}`;
    error = new CustomError(message, 404);
  }

  // Handle duplicate field value
  if (err.code === 11000) {
    const field = Object.keys(err.keyValue)[0];
    const message = `Duplicate field value: ${field}. Please use another value.`;
    error = new CustomError(message, 400);
  }

  // Handle validation errors
  if (err instanceof MongooseError.ValidationError) {
    const messages = Object.values(err.errors).map((val: any) => val.message);
    error = new CustomError(`Validation failed: ${messages.join('. ')}`, 400);
  }

  // Handle JWT errors
  if (err instanceof JsonWebTokenError) {
    const message = 'Invalid token. Please log in again.';
    error = new CustomError(message, 401);
  }

  if (err instanceof TokenExpiredError) {
    const message = 'Your token has expired. Please log in again.';
    error = new CustomError(message, 401);
  }

  // Send error response
  const errorResponse: ErrorResponse = {
    status: error.status,
    message: error.message || 'Internal Server Error',
  };

  // Include stack trace in development
  if (process.env.NODE_ENV === 'development') {
    errorResponse.stack = err.stack;
    errorResponse.error = err;
  }

  // Log the error to the console in development
  if (process.env.NODE_ENV === 'development') {
    console.error('Error Stack:', err.stack);
  }

  res.status(error.statusCode || 500).json(errorResponse);
};

export default errorHandler;
