import express, { Application, Request, Response, NextFunction } from 'express';
import mongoose from 'mongoose';
import cors from 'cors';
import helmet from 'helmet';
import morgan from 'morgan';
import compression from 'compression';
import cookieParser from 'cookie-parser';
import mongoSanitize from 'express-mongo-sanitize';
import rateLimit from 'express-rate-limit';
import xss from 'xss-clean';
import path from 'path';
import http from 'http';
import { Server } from 'socket.io';
import { config } from 'dotenv';
import { createClient } from 'redis';
import { createAdapter } from '@socket.io/redis-adapter';
import errorHandler from './middlewares/errorHandler';
import logger from './utils/logger';
import apiRoutes from './routes';

// Load environment variables
config({ path: path.join(__dirname, '../../.env') });

class App {
  public app: Application;
  public server: http.Server;
  public io: Server;
  private redisClient: ReturnType<typeof createClient>;

  constructor() {
    this.app = express();
    this.server = http.createServer(this.app);
    this.initializeMiddlewares();
    this.initializeRoutes();
    this.initializeErrorHandling();
    this.initializeSocket();
  }

  private initializeMiddlewares(): void {
    // Security headers
    this.app.use(helmet());
    
    // CORS
    this.app.use(cors({
      origin: process.env.CLIENT_URL || 'http://localhost:3000',
      credentials: true,
    }));

    // Rate limiting
    const limiter = rateLimit({
      windowMs: 15 * 60 * 1000, // 15 minutes
      max: 100, // limit each IP to 100 requests per windowMs
      message: 'Too many requests from this IP, please try again later.'
    });
    this.app.use('/api', limiter);

    // Body parser
    this.app.use(express.json({ limit: '10kb' }));
    this.app.use(express.urlencoded({ extended: true, limit: '10kb' }));
    
    // Cookie parser
    this.app.use(cookieParser());
    
    // Data sanitization against NoSQL query injection
    this.app.use(mongoSanitize());
    
    // Data sanitization against XSS
    this.app.use(xss());
    
    // Compression
    this.app.use(compression());
    
    // Logging
    if (process.env.NODE_ENV === 'development') {
      this.app.use(morgan('dev'));
    }
    
    // Static files
    this.app.use('/public', express.static(path.join(__dirname, '../public')));
  }

  private initializeRoutes(): void {
    // Health check endpoint
    this.app.get('/health', (req: Request, res: Response) => {
      res.status(200).json({
        status: 'success',
        message: 'Server is running',
        timestamp: new Date().toISOString()
      });
    });

    // API routes
    this.app.use('/api/v1', apiRoutes);

    // 404 handler
    this.app.all('*', (req: Request, res: Response, next: NextFunction) => {
      const err = new Error(`Can't find ${req.originalUrl} on this server!`) as any;
      err.status = 'fail';
      err.statusCode = 404;
      next(err);
    });
  }

  private initializeErrorHandling(): void {
    this.app.use(errorHandler);
  }

  private async initializeSocket(): Promise<void> {
    try {
      // Initialize Redis client for Socket.IO adapter
      this.redisClient = createClient({
        url: process.env.REDIS_URL || 'redis://localhost:6379'
      });
      
      await this.redisClient.connect();
      
      const subClient = this.redisClient.duplicate();
      await subClient.connect();
      
      // Initialize Socket.IO with Redis adapter
      this.io = new Server(this.server, {
        cors: {
          origin: process.env.CLIENT_URL || 'http://localhost:3000',
          methods: ['GET', 'POST'],
          credentials: true
        },
        adapter: createAdapter(this.redisClient, subClient)
      });
      
      // Socket.IO connection handler
      this.io.on('connection', (socket) => {
        logger.info(`New client connected: ${socket.id}`);
        
        // Join room for private messaging
        socket.on('joinRoom', (roomId: string) => {
          socket.join(roomId);
          logger.info(`Socket ${socket.id} joined room ${roomId}`);
        });
        
        // Handle disconnection
        socket.on('disconnect', () => {
          logger.info(`Client disconnected: ${socket.id}`);
        });
      });
      
      logger.info('Socket.IO initialized with Redis adapter');
    } catch (error) {
      logger.error('Error initializing Socket.IO:', error);
    }
  }

  public async connectToDatabase(): Promise<void> {
    try {
      const DB_URI = process.env.MONGODB_URI || 'mongodb://localhost:27017/school_lms';
      await mongoose.connect(DB_URI);
      logger.info('Database connected successfully');
    } catch (error) {
      logger.error('Database connection error:', error);
      process.exit(1);
    }
  }

  public start(): void {
    const PORT = process.env.PORT || 5000;
    
    this.server.listen(PORT, () => {
      logger.info(`Server running in ${process.env.NODE_ENV} mode on port ${PORT}`);
    });
    
    // Handle unhandled promise rejections
    process.on('unhandledRejection', (err: Error) => {
      logger.error('UNHANDLED REJECTION! 💥 Shutting down...');
      logger.error(err.name, err);
      this.server.close(() => {
        process.exit(1);
      });
    });
    
    // Handle uncaught exceptions
    process.on('uncaughtException', (err: Error) => {
      logger.error('UNCAUGHT EXCEPTION! 💥 Shutting down...');
      logger.error(err.name, err);
      process.exit(1);
    });
  }
}

// Start the application
const app = new App();

// Connect to database and start the server
const startServer = async () => {
  try {
    await app.connectToDatabase();
    app.start();
  } catch (error) {
    logger.error('Failed to start server:', error);
    process.exit(1);
  }
};

startServer();

export default app;
