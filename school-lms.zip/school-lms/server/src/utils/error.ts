/**
 * Custom Error class for handling application-specific errors
 */
class CustomError extends Error {
  statusCode: number;
  status: string;
  isOperational: boolean;

  constructor(message: string, statusCode: number) {
    super(message);

    this.statusCode = statusCode;
    this.status = `${statusCode}`.startsWith('4') ? 'fail' : 'error';
    this.isOperational = true;

    // Capture stack trace, excluding constructor call from it
    Error.captureStackTrace(this, this.constructor);
  }

  /**
   * Create a new CustomError instance from a standard Error
   */
  static fromError(error: Error, statusCode: number = 500): CustomError {
    const customError = new CustomError(error.message, statusCode);
    customError.stack = error.stack;
    return customError;
  }

  /**
   * Create a validation error (400)
   */
  static validationError(message: string = 'Validation failed'): CustomError {
    return new CustomError(message, 400);
  }

  /**
   * Create an unauthorized error (401)
   */
  static unauthorized(message: string = 'Unauthorized'): CustomError {
    return new CustomError(message, 401);
  }

  /**
   * Create a forbidden error (403)
   */
  static forbidden(message: string = 'Forbidden'): CustomError {
    return new CustomError(message, 403);
  }

  /**
   * Create a not found error (404)
   */
  static notFound(message: string = 'Resource not found'): CustomError {
    return new CustomError(message, 404);
  }

  /**
   * Create a conflict error (409)
   */
  static conflict(message: string = 'Conflict occurred'): CustomError {
    return new CustomError(message, 409);
  }

  /**
   * Create an internal server error (500)
   */
  static internal(message: string = 'Internal server error'): CustomError {
    return new CustomError(message, 500);
  }
}

export default CustomError;
