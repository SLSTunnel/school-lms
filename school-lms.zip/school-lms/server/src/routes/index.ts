import { Router } from 'express';
import authRoutes from './auth.routes';
import userRoutes from './user.routes';
import courseRoutes from './course.routes';
import adminRoutes from './admin.routes';
import teacherRoutes from './teacher.routes';
import studentRoutes from './student.routes';
import { authenticate, authorizeRoles } from '../middlewares/auth';
import { UserRole } from '../interfaces/user.interface';

const router = Router();

// Health check route
router.get('/health', (req, res) => {
  res.status(200).json({
    status: 'success',
    message: 'Server is up and running!',
    timestamp: new Date().toISOString(),
    environment: process.env.NODE_ENV || 'development',
  });
});

// Public routes
router.use('/auth', authRoutes);

// Protected routes
router.use(authenticate);

// User routes (authenticated users)
router.use('/users', userRoutes);

// Course routes
router.use('/courses', courseRoutes);

// Teacher routes
router.use('/teacher', authorizeRoles([UserRole.TEACHER, UserRole.ADMIN]), teacherRoutes);

// Student routes
router.use('/student', authorizeRoles([UserRole.STUDENT, UserRole.ADMIN]), studentRoutes);

// Admin routes (only for admins)
router.use('/admin', authorizeRoles([UserRole.ADMIN]), adminRoutes);

export default router;
