#!/bin/bash

# Deployment script for School LMS
# Usage: ./deploy.sh [setup|deploy|update|backup|restore]

set -e

# Colors for output
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Load environment variables
if [ -f .env ]; then
    export $(grep -v '^#' .env | xargs)
else
    echo -e "${RED}Error: .env file not found. Please create one from .env.example${NC}"
    exit 1
fi

# Check if docker and docker-compose are installed
check_dependencies() {
    if ! command -v docker &> /dev/null; then
        echo -e "${RED}Docker is not installed. Please install Docker first.${NC}"
        exit 1
    fi

    if ! command -v docker-compose &> /dev/null; then
        echo -e "${RED}Docker Compose is not installed. Please install Docker Compose.${NC}"
        exit 1
    fi
}

# Initial server setup
setup_server() {
    echo -e "${YELLOW}Starting initial server setup...${NC}"
    
    # Update system packages
    echo -e "${GREEN}Updating system packages...${NC}"
    sudo apt-get update && sudo apt-get upgrade -y
    
    # Install required packages
    echo -e "${GREEN}Installing required packages...${NC}"
    sudo apt-get install -y \
        apt-transport-https \
        ca-certificates \
        curl \
        gnupg \
        lsb-release \
        git \
        nginx \
        certbot \
        python3-certbot-nginx
    
    # Install Docker
    if ! command -v docker &> /dev/null; then
        echo -e "${GREEN}Installing Docker...${NC}"
        curl -fsSL https://get.docker.com -o get-docker.sh
        sudo sh get-docker.sh
        rm get-docker.sh
        
        # Add current user to docker group
        sudo usermod -aG docker $USER
        newgrp docker
    fi
    
    # Install Docker Compose
    if ! command -v docker-compose &> /dev/null; then
        echo -e "${GREEN}Installing Docker Compose...${NC}"
        sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
        sudo chmod +x /usr/local/bin/docker-compose
    fi
    
    echo -e "${GREEN}Server setup completed successfully!${NC}"
    echo -e "${YELLOW}Please log out and log back in for the group changes to take effect.${NC}"
}

# Deploy the application
deploy_app() {
    echo -e "${YELLOW}Starting deployment...${NC}"
    
    # Create necessary directories
    echo -e "${GREEN}Creating directories...${NC}"
    mkdir -p ./nginx/{conf.d,letsencrypt,var/{lib/letsencrypt,log/letsencrypt}}
    
    # Build and start containers
    echo -e "${GREEN}Building and starting containers...${NC}"
    docker-compose up -d --build
    
    # Set up SSL certificates (if domain is configured)
    if [ -n "$DOMAIN" ]; then
        echo -e "${GREEN}Setting up SSL certificates...${NC}"
        sudo certbot --nginx -d $DOMAIN --non-interactive --agree-tos --email $SMTP_EMAIL
    fi
    
    echo -e "${GREEN}Deployment completed successfully!${NC}"
}

# Update the application
update_app() {
    echo -e "${YELLOW}Updating application...${NC}"
    
    # Pull latest changes
    echo -e "${GREEN}Pulling latest changes...${NC}"
    git pull origin main
    
    # Rebuild and restart containers
    echo -e "${GREEN}Rebuilding and restarting containers...${NC}"
    docker-compose up -d --build
    
    echo -e "${GREEN}Application updated successfully!${NC}"
}

# Backup application data
backup_data() {
    echo -e "${YELLOW}Creating backup...${NC}"
    
    TIMESTAMP=$(date +%Y%m%d_%H%M%S)
    BACKUP_DIR="backups/backup_$TIMESTAMP"
    
    mkdir -p "$BACKUP_DIR"
    
    # Backup MongoDB
    echo -e "${GREEN}Backing up MongoDB...${NC}"
    docker exec school-lms-mongodb sh -c 'mongodump --archive' > "$BACKUP_DIR/mongodb_backup_$TIMESTAMP.archive"
    
    # Backup Redis
    echo -e "${GREEN}Backing up Redis...${NC}"
    docker exec school-lms-redis sh -c 'redis-cli SAVE'
    docker cp school-lms-redis:/data/dump.rdb "$BACKUP_DIR/redis_dump_$TIMESTAMP.rdb"
    
    # Backup environment files
    echo -e "${GREEN}Backing up configuration...${NC}"
    cp .env "$BACKUP_DIR/"
    
    # Create archive
    tar -czf "backups/school-lms-backup_$TIMESTAMP.tar.gz" -C "$BACKUP_DIR" .
    
    # Clean up
    rm -rf "$BACKUP_DIR"
    
    echo -e "${GREEN}Backup created: backups/school-lms-backup_$TIMESTAMP.tar.gz${NC}"
}

# Restore from backup
restore_backup() {
    if [ -z "$1" ]; then
        echo -e "${RED}Error: Please specify a backup file to restore${NC}"
        echo "Usage: $0 restore <backup_file.tar.gz>"
        exit 1
    fi
    
    BACKUP_FILE="$1"
    RESTORE_DIR="restore_$(date +%Y%m%d_%H%M%S)"
    
    if [ ! -f "$BACKUP_FILE" ]; then
        echo -e "${RED}Error: Backup file not found: $BACKUP_FILE${NC}"
        exit 1
    fi
    
    echo -e "${YELLOW}Restoring from backup: $BACKUP_FILE${NC}"
    
    # Extract backup
    mkdir -p "$RESTORE_DIR"
    tar -xzf "$BACKUP_FILE" -C "$RESTORE_DIR"
    
    # Restore MongoDB
    if [ -f "$RESTORE_DIR/mongodb_backup_"*".archive" ]; then
        echo -e "${GREEN}Restoring MongoDB...${NC}"
        docker exec -i school-lms-mongodb sh -c 'mongorestore --drop --archive' < "$RESTORE_DIR/mongodb_backup_"*"archive"
    fi
    
    # Restore Redis
    if [ -f "$RESTORE_DIR/redis_dump_"*"rdb" ]; then
        echo -e "${GREEN}Restoring Redis...${NC}"
        docker cp "$RESTORE_DIR/redis_dump_"*"rdb" school-lms-redis:/data/dump.rdb
        docker restart school-lms-redis
    fi
    
    # Restore environment files
    if [ -f "$RESTORE_DIR/.env" ]; then
        echo -e "${YELLOW}A backup of the .env file was found. Please review and update it manually.${NC}"
        cp "$RESTORE_DIR/.env" ".env.backup_$(date +%Y%m%d_%H%M%S)"
    fi
    
    # Clean up
    rm -rf "$RESTORE_DIR"
    
    echo -e "${GREEN}Restore completed successfully!${NC}"
}

# Main script execution
case "$1" in
    setup)
        check_dependencies
        setup_server
        ;;
    deploy)
        check_dependencies
        deploy_app
        ;;
    update)
        check_dependencies
        update_app
        ;;
    backup)
        backup_data
        ;;
    restore)
        restore_backup "$2"
        ;;
    *)
        echo "Usage: $0 {setup|deploy|update|backup|restore}"
        exit 1
        ;;
esac

exit 0
